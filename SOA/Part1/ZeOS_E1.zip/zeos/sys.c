/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>

#include <utils.h>

#include <io.h>

#include <mm.h>

#include <mm_address.h>

#include <sched.h>

#define LECTURA 0
#define ESCRIPTURA 1


int check_fd(int fd, int permissions)
{
  if (fd!=1) return -9; /*EBADF*/
  if (permissions!=ESCRIPTURA) return -13; /*EACCES*/
  return 0;
}

int sys_ni_syscall()
{
	return -38; /*ENOSYS*/
}

int sys_getpid()
{
	return current()->PID;
}

int sys_gettime()
{
	extern int zeos_ticks;
	return zeos_ticks;
}

int sys_write(int fd, char * buffer, int size)
{
	
	int fd_err = check_fd(fd, ESCRIPTURA);
	if (fd_err) return fd_err;
	
	if (buffer == NULL) return -14;
	if (size < 0) return -22;
	
	int chars_written;
	int chars = size;
	char user_buffer[256];
	while(chars > 256) {
		
		copy_from_user(buffer+(size-chars), user_buffer, 256);
		chars_written = sys_write_console(user_buffer, 256);
		
		buffer = buffer+256;
		chars = chars-chars_written;	
	}
	
	copy_from_user(buffer+(size-chars), user_buffer, chars);
	
	chars_written = sys_write_console(user_buffer, chars);
	
	chars = chars-chars_written;
	
	return size-chars;
}

int sys_fork()
{
  int PID=-1;

  // creates the child process
  
  return PID;
}

void sys_exit()
{  
}
