/*
 * sched.c - initializes struct for task 0 anda task 1
 */

#include <sched.h>
#include <mm.h>
#include <io.h>

union task_union task[NR_TASKS]
  __attribute__((__section__(".data.task")));

#if 1
struct task_struct *list_head_to_task_struct(struct list_head *l)
{
  return list_entry( l, struct task_struct, list);
}
#endif

extern struct list_head blocked;


/* get_DIR - Returns the Page Directory address for task 't' */
page_table_entry * get_DIR (struct task_struct *t) 
{
	return t->dir_pages_baseAddr;
}

/* get_PT - Returns the Page Table address for task 't' */
page_table_entry * get_PT (struct task_struct *t) 
{
	return (page_table_entry *)(((unsigned int)(t->dir_pages_baseAddr->bits.pbase_addr))<<12);
}


int allocate_DIR(struct task_struct *t) 
{
	int pos;

	pos = ((int)t-(int)task)/sizeof(union task_union);

	t->dir_pages_baseAddr = (page_table_entry*) &dir_pages[pos]; 

	return 1;
}

void cpu_idle(void)
{
	__asm__ __volatile__("sti": : :"memory");

	while(1)
	{
	printk("hola");
	}
}

void init_idle (void)
{
	// Get an available task_union from the freequeue to contain the characteristics of this process
	struct task_struct * pcb = list_head_to_task_struct(list_first(&freequeue));
	
	// Delete the already used pcb from the list of free processes
	list_del(list_first(&freequeue));
	
	// Assign PID 0 to the process
	pcb->PID = 0;
	
	// Initialize field dir_pages_baseAaddr with a new directory to store the process address space using the allocate_DIR 		routine
	allocate_DIR(pcb);
	
	// Initialize an execution context for the process
	union task_union *tsk = (union task_union*) pcb;
	
	// Store in the stack of the idle process the address of the code that it will execute
	tsk->stack[KERNEL_STACK_SIZE - 1] = (unsigned long) cpu_idle;
	
	// Store in the stack the initial value that we want to assign to register ebp when undoing the dynamic link
	tsk->stack[KERNEL_STACK_SIZE - 2] = (unsigned long) 0;
	
	// We need to keep (in a field of its task_struct) the position of the stack where we have stored the initial value for 		the ebp register
	tsk->task.kernel_esp = &(tsk->stack[KERNEL_STACK_SIZE - 2]);
	
	// Initialize the global variable idle_task, which will help to get easily the task_struct of the idle process.
	idle_task = pcb;
}

void init_task1(void)
{
	// Get an available task_union from the freequeue to contain the characteristics of this process
	struct task_struct * pcb = list_head_to_task_struct(list_first(&freequeue));
	
	// Delete the already used pcb from the list of free processes
	list_del(list_first(&freequeue));
	
	// Assign PID 1 to the process
	pcb->PID = 1;
	
	// Initialize field dir_pages_baseAaddr with a new directory to store the process address space using the allocate_DIR 		routine
	allocate_DIR(pcb);
	
	// Complete the initialization of its address space, by using the function set_user_pages
	set_user_pages(pcb);
	
	// Initialize an execution context for the process
	union task_union * tsk = (union task_union*) pcb;
	
	// Update the TSS to make it point to the new_task system stack
	tss.esp0 = KERNEL_ESP(tsk);
	
	// In case you use sysenter you must modify also the MSR number 0x175
	writeMSR(0x175, tss.esp0);
	
	// Set its page directory as the current page directory in the system, by using the set_cr3 function
	set_cr3(pcb->dir_pages_baseAddr);
}


void init_sched()
{
	INIT_LIST_HEAD(&freequeue);
	INIT_LIST_HEAD(&readyqueue);
	for (int i = 0; i < NR_TASKS; ++i)
		list_add( &(task[i].task.list), &freequeue);
}

struct task_struct* current()
{
  int ret_value;
  
  __asm__ __volatile__(
  	"movl %%esp, %0"
	: "=g" (ret_value)
  );
  return (struct task_struct*)(ret_value&0xfffff000);
}

void inner_task_switch(union task_union *new_tsk) {

	// We copy the esp register from the KERNEL_ESP
	tss.esp0 = KERNEL_ESP((union task_union *)new_tsk);
	writeMSR(0x175, (int) tss.esp0);
	
	// We change the old system stack with the system stack of the new task
	set_cr3(get_DIR(&(new_tsk->task)));
	
	// We set the %ebp in the current's kernel_esp
	__asm__ __volatile__ (
		"mov %%ebp, %0"
		: "=g" (current()->kernel_esp)
		:);
	
	// We save in the %esp the value of the new_tsk's kernel_esp
	__asm__ __volatile__ (
		"mov %0, %%esp"
		:
		: "g" (new_tsk->task.kernel_esp));
		
	// We pop the %ebp from the stack
	__asm__ __volatile__ (
		"popl %%ebp"
		:
		:);
		
	// We return to the task_switch routine
	__asm__ __volatile__ (
		"ret"
		:
		:);

}

