/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>

#include <utils.h>

#include <io.h>

#include <mm.h>

#include <mm_address.h>

#include <sched.h>

#include <errno.h>

#define LECTURA 0
#define ESCRIPTURA 1
#define ALIGN_TO_4k 12

int globalpid = 1000;

extern struct list_head freequeue, readyqueue;



int check_fd(int fd, int permissions)
{
  if (fd!=1) return -EBADF;
  if (permissions!=ESCRIPTURA) return -EACCES;
  return 0;
}

int sys_ni_syscall()
{
	return -ENOSYS;
}

int sys_getpid()
{
	return current()->PID;
}

int sys_gettime()
{
	extern int zeos_ticks;
	return zeos_ticks;
}

int sys_write(int fd, char * buffer, int size)
{
	
	int fd_err = check_fd(fd, ESCRIPTURA);
	if (fd_err) return fd_err;
	
	if (buffer == NULL) return -EFAULT;
	if (size < 0) return -EINVAL;
	
	int chars_written;
	int chars = size;
	char user_buffer[256];
	while(chars > 256) {
		
		copy_from_user(buffer+(size-chars), user_buffer, 256);
		chars_written = sys_write_console(user_buffer, 256);
		
		buffer = buffer+256;
		chars = chars-chars_written;	
	}
	
	copy_from_user(buffer+(size-chars), user_buffer, chars);
	
	chars_written = sys_write_console(user_buffer, chars);
	
	chars = chars-chars_written;
	
	return size-chars;
}

int ret_from_fork() {

	return 0;

}

int sys_fork()
{
  // We check if the freequeue is empty and return the appropiate error if so
  if(list_empty(&freequeue)) return -ENOMEM;
  
  // We take the first list_head from the freequeue and delete it from there
  struct list_head *lh = list_first(&freequeue);
  list_del(lh);
  
  // We create the child PCB and we initialize it with the parent PCB
  union task_union *child = (union task_union*)list_head_to_task_struct(lh);
  copy_data(current(), child, sizeof(union task_union));
  
  // We initialize the child directory
  allocate_DIR((struct task_struct*)child);
  
  // We create the child page table, and we fill it with pages, if there are not enough an error will be returned
  page_table_entry *chld_pt = get_PT(&child->task);
  
  int pages[NUM_PAG_DATA];
  for (int i = 0; i < NUM_PAG_DATA; ++i) {
  
  	// If there are no pages the returned value is -1
  	pages[i] = alloc_frame();
  	
  	// We check if there is an error, and we free all the previous allocated resources and return an error
  	if (pages[i] < 0) {
  		for (int j = 0; j < i; j++) free_frame(pages[j]);
  		list_add_tail(&child->task.list, &freequeue);
  		return -EAGAIN;
  	}
  }
  
  // Child will inherit the parent data
  // We get the parent page table
  page_table_entry *prnt_pt = get_PT(current());
  
  // We copy the parent system code and data to the child, as they will be shared
  for (int i = 0; i < NUM_PAG_KERNEL; ++i) set_ss_pag(chld_pt, i, get_frame(prnt_pt, i));
  for (int i = 0; i < NUM_PAG_CODE; ++i) set_ss_pag(chld_pt, PAG_LOG_INIT_CODE+i, get_frame(prnt_pt, PAG_LOG_INIT_CODE+i));
  
  // We point the allocated fisical pages to the logical ones
  for (int i = 0; i < NUM_PAG_DATA; ++i) set_ss_pag(chld_pt, PAG_LOG_INIT_DATA+i, pages[i]);
  
  // We expand the shared space in order to be able to copy in the chld ones
  int shrd = NUM_PAG_KERNEL+NUM_PAG_CODE;
  int totl = NUM_PAG_CODE+NUM_PAG_KERNEL+NUM_PAG_DATA;
  
  // We copy them
  for (int i = shrd; i < totl; ++i) {
  
  	set_ss_pag(prnt_pt, i+NUM_PAG_DATA, get_frame(chld_pt, i));
  	copy_data((void *) (i << ALIGN_TO_4k), (void *) ((i+NUM_PAG_DATA) << ALIGN_TO_4k), PAGE_SIZE);
  	del_ss_pag(prnt_pt, i+NUM_PAG_DATA);
  }
  
  // We flush the TLB to deny parent's access to child
  set_cr3(get_DIR(current()));
  
  // We assign the new process a free PID
  child->task.PID=++globalpid;
  
  // We assign the fake ebp and @ret in the child stack and asign the kernel_esp
  ((unsigned long *)KERNEL_ESP(child))[-0x13] = (unsigned long) 0;
  ((unsigned long *)KERNEL_ESP(child))[-0x12]= (unsigned long)&ret_from_fork;
  child->task.kernel_esp = &((unsigned long *)KERNEL_ESP(child))[-0x13];
  
  // We include the child process in the ready queue
  list_add_tail(&(child->task.list), &readyqueue);
  
  // We return the child's PID
  return child->task.PID;
}

void sys_exit()
{  

	// We get the current process page table entry and we free all the reserved resurces
	struct task_struct *curr = current();
	page_table_entry *currpt = get_PT(curr);
	for(int i = 0; i<NUM_PAG_DATA; ++i){
		free_frame(get_frame(currpt, i+PAG_LOG_INIT_DATA));
		del_ss_pag(currpt, i+PAG_LOG_INIT_DATA);
	}
	
	// We remove the PID and the pointer to the pages
	curr->PID = -1;
	curr->dir_pages_baseAddr = NULL;
	
	// We assign the process in the freequeue
	update_process_state_rr(curr, &freequeue);
	
	// We forçe a change in the CPU as the process does not exist
	sched_next_rr();

}



