#include "buffer_circular.h"
#include <errno.h>

void empty_buffer(struct buffer_circular *buffer) {
    buffer->pos_to_read = 0;
    buffer->pos_to_write = 0;
    
    for (int i = 0; i < SIZE; i++) buffer->buffer[i] = '\x00'; //inicialitzem el buffer a null   
}

int read_from_buffer(unsigned char *c, struct buffer_circular *buffer) {
    if (buffer->buffer[buffer->pos_to_read] != '\x00') {
    
    	*c = buffer->buffer[buffer->pos_to_read];
    	buffer->pos_to_read++;
    	buffer->pos_to_read %= SIZE;
    	buffer->buffer[buffer->pos_to_read] = '\x00';
    	
    	return 0;
    }
    
    c = '\x00'; //el seu valor és null, error
    return -1; //no s'ha escrit res al buffer encara
}

int write_to_buffer(unsigned char *c, struct buffer_circular *buffer) {
    if (buffer->buffer[buffer->pos_to_write] != '\x00') return -ENOMEM; //no hi ha espai per escriure al buffer circular
    buffer->buffer[buffer->pos_to_write] = *c;
    buffer->pos_to_write++;
    buffer->pos_to_write %= SIZE;
    return 0;
}
