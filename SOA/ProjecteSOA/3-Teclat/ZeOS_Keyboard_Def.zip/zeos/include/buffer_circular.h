#ifndef H_BUFFER_CIRCULAR_H
#define _BUFFER_CIRCULAR_H

#define SIZE  128

struct buffer_circular {
    int pos_to_read;
    int pos_to_write;
    unsigned char buffer[SIZE];
};

//buida el buffer a 0
void empty_buffer(struct buffer_circular *buffer);
//llegeix el següent caràcter a llegir del buffer circular, retorna error si no hi ha res per llegir
int read_from_buffer(unsigned char *c, struct buffer_circular *buffer);
//escriu en el buffer el caràcter apuntat per c, retorna error si el buffer està ple
int write_to_buffer(unsigned char *c, struct buffer_circular *buffer);

#endif
