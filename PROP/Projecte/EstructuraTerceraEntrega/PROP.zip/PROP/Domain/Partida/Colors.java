package Domain.Partida;

public enum Colors {
    vermell,
    blau,
    verd,
    groc,
    taronja,
    rosa,
    lila,
    gris,
    blanc,
    negre,
    buit
}
