package Domain.Partida;

import java.io.Serializable;
import java.time.*;
import java.util.ArrayList;
import java.util.List;

import Domain.Dificultat;

/**
 * Classe Partida
 * Conté informació de la partida que cadascun dels jugadors té activa, aquesta classe representen partides pausades o partides en què l'usari està jugant
 *
 * @author Noa Yu Ventura Vila
 */
public class Partida implements Serializable {
    private final int pid;
    private final Dificultat dificultat;
    private final TipusPartida tipusPartida;
    private boolean usatAjuda;
    private byte rondesIA;
    private byte rondesUsuari;
    private Duration tempsPartida;
    //Conté en quin moment s'ha iniciat o reanudat la partida
    private Instant iniciPartida;
    private boolean tornIA;
    //Conté en quin moment es va crear la partida
    private final LocalDateTime tempsInici;
    private int puntuacio;
    private Maquina maquinaAlgorismes;

    /**
     * Crea una nova partida amb els paràmetres demanats, i els que no ens dónen tenen el valor per defecte
     * Cost: O(1) en tots els casos
     * @param id ID que farem servir per identificar la nova partida que crearem
     * @param dif dificultat que tindrà la partida
     * @param tipusP tipus de la partida que crearem
     */
    public Partida(int id, Dificultat dif, TipusPartida tipusP, Maquina maquina) {
        pid = id;
        dificultat = dif;
        tipusPartida = tipusP;
        usatAjuda = false;
        rondesIA = 0;
        rondesUsuari = 0;
        tempsPartida = Duration.ZERO;
        iniciPartida = Instant.now();
        tornIA = false;
        tempsInici = LocalDateTime.now();
        puntuacio = 0;
        maquinaAlgorismes = maquina;
    }

    /**
     * Obtenim l'identificador de la partida
     * Cost: O(1) en tots els casos
     * @return el ID de la partida
     */
    int getPid() {
        return pid;
    }

    /**
     * Obtenim la dificultat de la partida
     * Cost: O(1) en tots els casos
     * @return la dificultat de la partida
     */
    Dificultat getDificultat() {
        return dificultat;
    }

    /**
     * Obtenim el tipus de partida
     * Cost: O(1) en tots els casos
     * @return el tipus de partida
     */
    TipusPartida getTipusPartida() {
        return tipusPartida;
    }

    /**
     * Obtenim l'atribut usatAjuda de la partida
     * Cost: O(1) en tots els casos
     * @return si l'usuari ha demanat ajuda o no; true en cas afirmatiu, false en cas contrari
     */
    boolean getUsatAjuda() {
        return usatAjuda;
    }

    /**
     * Obtenim les rondes que ha fet la IA en aquesta partida
     * Cost: O(1) en tots els casos
     * @return el número de rondes que ha fet la IA en aquesta partida
     */
    byte getRondesIA() {
        return rondesIA;
    }

    /**
     * Obtenim les rondes que ha fet l'usuari en aquesta partida
     * Cost: O(1) en tots els casos
     * @return el número de rondes que ha fet l'usuari en aquesta partida
     */
    byte getRondesUsuari() {
        return rondesUsuari;
    }

    /**
     * Obtenim el temps que ha durat la partida fins ara
     * Cost: O(1) en tots els casos
     * @return el temps que ha durat la partida
     */
    Duration getTempsPartida() {
        return tempsPartida;
    }

    /**
     * Obtenim si és el torn de la IA per jugar com a codebreaker
     * Cost: O(1) en tots els casos
     * @return <CODE>true</CODE> si és el torn de la IA per jugar com a codebreaker, <CODE>false</CODE> en cas contrari
     */
    boolean getTornIA() {
        return this.tornIA;
    }

    /**
     * Obtenim el moment en què hem començat la partida
     * Cost: O(1) en tots els casos
     * @return temps d'inici de la partida
     */
    LocalDateTime getTempsInici() {
        return tempsInici;
    }

    /**
     * Obtenim la puntuacio que ha fet l'usuari en la partida
     * Cost: O(1) en tots els casos
     * @return la puntuació de la partida
     */
    int getPuntuacio() {
        return puntuacio;
    }

    /**
     * Obtenim quin algorisme estem fent servir
     * Cost: O(1) en tots els casos
     * @return true si l'algorisme Ã©s FiveGuess, false en cas contrari
     */
    boolean getMaquina() {
        return maquinaAlgorismes instanceof MaquinaFiveGuess;
    }

    /**
     * Posem l'atribut usatAjuda de la partida a true quan l'usuari demana ajut en la partida
     * Cost: O(1) en tots els casos
     */
    void setUsatAjuda() {
        usatAjuda = true;
    }

    /**
     * Posem l'atribut IniciPartida al valor que ens passen per paràmetre
     * Cost: O(1) en tots els casos
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     */
    void setIniciPartida() {
        try {
            this.iniciPartida = Instant.now();
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Posem l'atribut tornIA de la partida al valor que ens passen per paràmetre
     * Cost: O(1) en tots els casos
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     */
    void setTornIA() {
        try {
            this.tornIA = true;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Posem l'atribut rondesIA de la partida al valor que ens passen per paràmetre
     * Cost: O(1) en tots els casos
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     */
    void incRondesIA() {
        this.rondesIA++;
    }

    /**
     * Posem l'atribut rondesUsuari de la partida al valor que ens passen per paràmetre
     * Cost: O(1) en tots els casos
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     */
    void incRondesUsuari() {
        this.rondesUsuari++;
    }

    /**
     * Incrementem l'atribut tempsPartida de la partida en el valor calculat de la següent manera:
     *              1. L'instant en el que estem ara mateix
     *              2. El moment que hem iniciat/reanudat la partida
     * Cost: O(1) en tots els casos
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     */
    void incTempsPartida() {
        try {
            this.tempsPartida = this.tempsPartida.plus(Duration.between(iniciPartida, Instant.now()));
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    /**
     * Calculem la puntuació que s'ha obtingut en la partida a partir dels atributs d'aquesta i s'actualitza el seu atribut
     * Cost: O(1) en tots els casos
     * @param nColumns número de columnes que té el tauler de la partida
     * @param nColors número de colors que es fan srevir en la partida
     * @return el valor de la puntuacio que s'ha obtingut en la partida
     */
    int calcularPuntuacio(int nColumns, int nColors) {
        int dif = 1, ajut;

        //Com més fàcil sigui la partida menys puntuació pots obtenir
        if (this.dificultat == Dificultat.facil) dif = 1;
        else if (this.dificultat == Dificultat.intermig) dif = 2;
        else if (this.dificultat == Dificultat.dificil) dif = 3;

        //Si l'usuari ha demanat ajuda, se li redueix la puntuació a la meitat
        if (this.usatAjuda) ajut = 1;
        else ajut = 2;
        Double temps = (1.0 / Long.valueOf(this.tempsPartida.getSeconds()).intValue()) * 1000;
        int punt = dif * (ajut / 2) * (this.rondesIA / this.rondesUsuari) * (nColors / nColumns) * temps.intValue();
        this.puntuacio = punt;
        return punt;
    }

    /**
     * Recolecta tots els intents que fa la IA en la resolució del codi
     * Cost: O(maxSteps * (colors^n + n^3)); on n és la longitud de la solució per a l'algoritme FiveGuess
     * Cost: O(n) en el millor cas, O(maxGeneracions * m * n^3) en el pitjor dels casos; on n és el nombre d'individus de la població, maxGeneracions és els intents per a l'algoritme Genètic
     * @param solucio solució que proposa l'usuari com a codemaker
     * @return llista de combinacions de codis
     * @exception RuntimeException Tarda massa
     */
    ArrayList<Colors[]> intentsMaquina(Colors[] solucio){
        List<Integer> llistaColors = new ArrayList<Integer>();
        for (Colors color : solucio) {
            int valor = 0;
            switch (color) {
                case vermell:
                    valor = 1;
                    break;
                case blau:
                    valor = 2;
                    break;
                case verd:
                    valor = 3;
                    break;
                case groc:
                    valor = 4;
                    break;
                case taronja:
                    valor = 5;
                    break;
                case rosa:
                    valor = 6;
                    break;
                case lila:
                    valor = 7;
                    break;
                case gris:
                    valor = 8;
                    break;
            }
            llistaColors.add(valor);
        }
        try {
            List<List<Integer>> intents =  maquinaAlgorismes.solve(llistaColors);
            ArrayList<Colors[]> intentsSortida = new ArrayList<>();
            for (List<Integer> intent : intents) {
                Colors[] colors = new Colors[intent.size()];
                for (int i = 0; i < intent.size(); i++) {
                    switch(intent.get(i)) {
                        case 1:
                            colors[i] = Colors.vermell;
                            break;
                        case 2:
                            colors[i] = Colors.blau;
                            break;
                        case 3:
                            colors[i] = Colors.verd;
                            break;
                        case 4:
                            colors[i] = Colors.groc;
                            break;
                        case 5:
                            colors[i] = Colors.taronja;
                            break;
                        case 6:
                            colors[i] = Colors.rosa;
                            break;
                        case 7:
                            colors[i] = Colors.lila;
                            break;
                        case 8:
                            colors[i] = Colors.gris;
                            break;
                    }
                }
                intentsSortida.add(colors);
            }
            rondesIA = (byte) intentsSortida.size();
            return intentsSortida;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}