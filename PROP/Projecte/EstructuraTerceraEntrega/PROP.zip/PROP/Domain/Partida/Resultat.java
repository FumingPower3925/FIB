package Domain.Partida;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;

/**
 * Classe Resultat
 * Conté el resultat de les partides que ja han acabat del sistema
 *
 * @author David Molina Mesa
 */
public class Resultat implements Serializable {
    private final int rid;
    private final TipusPartida tipusPartida;
    private final byte rondesUsuari;
    private final byte rondesIA;
    private final LocalDateTime tempsInici;
    private final Duration temps;
    private final int puntuacio;

    /**
     * Crea un nou resultat amb els paràmetres demanats
     * Cost: O(1) en tots els casos
     * @param _rid ID que farem servir per identificar el nou resultat que crearem
     * @param _tipusPartida Tipus de partida a la qual correspon el resultat
     * @param _rondesUsuari Rondes que l'usuari ha necessitat fins a acabar la partida
     * @param _rondesIA Rondes que la IA ha necessitat fins a acabar la partida
     * @param _tempsInici Data (amb hores, minuts i segons) en la qual l'usuari va iniciar la partida del resultat
     * @param _temps Temps de duracio de la partida del resultat
     * @param _puntuacio Puntuacio final de la partida a la qual correspon el resultat
     */
    public Resultat(int _rid, TipusPartida _tipusPartida, byte _rondesUsuari, byte _rondesIA, LocalDateTime _tempsInici,
                    Duration _temps, int _puntuacio){
        this.rid = _rid;
        this.tipusPartida = _tipusPartida;
        this.rondesUsuari = _rondesUsuari;
        this.rondesIA = _rondesIA;
        this.tempsInici = _tempsInici;
        this.temps = _temps;
        this.puntuacio = _puntuacio;
    }

    /**
     * Retorna el identificador del resultat
     * @return Int que conte el identificador de resultat
     */
    int getRid() {
        return rid;
    }

    /**
     * Obtenim el tipus de partida del resultat
     * Cost: O(1) en tots els casos
     * @return el tipus de partida del resultat
     */
    TipusPartida getTipusPartida() {
        return tipusPartida;
    }

    /**
     * Obtenim el número de rondes que ha necessitat l'usuari
     * Cost: O(1) en tots els casos
     * @return el numero de rondes que ha necessitat l'usuari
     */
    byte getRondesUsuari() {
        return rondesUsuari;
    }

    /**
     * Obtenim el número de rondes que ha necessitat la IA
     * Cost: O(1) en tots els casos
     * @return el número de rondes que ha necessitat la IA
     */
    byte getRondesIA() {
        return rondesIA;
    }

    /**
     * Obtenim la data (amb hores, segons i minuts) en la qual l'usuari va iniciar la partida del resultat
     * Cost: O(1) en tots els casos
     * @return la data (amb hores, segons i minuts) en la qual l'usuari va iniciar la partida del resultat
     */
    LocalDateTime getTempsInici() {
        return tempsInici;
    }

    /**
     * Obtenim el temps de duració de la partida del resultat
     * Cost: O(1) en tots els casos
     * @return el temps de duració de la partida del resultat
     */
    Duration getTemps() {
        return temps;
    }

    /**
     * Obtenim la puntuació final de la partida a la qual correspon el resultat
     * Cost: O(1) en tots els casos
     * @return la puntuació final de la partida a la qual correspon el resultat
     */
    int getPuntuacio() {
        return puntuacio;
    }
}

