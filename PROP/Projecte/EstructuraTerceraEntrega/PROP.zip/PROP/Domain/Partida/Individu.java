package Domain.Partida;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe Individu
 * Conté informació dels gens d'un individu
 *
 * @author Noa Yu Ventura Vila
 */

public class Individu {

    private final int numGensPerDefecte;
    // NOTA: En Indvidu es guarden bytes, no es pot canviar
    private final byte[] gens;
    private double fitness;

    /**
     * Constructora d'un individu qualsevol
     * Cost: O(1) en tots els casos
     * @param numGens nombre de gens que tindrà aquest individu. En aquest cas en concret és el nombre de columnes (gens) que tindrà el codi solució
     */
    Individu(int numGens) {
        numGensPerDefecte = numGens;
        fitness = 0;
        gens = new byte[numGens];
    }

    /**
     * Constructora d'un individu en concret
     * Cost: O(n) en tots els casos; on n és el nombre de columnes que tingui el codi solució
     * @param newGens gens als que volem inicialitzar l'individu
     */
    Individu(List<Integer> newGens) {
        numGensPerDefecte = newGens.size();
        fitness = newGens.size();
        gens = new byte[newGens.size()];
        for (int i = 0; i < numGensPerDefecte; ++i)
            gens[i] = newGens.get(i).byteValue();
    }

    /**
     * Obtenim el nombre de gens que té l'individu
     * Cost: O(1) en tots els casos
     * @return el nombre de gens que té l'individu demanat
     */
    int numGens() {
        return gens.length;
    }

    /**
     * Obtenim el gen que necessitem a partir de la posició on està
     * Cost: O(1) en tots els casos
     * @param index posició on es troba el gen que volem obtenir. 0 <= index < gens.size()
     * @return el gen que necessitem
     * @exception IndexOutOfBoundsException index amb valor erroni
     */
    byte getGen(int index) {
        if (index < gens.length && index >= 0) return gens[index];
        throw new IndexOutOfBoundsException("Índex amb valor erroni");
    }

    /**
     * Obtenim els gens de tot l'individu
     * Cost: O(n); on n és el nombre de gens que té l'individu
     * @return una llista amb tots els gens que necessitem en format Integer
     */
    List<Integer> getGens() {
        List<Integer> ret = new ArrayList<>();
        for (byte gen : gens) ret.add((int) gen);
        return ret;
    }

    /**
     * Modifiquem el gen que volem a partir de la posició on està amb el nou valor
     * Cost: O(1) en tots els casos
     * @param index posició on es troba el gen que volem modificar. 0 <= index < gens.size()
     * @param valor nou valor que li volem ficar al gen
     * @exception IndexOutOfBoundsException index amb valor erroni
     */
    void setGen(int index, byte valor) {
        if (index < gens.length && index >= 0){
            gens[index] = valor;
            fitness = 0;
        }
        else throw new IndexOutOfBoundsException("Índex amb valor erroni");
    }

    /**
     * Modifiquem el gen que volem a partir de la posició on està amb un valor random
     * Cost: O(1) en tots els casos
     * @param index posició on es troba el gen que volem modificar. 0 <= index < gens.size()
     * @param n_colors nombre de colors que es poden fer servir per al codi solució
     * @exception IndexOutOfBoundsException index amb valor erroni
     */
    void setGenRandom(int index, int n_colors) {
        if (index < gens.length && index >= 0){
            Integer gen = (int)(1 + Math.floor(Math.random() * n_colors));
            setGen(index, gen.byteValue());
        }
        else throw new IndexOutOfBoundsException("Índex amb valor erroni");
    }

    /**
     * Assignem valors random als gens de l'individu
     * Cost: O(n); on n és el nombre de gens de l'individu
     * @param n_colors nombre de colors que es poden fer servir per al codi solució
     */
    void inicialitzaIndividu(int n_colors) {
        for (int i = 0; i < numGens(); i++)
            setGenRandom(i, n_colors);
    }

    /**
     * Calculem el fitness de l'individu a partir de la solució, la qual té fitness màxim
     * Cost: O(n) en tots els casos; on n és el nombre de gens que té l'individu solució
     * @param solucio individu solució que volem trobar que té fitness màxim
     * @return la fitness de l'individu
     */
    double fitnessIndividu(Individu solucio) {
        int fitness = 0;
        for (int i = 0; i < numGens() && i < solucio.numGens(); ++i)
            if (getGen(i) == solucio.getGen(i)) fitness++;
        this.fitness = fitness;
        return fitness;
    }
}
