package Domain.Partida;

/**
 * Classe Poblacio
 * Conté informació d'una població composta d'individus
 *
 * @author Noa Yu Ventura Vila
 */

public class Poblacio {

    //Individus que componen la població
    private Individu[] individus;

    /**
     * Constructora d'una població qualsevol
     * Cost: O(n); on n és igual al tamany
     * @param tamany mida (nombre d'individus) que tindrà la població
     * @param inicialitza boolean que determina si inicialitzem la població o simplement la deixem buida
     * @param numGens nombre de gens que tindran els individus de la població. En aquest cas en concret és el nombre de columnes que tindrà el codi solució
     * @param nColors nombre de colors possibles per a endevinar el codi solució
     */
    Poblacio(int tamany, boolean inicialitza, int numGens, int nColors) {
        individus = new Individu[tamany];
        // Inicializa la poblacion
        if (inicialitza) {
            for (int i = 0; i < tamany; i++) {
                Individu nouInd = new Individu(numGens);
                do {
                    nouInd.inicialitzaIndividu(nColors);
                } while(existeixIndividu(nouInd, i));
                setIndividu(i, nouInd);
            }
        }
    }

    /**
     * Obtenim el nombre d'individus que té la població
     * Cost: O(1) en tots els casos
     * @return el nombre d'individus que té la població demanada
     */
    int numIndividus() {
        return individus.length;
    }

    /**
     * Indica si ja existeix l'individu o no
     * Cost: O(n*m); on n és el nombre d'individus que hi ha a la població, i m és el nombre de gens que tenen aquests
     * @param ind individu que volem comprovar si ja existeix en la població o no
     * @param limit punt de la llista d'individus fins al qual volem comprovar
     * @return true si l'individu ind ja existeix, fals en cas contrari
     */
    boolean existeixIndividu(Individu ind, int limit) {
        for (int i = 0; i < individus.length && i < limit; ++i) {
            byte count = 0;
            for (int j = 0; j < ind.numGens(); ++j) {
                if (ind.getGen(j) == individus[i].getGen(j)) ++count;
            }
            if (count == ind.numGens()) return true;
        }
        return false;
    }

    /**
     * Obtenim l'individu demanat a partir de la seva posició
     * Cost: O(1) en tots els casos
     * @param index posició en la que es troba l'individu que volem obtenir: 0 <= index < numIndividus()
     * @return el nombre d'individus que té la població demanada
     * @exception IndexOutOfBoundsException index amb valor erroni
     */
    Individu getIndividu(int index) {
        if (0 <= index && index < numIndividus()) return individus[index];
        else throw new IndexOutOfBoundsException("Índex amb valor erroni");
    }

    /**
     * Inicialitzar l'individu demanat a partir de la seva posició a l'individu que ens passen per paràmetre
     * Cost: O(1) en tots els casos
     * @param index posició en la que es troba l'individu que volem modificar: 0 <= index < numIndividus()
     * @param ind individu que volem ficar a la població
     * @exception IndexOutOfBoundsException index amb valor erroni
     */
    void setIndividu(int index, Individu ind) {
        if (0 <= index && index < numIndividus()) individus[index] = ind;
        else throw new IndexOutOfBoundsException("Índex amb valor erroni");
    }

    /////////////////////////////////////
    // Mètodes específics del genètic
    /////////////////////////////////////

    /**
     * Obtenir l'individu més apte de la població
     * Cost: O(nm); on n és el nombre d'individus de la població i m el nombre de gens de l'individu
     * @param solucio individu que té el codi solució que l'algoritme ha de trobar
     * @return l'individu més apte que té la població (amb major fitness)
     */
    Individu individuMesApte(Individu solucio) {
        Individu fittest = individus[0];
        for (int i = 1; i < numIndividus(); i++)
            if (fittest.fitnessIndividu(solucio) < getIndividu(i).fitnessIndividu(solucio)) fittest = individus[i];
        return fittest;
    }

    /**
     * Indica si l'individu és vàlid per a afegir a la població
     * Cost: O(n); on n és el nombre de gens que té un individu
     * @param solucio individu solució que conté el codi correcte
     * @param lastGen millor individu de la generació anterior
     * @param ind individu a evaluar
     * @return true si l'individu ind té com a molt numGens()-fitness gens diferents a l'individu lastGen
     */
    boolean valid(Individu solucio, Individu lastGen, Individu ind) {
        int count = 0;
        for (int i = 0; i < solucio.numGens(); ++i) {
            if (lastGen.getGen(i) != ind.getGen(i)) ++count;
        }
        return count == lastGen.numGens()-lastGen.fitnessIndividu(solucio);
    }

    /**
     * Seleccionem el millor individu del torneig creat aleatòriament
     * Cost: O(n*m); on n és el nombre d'individus que té el torneig i m és el nombre de gens que tenen els individus del torneig
     * @param solucio individu solució que l'algoritme ha de trobar
     * @param numGens nombre de gens que té la solució i que tenen els individus de la població del torneig
     * @param nColors nombre de colors possibles que estiguin en el codi solució
     * @param lastGen millor individu de la generació anterior
     * @return l'individu més apte del torneig
     */
    Individu seleccionaIndividu(Individu solucio, int numGens, int nColors, Individu lastGen) {
        Poblacio torneig = new Poblacio(numIndividus(), false, numGens, nColors);
        for (int i = 0; i < numIndividus(); ++i) {
            Individu nouInd = new Individu(numGens);
            do {
                nouInd.inicialitzaIndividu(nColors);
            } while (!valid(solucio, lastGen, nouInd));
            torneig.setIndividu(i, nouInd);
        }
        return torneig.individuMesApte(solucio);
    }

    /**
     * Fem evolucionar la població que tenim en l'actual generació per fer-ne una de millor a la següent generació
     * Cost: O(m*n^2); on n és el nombre d'individus que té la població i m és el nombre de gens que tenen aquests
     * @param solucio individu solució que l'algoritme ha de trobar
     * @param nColors nombre de colors possibles que pot tenir la solució
     * @param lastGen generació anterior
     * @return la nova població de la següent generació
     */
    Poblacio evolucionaPoblacio(Individu solucio, int nColors, Individu lastGen) {
        Poblacio novaPoblacio = new Poblacio(numIndividus(),false, solucio.numGens(), nColors);

        for (int i = 0; i < numIndividus(); i++) {
            Individu indv1 = seleccionaIndividu(solucio, solucio.numGens(), nColors, lastGen);
            Individu indv2 = seleccionaIndividu(solucio, solucio.numGens(), nColors, lastGen);
            if (indv1.fitnessIndividu(solucio) > indv2.fitnessIndividu(solucio)) novaPoblacio.setIndividu(i, indv1);
            else novaPoblacio.setIndividu(i, indv2);
        }
        return novaPoblacio;
    }
}