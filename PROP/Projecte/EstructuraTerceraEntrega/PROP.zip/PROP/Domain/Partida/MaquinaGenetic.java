package Domain.Partida;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe MaquinaGenetic
 * Conté la informació i funcions necessàries per a que la IA jugui el seu torn
 *
 * @author Noa Yu Ventura Vila
 */

public class MaquinaGenetic implements Maquina, Serializable {
    private final int maxGeneracions;
    private final int nIndividusPoblacio;
    private final int nColors;

    /**
     * Creadora de la implementació de MaquinaGenetic
     * Cost: O(1) en tots els casos
     * @param n_colors nombre de colors que es poden fer servir per al codi solució
     * @param n_maxSteps limitació del nombre de generacions de jugades que pot fer l'algorisme
     */
    public MaquinaGenetic(int n_colors, int n_maxSteps) {
        maxGeneracions = n_maxSteps;
        nIndividusPoblacio = 5;
        nColors = n_colors;
    }

    /**
     * Implementació de l'algorisme Genètic
     * Cost: O(n) en el millor cas, O(maxGeneracions * m * n^3) en el pitjor dels casos; on n és el nombre d'individus de la població, maxGeneracions és els intents
     * màxims que té l'algoritme per endevinar el codi solució, i m és el nombre de columnes que té la solució
     * @param solution codi de la solució
     * @return una llista de combinacions proposades com solucions. La seva longitud depèn de quantes generacions necessitarà
     * fer l'algorisme per a trobar la solució, si no la troba retorna maxSteps codis.
     * @exception IllegalArgumentException Es llença si el codi secret de solució no és coherent amb els paràmetres de la partida actual
     */
    @Override
    public List<List<Integer>> solve(List<Integer> solution) throws Exception {

        if (solution == null || solution.isEmpty()) throw new IllegalArgumentException("El codi secret no pot ser null o buit");

        //Guardem totes les rondes que ha fet l'algoritme per després retornar-les
        List<List<Integer>> ret = new ArrayList<>();

        //Creem l'individu solució que l'algoritme genètic ha de trobar
        Individu solucio = new Individu(solution);

        // Crear població inicial que serà random
        Poblacio poblacio = new Poblacio(nIndividusPoblacio,true, solution.size(), nColors);
        ret.add(poblacio.individuMesApte(solucio).getGens());

        // Evolucionar la població fins a aconseguir el més adaptat (el que s'assembli més a la solució). Cada generació és una ronda que la IA juga en el seu torn
        int generacio = 0;
        while (generacio < maxGeneracions && poblacio.individuMesApte(solucio).fitnessIndividu(solucio) < maxFitness(solucio)) {
            poblacio = poblacio.evolucionaPoblacio(solucio, nColors, poblacio.individuMesApte(solucio));
            ret.add(poblacio.individuMesApte(solucio).getGens());
            generacio++;
        }

        return ret;
    }

    /**
     * Obtenim el màxim fitness possible que pot aconseguir un individu
     * Cost: O(1) en tots els casos
     * @param solucio individu solució que l'algoritme ha de trobar
     * @return el màxim fitness que es pot aconseguir (és igual al fitness de la solució, que és igual al nombre de gens que té l'individu solució)
     */
    private double maxFitness(Individu solucio) {
        return solucio.numGens();
    }
}