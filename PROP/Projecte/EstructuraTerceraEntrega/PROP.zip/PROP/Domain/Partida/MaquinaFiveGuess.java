package Domain.Partida;

import Domain.Pair;

import java.io.Serializable;
import java.util.*;

/**
 * Classe MaquinaFiveGuess
 * Implementa la interfície Màquina amb l'algorisme "Five Guess"
 *
 * @author David Molina Mesa
 */
public class MaquinaFiveGuess implements Maquina, Serializable {
    private final int colors;
    private final int maxSteps;

    /**
     * Creadora de la implementació de MaquinaFiveGuess
     * Cost: O(1)
     * @param _colors nombre de colors del codi del Codemaster
     * @param _maxSteps limitació del nombre de generacions de jugades que pot fer l'algorisme
     */
    public MaquinaFiveGuess(int _colors, int _maxSteps) {
        colors = _colors;
        maxSteps = _maxSteps;
    }

    /**
     * Implementacio de l'algorisme FiveGuess
     * Cost: O(maxSteps * (colors^n + n^3)); on n es la longitud de la solució
     * @param solution codi de la solució
     * @return una llista de combinacions proposades com solucions. La seva longitud depen de quants steps necessitarà
     * fer l'algorisme per trobar la solució, si no la troba retorna maxSteps codis.
     * @exception IllegalArgumentException Es llenca si el codi secret de solució no és coherent amb els paràmetres
     * de la partida actual
     */
    @Override
    public List<List<Integer>> solve(List<Integer> solution) throws Exception {
        if (solution == null || solution.isEmpty()) {
            throw new IllegalArgumentException("El codi secret no pot ser null o buit");
        }
            //generm possibles combinacions inicials
            List<List<Integer>> possibles = generarCandidatsInicials(solution.size(), colors);

            //calculem evaluacio de cada possible combinacio
            Map<String, Set<List<Integer>>> evaluacions = avaluarPossibles(possibles, solution);

            //ordenem les possibles combinacions per diferencia amb la solucio
            List<List<Integer>> ordenats = ordenarPerDiferencia(possibles, solution);

            //generem proxima jugada a partir dels ordenats
            List<Integer> jugada = generarJugada(ordenats);

            int steps = 0;
            List<List<Integer>> result = new ArrayList<>();
            result.add(jugada);

            //generem noves combinacions mentres no encertem jugada i tinguem steps disponibles
            while (!jugada.equals(solution) && steps < maxSteps) {

                //fem update de la llista de combinacions possibles
                possibles = generarPossibles(possibles, jugada, evaluacions);

                //calculem de nou les evaluacions
                evaluacions = avaluarPossibles(possibles, solution);

                //tornem a ordenar
                ordenats = ordenarPerDiferencia(possibles, solution);

                //generem una altra jugada
                jugada = generarJugada(ordenats);

                //l'afegim a la llista de resultats
                result.add(jugada);
                steps++;
            }

            //cas en que assolim maxSteps i hem de retornar maxSteps combinacions
            if (steps == maxSteps) {
                result = new ArrayList<>();
                for (int i = 0; i < maxSteps; i++) {
                    result.add(possibles.get(i));
                }
            }
            return result;
    }


    /**
     * Crea un llista de combinacions candidates inicials
     * Cost: O(colors^posicions), atès que es tracta a una combinatòria d'aquests
     * @param posicions nombre de cel·les de la solució
     * @param colors nombre de colors amb els quals juguem
     * @return llista amb les combinacions candidates inicials
     */
    private List<List<Integer>> generarCandidatsInicials(int posicions, int colors){
        List<List<Integer>> possibles = new ArrayList<>();
        int[] cod = new int[posicions];
        Arrays.fill(cod, 1);
        while (true) {
            List<Integer> codi = new ArrayList<>();
            Set<Integer> usats = new HashSet<>();
            boolean combinacioValida = true;
            for (int i = 0; i < posicions; i++) {
                codi.add(cod[i]);
                if (usats.contains(cod[i])) {
                    combinacioValida = false;
                    break;
                }
                usats.add(cod[i]);
            }
            if (combinacioValida) {
                possibles.add(codi);
            }
            int i = posicions - 1;
            while (i >= 0 && cod[i] == colors) {
                i--;
            }
            if (i < 0) {
                break;
            }
            cod[i]++;
            for (int j = i + 1; j < posicions; j++) {
                cod[j] = 1;
            }
        }
        return possibles;
    }

    /**
     * Crea un diccionari d'avaluacions - conjunt de combinacions
     * Cost: O(n^m) essent n la longitud de la llista i m la longitud de les subllistes
     * @param possibles llista de les combinacions possibles
     * @param solucio codi del Codemaster
     * @return diccionari on les claus són les diferents avaluacions, i els valors un set on s'agrupen les combinacions
     */
    private Map<String, Set<List<Integer>>> avaluarPossibles(List<List<Integer>> possibles, List<Integer> solucio) {
        Map<String, Set<List<Integer>>> avaluacio = new HashMap<>();
        for (List<Integer> possible : possibles) {
            String key = generaClauAvaluacio(solucio, possible);
            Set<List<Integer>> possiblesAvaluats = avaluacio.getOrDefault(key, new HashSet<>());
            possiblesAvaluats.add(possible);
            avaluacio.put(key, possiblesAvaluats);
        }
        return avaluacio;
    }

    /**
     * Genera una clau d'avaluació donada una combinació possible en format String. Les posicions de l'String tenen
     * una B si aquest color coincideix en aquella posició, una W si aquell color està contingut en la solució
     * o " " (buit) si el color no pertany a la solució.
     * Cost: O(n^2) cas pitjor i mig, O(n) cas millor (essent n la longitud de les llistes solució i possible)
     * @param solucio codi del Codemaker
     * @param possible combinació possible
     * @return String que representa una clau d'avaluació de la combinació que es passa per paràmetre enfront de
     * la solució.
     */
    private String generaClauAvaluacio(List<Integer> solucio, List<Integer> possible) {
        StringBuilder clau = new StringBuilder();
        for (int i = 0; i < solucio.size(); i++) {
            if (solucio.get(i).equals(possible.get(i))) {
                clau.append("B");
            } else if (possible.contains(solucio.get(i))) {
                clau.append("W");
            } else {
                clau.append(" ");
            }
        }
        return clau.toString();
    }

    /**
     * Ordena una llista de combinacions per grau de diferència amb la combinació de la solució del codi del
     * Codemaker. Quan parlem de grau de diferència ens referim a quant difereix una combinació respecte a un altre
     * Cost: O(n*k) cas pitjor, mig i millor (tenint en compte que calcularDiferencia() té cost O(n) essent n la mida
     * de solució i k la quantitat de combinacions possibles)
     * @param possibles llista de combinacions possibles
     * @param solucio codi del Codemaker
     * @return llista de combinacions ordenades per grau de diferencia
     */
    private List<List<Integer>> ordenarPerDiferencia(List<List<Integer>> possibles, List<Integer> solucio) {
        List<Pair<List<Integer>, Integer>> codisAmbDiferencia= new ArrayList<>();
        for (List<Integer> possible : possibles) {
            int diferencia = calculaDiferencia(possible, solucio);
            codisAmbDiferencia.add(new Pair<>(possible, diferencia));
        }

        codisAmbDiferencia.sort(Comparator.comparing(Pair::getValue));

        List<List<Integer>> codisOrdenats = new ArrayList<>();
        for (Pair<List<Integer>, Integer> par : codisAmbDiferencia) {
            codisOrdenats.add(par.getKey());
        }
        return codisOrdenats;
    }

    /**
     * Calcula el grau de diferència entre dos codis
     * Cost: O(n) cas pitjor i mig, O(1) cas millor (essent n la mida de les llistes codi1 i codi2)
     * @param codi1 un codi arbitrari
     * @param codi2 un codi arbitrari
     * @return el grau de diferencia entre dos codis
     */
    private int calculaDiferencia(List<Integer> codi1, List<Integer> codi2) {
        int diferencia = 0;
        for (int i = 0; i < codi1.size(); i++) {
            if (!codi1.get(i).equals(codi2.get(i))) {
                diferencia++;
            }
        }
        return diferencia;
    }

    /**
     * Genera una combinació la qual serà una jugada de la màquina
     * Cost: O(n) cas pitjor i mig, O(1) cas millor
     * @param possibles llista de combinacions possibles
     * @return una llista que representa una combinació la qual sera una jugada de la maquina
     */
    private List<Integer> generarJugada(List<List<Integer>> possibles) {
        if (possibles.size() == 1) {
            return possibles.get(0);
        }
        //obtenim subconjunt amb menor quantitat combinacions cobertes
        List<List<Integer>> subconjunt = obtenirSubconjunt(possibles); //caldria fer sort??? REVISAR

        Random random = new Random();
        int size = subconjunt.size();

        int randomIndex = random.nextInt(10); //generem un nombre aleatori entre 0 i 9

        if (randomIndex <= 2) { //si el nombre aleatori és menor o igual que 2, retornem el primer element de subconjunt
            return subconjunt.get(0);
        } else { //si el nombre aleatori és més gran que 2, generem un element aleatori diferent del primer
            int randomElementIndex = random.nextInt(size - 1) + 1;
            return subconjunt.get(randomElementIndex);
        }
    }


    /**
     * Obté un subconjunt de la llista de combinacions possibles (el primer 20% d'aquesta)
     * Cost: O(n) cas pitjor i mig, O(1) cas millor (essent n la longitud de la llista de possibles)
     * @param possibles llista de combinacions possibles
     * @return  subconjunt de la llista de combinacions possibles (un 20% d'aquesta)
     */
     private List<List<Integer>> obtenirSubconjunt(List<List<Integer>> possibles) {
        List<List<Integer>> subconjunt = new ArrayList<>();
        //tamanySubconjunt per ara sera del 20%
        int tamanySubconjunt = Math.round(possibles.size() * 0.2f);
        for (int i = 0; i < tamanySubconjunt && i < possibles.size(); i++) {
            subconjunt.add(possibles.get(i));
        }
        return subconjunt;
    }

    /**
     * Genera una llista de possibles solucions atenent a una jugada ja realitzada filtrant-les de tal manera que només
     * retorna aquelles que tenen la mateixa clau d'avaluació que la jugada que li passem per paràmetre
     * Cost: O(n^3) cas pitjor i mig, O(1) cas millor
     * @param possibles llista de combinacions possibles
     * @param jugada combinació jugada anteriorment
     * @param avaluacions diccionari d'avaluacions - conjunt de combinacions
     * @return nova llista de combinacions possibles atenent als criteris esmentats anteriorment
     */
    private List<List<Integer>> generarPossibles(List<List<Integer>> possibles, List<Integer> jugada, Map<String,
            Set<List<Integer>>> avaluacions) {
        List<List<Integer>> novesCombinacions = new ArrayList<>();
        for (List<Integer> combinacio : possibles) {
            String clave = generaClauAvaluacio(jugada, combinacio);
            if (avaluacions.containsKey(clave)) {
                novesCombinacions.addAll(avaluacions.get(clave));
            }
        }
        return novesCombinacions;
    }
}
