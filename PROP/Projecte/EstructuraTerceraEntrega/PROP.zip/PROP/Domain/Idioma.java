package Domain;
/**
 * Classe Idioma
 *
 * Representa els diferents idiomes de l'aplicació
 *
 * @author Albert Bausili Fernández
 */
public enum Idioma {
    catala,
    espanyol,
    angles,
    alemany,
    frances
}