package Domain.Usuari;

import Domain.Dificultat;

import java.io.Serializable;
import java.util.Date;
import static Domain.Dificultat.*;


/**
 * Classe Estadístiques
 * Conté les funcions i les estructures de dades per a mantenir i actualitzar les estadístiques de l'usuari
 *
 * @author Albert Bausili Fernández
 */
public class Estadistiques implements Serializable {
    private int eid;
    private int partidesGuanyadesFacil;
    private int partidesGuanyadesIntermig;
    private int partidesGuanyadesDificil;
    private int partidesPerdudesFacil;
    private int partidesPerdudesIntermig;
    private int partidesPerdudesDificil;
    private int tempsTotalJugatFacil;
    private int tempsTotalJugatIntermig;
    private int tempsTotalJugatDificil;
    private int duracioPromigFacil;
    private int duracioPromigIntermig;
    private int duracioPromigDificil;
    private int millorPuntuacioFacil;
    private int millorPuntuacioIntermig;
    private int millorPuntuacioDificil;
    private int puntuacioPromigFacil;
    private int puntuacioPromigIntermig;
    private int puntuacioPromigDificil;
    private Date creacioCompte;

    /**
     * Crea un nou set d'estadístiques per a l'usuari amb identificador igual a id i ho inicialitza totes les variables.
     * Cost: O(1) en tots els casos
     * @param id Identificador de les estadístiques
     */
    Estadistiques(int id) {
        eid = id;
        partidesGuanyadesFacil = 0;
        partidesGuanyadesIntermig = 0;
        partidesGuanyadesDificil = 0;
        partidesPerdudesFacil = 0;
        partidesPerdudesIntermig = 0;
        partidesPerdudesDificil = 0;
        tempsTotalJugatFacil = 0;
        tempsTotalJugatIntermig = 0;
        tempsTotalJugatDificil = 0;
        duracioPromigFacil = 0;
        duracioPromigIntermig = 0;
        duracioPromigDificil = 0;
        millorPuntuacioFacil = 0;
        millorPuntuacioIntermig = 0;
        millorPuntuacioDificil = 0;
        puntuacioPromigFacil = 0;
        puntuacioPromigIntermig = 0;
        puntuacioPromigDificil = 0;
        creacioCompte = new Date();
    }

    /**
     * Creadora utilitzada en la persistencia, es defineixen tots els parametres
     * Cost: O(1) en tots els casos
     * @param id Identificador de les estadistiques a recuperar
     * @param estats Array amb els valors de totes les estadistiques
     * @param data Data de creació del compte del usuari
     */
    public Estadistiques(int id, Integer[] estats, Date data) {
        eid = id;
        partidesGuanyadesFacil = estats[0];
        partidesGuanyadesIntermig = estats[1];
        partidesGuanyadesDificil = estats[2];
        partidesPerdudesFacil = estats[3];
        partidesPerdudesIntermig = estats[4];
        partidesPerdudesDificil = estats[5];
        tempsTotalJugatFacil = estats[6];
        tempsTotalJugatIntermig = estats[7];
        tempsTotalJugatDificil = estats[8];
        duracioPromigFacil = estats[9];
        duracioPromigIntermig = estats[10];
        duracioPromigDificil = estats[11];
        millorPuntuacioFacil = estats[12];
        millorPuntuacioIntermig = estats[13];
        millorPuntuacioDificil = estats[14];
        puntuacioPromigFacil = estats[15];
        puntuacioPromigIntermig = estats[16];
        puntuacioPromigDificil = estats[17];
        creacioCompte = data;
    }

    /**
     * Actualitza les estadístiques de l'usuari afegint els seus últims resultats
     * Cost: O(1) en tots els casos
     * @param resultat Es tracta d'un array d'ints que conté: int [{1(facil),2(intermig),3(difícil)}, {0(perdut),1(guanyat)},{numero de  segons},{puntuació}]
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     * @exception IllegalArgumentException Argument resultat[0] conté un valor invàlid
     */
    void actualitzarEstadistiques (int[] resultat) {
        switch (resultat[0]) {
            case 1:
                try {
                    if (resultat[1] == 1) ++partidesGuanyadesFacil;
                    else ++partidesPerdudesFacil;
                    tempsTotalJugatFacil += resultat[2];
                    duracioPromigFacil = ((duracioPromigFacil * (partidesGuanyadesFacil + partidesPerdudesFacil - 1)) + resultat[2]) / (partidesGuanyadesFacil + partidesPerdudesFacil);
                    if (resultat[3] > millorPuntuacioFacil) millorPuntuacioFacil = resultat[3];
                    puntuacioPromigFacil = ((puntuacioPromigFacil * (partidesGuanyadesFacil + partidesPerdudesFacil - 1)) + resultat[2]) / (partidesGuanyadesFacil + partidesPerdudesFacil);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            break;
            case 2:
                try {
                    if (resultat[1] == 1) ++partidesGuanyadesIntermig;
                    else ++partidesPerdudesIntermig;
                    tempsTotalJugatIntermig += resultat[2];
                    duracioPromigIntermig = ((duracioPromigIntermig * (partidesGuanyadesIntermig + partidesPerdudesIntermig - 1)) + resultat[2]) / (partidesGuanyadesIntermig + partidesPerdudesIntermig);
                    if (resultat[3] > millorPuntuacioIntermig) millorPuntuacioIntermig = resultat[3];
                    puntuacioPromigFacil = ((puntuacioPromigFacil * (partidesGuanyadesIntermig + partidesPerdudesIntermig - 1)) + resultat[2]) / (partidesGuanyadesIntermig + partidesPerdudesIntermig);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            break;
            case 3:
                try {
                    if (resultat[1] == 1) ++partidesGuanyadesDificil;
                    else ++partidesPerdudesDificil;
                    tempsTotalJugatDificil += resultat[2];
                    duracioPromigDificil = ((duracioPromigDificil * (partidesGuanyadesDificil + partidesPerdudesDificil - 1)) + resultat[2]) / (partidesGuanyadesDificil + partidesPerdudesDificil);
                    if (resultat[3] > millorPuntuacioDificil) millorPuntuacioDificil = resultat[3];
                    puntuacioPromigFacil = ((puntuacioPromigFacil * (partidesGuanyadesDificil + partidesPerdudesDificil - 1)) + resultat[2]) / (partidesGuanyadesDificil + partidesPerdudesDificil);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            break;
            default:
                throw new IllegalArgumentException("Argument resultat[0] conté un valor invalid");
        }
    }

    /**
     * Obté totes les estadístiques de l'usuari
     * Cost: O(1) en tots els casos
     * @return Retorna totes les estadístiques del usuari en forma d'array de ints
     */
    int[] getEstadistiques () {
        int[] estadistiques = new int[18];
        estadistiques[0] = partidesGuanyadesFacil;
        estadistiques[1] = partidesGuanyadesIntermig;
        estadistiques[2] = partidesGuanyadesDificil;
        estadistiques[3] = partidesPerdudesFacil;
        estadistiques[4] = partidesPerdudesIntermig;
        estadistiques[5] = partidesPerdudesDificil;
        estadistiques[6] = tempsTotalJugatFacil;
        estadistiques[7] = tempsTotalJugatIntermig;
        estadistiques[8] = tempsTotalJugatDificil;
        estadistiques[9] = duracioPromigFacil;
        estadistiques[10] = duracioPromigIntermig;
        estadistiques[11] = duracioPromigDificil;
        estadistiques[12] = millorPuntuacioFacil;
        estadistiques[13] = millorPuntuacioIntermig;
        estadistiques[14] = millorPuntuacioDificil;
        estadistiques[15] = puntuacioPromigFacil;
        estadistiques[16] = puntuacioPromigIntermig;
        estadistiques[17] = puntuacioPromigDificil;
        return estadistiques;
    }

    /**
     * Retorna la data/temps de creació del compte de l'usuari
     * Cost: O(1) en tots els casos
     * @return Retorna un "Date" de la creació del compte de l'usuari
     */
    Date getCreacioCompte () {
        return creacioCompte;
    }

    /**
     * Retorna el rati de victories del usuari per la dificultat demanada
     * Cost: O(1) en tots els casos
     * @param diff és la dificultat per la que volem saber el rati de victories del usuari
     * @return un float amb el rati de victories de l'usuari
     * @exception IllegalArgumentException L'argument diff conté un valor erroni
     */
    float getRatiVictories (Dificultat diff) {
        float result = 0;
        if (diff.equals(facil)) {
            if (partidesPerdudesFacil == 0 && partidesGuanyadesFacil > 0) result = 1;
            else if (partidesGuanyadesFacil == 0) result = 0;
            else result = Integer.valueOf(partidesGuanyadesFacil).floatValue() / Integer.valueOf(partidesPerdudesFacil).floatValue();
        }
        else if (diff.equals(intermig)) {
            if (partidesPerdudesIntermig == 0 && partidesGuanyadesIntermig > 0) result = 1;
            else if (partidesGuanyadesIntermig == 0) result = 0;
            else result = Integer.valueOf(partidesGuanyadesIntermig).floatValue() / Integer.valueOf(partidesPerdudesIntermig).floatValue();
        }
        else if (diff.equals(dificil)) {
            if (partidesPerdudesDificil == 0 && partidesGuanyadesDificil > 0) result = 1;
            else if (partidesGuanyadesDificil == 0) result = 0;
            else result = Integer.valueOf(partidesGuanyadesDificil).floatValue() / Integer.valueOf(partidesPerdudesDificil).floatValue();
        }
        else {
            throw new IllegalArgumentException("L'argument diff conté un valor erroni");
        }
        return result;
    }

    /**
     * Retorna un boolean indicant si l'usuari ha realitzat ja alguna partida per la dificultat introduïda o no
     * Cost: O(1) en tots els casos
     * @param diff És la dificultat per la qual volem saber si l'usuari ha realitzat alguna partida o no
     * @return Retorna un boleà indicant si l'usuari ha realitzat alguna partida o no en la dificultat diff
     * @exception IllegalArgumentException L'argument diff conté un valor erroni
     */
    boolean getPrimeraPartida (Dificultat diff) {
        boolean primeraPartida = false;
        if (diff.equals(facil)) {
            if (tempsTotalJugatFacil == 0) primeraPartida = true;
        }
        else if (diff.equals(intermig)) {
            if (tempsTotalJugatIntermig == 0) primeraPartida = true;
        }
        else if (diff.equals(dificil)) {
            if (tempsTotalJugatDificil == 0) primeraPartida = true;
        }
        else {
            throw new IllegalArgumentException("L'argument diff conté un valor erroni");
        }
        return primeraPartida;
    }
}
