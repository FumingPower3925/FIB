package Domain.Usuari;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Classe Historial
 * Conté informació de l'historial de partides jugades pels usuaris registrats en el sistema
 *
 * @author Albert Bausili Fernández
 */
public class Historial implements Serializable{
    private final int hid;
    private final ArrayList<Integer> partides;

    /**
     * Crea un nou historial amb els paràmetres demanats, i a resta per defecte
     * Cost: O(1) en tots els casos
     * @param id id que farem servir per identificar el nou historial que crearem
     */
    Historial(int id) {
        hid = id;
        partides = new ArrayList<>();
    }

    /**
     * Crea un nou historial amb partides ja afegides (o no), s'utilitza a persistencia
     * Cost: O(1) en tots els casos
     * @param id Identificador del historial que volem retornar
     * @param hist Arraylist amb els identificadors dels resultats jugats per l'usuari
     */
    public Historial(int id, ArrayList<Integer> hist) {
        hid = id;
        partides = hist;
    }

    /**
     * Obtenim l'identificador de l'historial
     * Cost: O(1) en tots els casos
     * @return retorna el identificador del historial
     */
    int getHid () {
        return hid;
    }

    /**
     * Obtenim el llistat de partides jugades per l'usuari
     * Cost: O(1) en tots els casos
     *
     * @return retorna la arraylist que conté els identificadors de les partides jugades
     */
    ArrayList<Integer> getPartides () {
        return partides;
    }

    /**
     * Afegim una partida amb identificador rid a l'historial
     * @param rid conté l'identificador de la partida que volem afegir a l'historial
     */
    void afegirResultat (int rid) {
        partides.add(rid);
    }
}
