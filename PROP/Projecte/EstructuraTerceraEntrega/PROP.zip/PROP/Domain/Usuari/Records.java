package Domain.Usuari;

import Domain.Pair;

import java.io.Serializable;
import java.util.ArrayList;

import static java.util.Arrays.fill;

/**
 * Classe Records
 * Conté els récords de l'usuari
 *
 * @author Sergio Delgado Ampudia
 */
public class Records implements Serializable {

    private int recid;
    private int[] records;
    private static final int SALTS = 3;
    private static final int GUANYAT = 1;
    private static final int ENTRENAMENT = 1;
    private static final int COMPLERT = 1;

    /**
     * Crea un nou set de récords per a l'usuari amb identificador igual a id i inicialitza totes les variables
     * Cost: O(1) en tots els casos
     * records[0] jugaPrimerCop
     * records[1] jugaPrimerCopRanquejada
     * records[2] jugaPartidaFacilEntrenament
     * records[3] jugaPartidaIntermitjaEntrenament
     * records[4] jugaPartidaDificilEntrenament
     * records[5] guanyaPartidaFacilEntrenament
     * records[6] guanyaPartidaIntermitjaEntrenament
     * records[7] guanyaPartidaDificilEntrenament
     * records[8] jugaPartidaFacilRanquejada
     * records[9] jugaPartidaIntermitjaRanquejada
     * records[10] jugaPartidaDificilRanquejada
     * records[11] guanyaPartidaFacilRanquejada
     * records[12] guanyaPartidaIntermitjaRanquejada
     * records[13] guanyaPartidaDificilRanquejada
     * records[14] juga5PartidaFacilEntrenament
     * records[15] juga5PartidaIntermitjaEntrenament
     * records[16] juga5PartidaDificilEntrenament
     * records[17] guanya5PartidaFacilEntrenament
     * records[18] guanya5PartidaIntermitjaEntrenament
     * records[19] guanya5PartidaDificilEntrenament
     * records[20] juga5PartidaFacilRanquejada
     * records[21] juga5PartidaIntermitjaRanquejada
     * records[22] juga5PartidaDificilRanquejada
     * records[23] guanya5PartidaFacilRanquejada
     * records[24] guanya5PartidaIntermitjaRanquejada
     * records[25] guanya5PartidaDificilRanquejada
     * records[26] guanyaPartidaFacilEntrenament5rondes
     * records[27] guanyaPartidaIntermitjaEntrenament5rondes
     * records[28] guanyaPartidaDificilEntrenament5rondes
     * records[29] guanyaPartidaFacilRanquejada5rondes
     * records[30] guanyaPartidaIntermitjaRanquejada5rondes
     * records[31] guanyaPartidaDificilRanquejada5rondes
     * @param id Identificador del record
     */
    Records(int id) {
        recid = id;
        records = new int[32];
        fill(records, 0);
    }

    /**
     * Crea un objecte record amb tot definit, s'utilitza a paersistencia
     * @param id Identificador dels records que volem recuperar
     * @param rec Array dels valors dels records que volem recuperar
     */
    public Records(int id, int[] rec) {
        recid = id;
        records = rec;
    }

    /**
     * Actualitza els récords de l'usuari comprovant si ha realitzat algun en la seva última partida
     * Cost: O(1) en tots els casos
     * @param resultat Array de ints que representen: [{Guanyat:1, Perdut:0},{numRondesUsuari},{Ranquejada:0, Entrenament:1},{Facil:1, Intermig:2, Difícil:3}]
     */
    void actualitzarRecords (int[] resultat) {
        int posicio = 0;
        if (resultat[2] == ENTRENAMENT) {
            records[posicio] += COMPLERT;
            ++posicio;
        }
        else {
            ++posicio;
            records[posicio] += COMPLERT;
        }

        posicio = posicio + resultat[3] + SALTS-(resultat[2]*SALTS);
        ++records[posicio];
        posicio += SALTS;
        if (resultat[0] == GUANYAT) records[posicio] += COMPLERT;
        posicio += 3*SALTS;
        if (records[posicio-3*SALTS] >= 5) records[posicio] += COMPLERT;
        posicio += SALTS;
        if (records[posicio-3*SALTS] >= 5 && resultat[0] == GUANYAT) records[posicio] += COMPLERT;
        if (resultat[2] == ENTRENAMENT) posicio += 4*SALTS;
        else posicio += 2*SALTS;
        if (resultat[1] <= 5 && resultat[0] == GUANYAT) records[posicio] += COMPLERT;
    }

    /**
     * Retorna el llistat de records en forma de integer
     * @return Retorna un array de integrs amb els valors del diferents records
     */
    int[] getRecords() {
        return records;
    }

    /**
     * Reenvia els records que l'usuari ha completat i no ha completat amb la seva descripció
     * @return ArrayList que conté els records amb el text i un booleà indicant si l'usuari els ha assolit o no
     */
    ArrayList<Pair<String, Boolean>> retornaRecords () {
        ArrayList<Pair<String, Boolean>> llistaRecords = new ArrayList<>();

        llistaRecords.add(new Pair<>("Juga per primer cop", records[0] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga per primer cop una partida ranked", records[1] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga una partida en dificultat fàcil en el mode d'entrenament", records[2] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga una partida en dificultat intermitja en el mode d'entrenament", records[3] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga una partida en dificultat difícil en el mode d'entrenament", records[4] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dficultat fàcil en el mode d'entrenament", records[5] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dficultat intermitja en el mode d'entrenament", records[6] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dficultat difícil en el mode d'entrenament", records[7] >= COMPLERT));

        llistaRecords.add(new Pair<>("Juga una partida en dificultat fàcil en el mode ranked", records[8] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga una partida en dificultat intermitja en el mode ranked", records[9] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga una partida en dificultat difícil en el mode ranked", records[10] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dificultat fàcil en el mode ranked", records[11] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dificultat intermitja en el mode ranked", records[12] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dificultat difícil en el mode ranked", records[13] >= COMPLERT));

        llistaRecords.add(new Pair<>("Juga 5 partides en dificultat fàcil en el mode d'entrenament", records[14] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga 5 partides en dificultat intermitja en el mode d'entrenament", records[15] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga 5 partides en dificultat difícil en el mode d'entrenament", records[16] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya 5 partides en dificultat fàcil en el mode d'entrenament", records[17] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya 5 partides en dificultat intermitja en el mode d'entrenament", records[18] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya 5 partides en dificultat difícil en el mode d'entrenament", records[19] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga 5 partides en dificultat fàcil en el mode ranked", records[20] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga 5 partides en dificultat intermitja en el mode ranked", records[21] >= COMPLERT));
        llistaRecords.add(new Pair<>("Juga 5 partides en dificultat difícil en el mode ranked", records[22] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya 5 partides en dificultat fàcil en el mode ranked", records[23] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya 5 partides en dificultat intermitja en el mode ranked", records[24] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya 5 partides en dificultat difícil en el mode ranked", records[25] >= COMPLERT));

        llistaRecords.add(new Pair<>("Guanya una partida en dificultat fàcil en el mode d'entrenament en menys de 5 rondes", records[26] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dificultat intermitja en el mode d'entrenament en menys de 5 rondes", records[27] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dificultat difícil en el mode d'entrenament en menys de 5 rondes", records[28] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dificultat fàcil en el mode ranked en menys de 5 rondes", records[29] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dificultat intermitja en el mode ranked en menys de 5 rondes", records[30] >= COMPLERT));
        llistaRecords.add(new Pair<>("Guanya una partida en dificultat difícil en el mode ranked en menys de 5 rondes", records[31] >= COMPLERT));

        return llistaRecords;
    }
}