package Domain;

import java.io.Serializable;

/**
 * Classe Pair
 *
 * Dona la posibilitat de tenir una estructura de dades amb dos elements
 *
 * @author Sergio Delgado Ampudia
 */
public class Pair<K, V> implements Serializable {

    private final K key;
    private final V value;

    /**
     * Crea un nou pair amb els parametres demanats
     * Cost: O(1)
     * @param key que sera el primer element de la parella
     * @param value que ser el segon element de la parella
     */
    public Pair(K key, V value) {
        this.key = key;
        this.value = value;
    }

    /**
     * Obtenim el primer element de la parella
     * Cost: O(1)
     * @return la key de la parella
     */
    public K getKey() {
        return key;
    }

    /**
     * Obtenim el segon element de la parella
     * Cost: O(1)
     * @return el value de la parella
     */
    public V getValue() {
        return value;
    }

    /**
     * Obtenim els dos valors de la parella.
     * Cost: O(1)
     * @return key y value de la parella
     */
    @Override
    public String toString() {
        return "(" + key + ", " + value + ")";
    }
}