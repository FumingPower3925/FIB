/*
package Domain.Ranquing;

import Domain.Dificultat;
import org.junit.Test;

import static org.junit.Assert.*;

public class RanquingPartidesTest {

    @Test
    public void getDificultat() {
        RanquingPartides ranquingPartides = new RanquingPartides(Dificultat.facil);
        assertEquals(Dificultat.facil, ranquingPartides.getDificultat());
    }

    @Test
    public void getRanquingPartides() {
    }

    @Test
    public void afegirRanquingPartides() {
    }
}

 */