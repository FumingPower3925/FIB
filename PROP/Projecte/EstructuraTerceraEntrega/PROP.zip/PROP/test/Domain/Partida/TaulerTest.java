/*package Domain.Partida;

import org.junit.Test;

import static org.junit.Assert.*;

public class TaulerTest {

    @Test
    public void getTid() {
    }

    @Test
    public void getNfiles() {
    }

    @Test
    public void getNcolumnes() {
    }

    @Test
    public void getNcolors() {
    }

    @Test
    public void getTauler() {
    }

    @Test
    public void comprovarCodi() {
    }

    @Test
    public void setCode() {
    }

    @Test
    public void obteFitxesColors() {
    }
}*/