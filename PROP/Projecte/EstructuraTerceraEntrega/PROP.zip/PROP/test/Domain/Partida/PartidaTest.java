/*package Domain.Partida;

import Domain.Dificultat;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PartidaTest {
    @Test
    public void getPid() {

        /*Partida p1 = new Partida(0, Dificultat.facil, TipusPartida.entrenament, MaquinaF);
        assertEquals(0, Dificultat.facil, TipusPartida.entrenament, );
        Partida p2 = new Partida(1, Dificultat.intermig, TipusPartida.ranked, );
        assertEquals(1, Dificultat.intermig, TipusPartida.ranked, );
        Partida p3 = new Partida(2, Dificultat.dificil, TipusPartida.ranked, );
        assertEquals(2, Dificultat.dificil, TipusPartida.ranked, );
        Partida p4 = new Partida(3, Dificultat.dificil, TipusPartida.ranked, );
        assertEquals(3, Dificultat.dificil, TipusPartida.ranked, );
        Partida p5 = new Partida(4, Dificultat.facil, TipusPartida.ranked, );
        assertEquals(4, Dificultat.facil, TipusPartida.ranked, );
        Partida p6 = new Partida(-1, Dificultat.intermig, TipusPartida.entrenament, );
        assertEquals(-1, Dificultat.intermig, TipusPartida.entrenament, );
        Partida p7 = new Partida(-1000, Dificultat.intermig, TipusPartida.entrenament, );
        assertEquals(-1000, Dificultat.intermig, TipusPartida.entrenament, );
    }
    @Test
    public void getDificultat() {
        Partida p1 = new Partida(0, Dificultat.facil, TipusPartida.entrenament, MaquinaF);

    }
    @Test
    public void getTipusPartida() {
    }
    @Test
    public void getUsatAjuda() {
    }
    @Test
    public void getRondesIA() {
    }
    @Test
    public void getRondesUsuari() {
    }
    @Test
    public void getTempsPartida() {
    }
    @Test
    public void getTornIA() {
    }
    @Test
    public void getTempsInici() {
    }
    @Test
    public void getPuntuacio() {
    }
    @Test
    public void setUsatAjuda() {
    }
    @Test
    public void setIniciPartida() {
    }
    @Test
    public void setTornIA() {
    }
    @Test
    public void incRondesIA() {
    }
    @Test
    public void incRondesUsuari() {
    }
    @Test
    public void incTempsPartida() {
    }
    @Test
    public void calcularPuntuacio() {
    }
    @Test
    public void intentsMaquina() {
    }
}*/