/*package Domain.Partida;

import org.junit.Test;

import java.time.Duration;
import java.time.LocalDateTime;

import static org.junit.Assert.*;

public class ResultatTest {

    @Test
    public void getTipusPartida() {
        LocalDateTime tempsInici = LocalDateTime.now();
        Duration temps = Duration.ofSeconds(100);
        Resultat resultat1 = new Resultat(1,TipusPartida.ranked, (byte) 5, (byte) 4, tempsInici,temps, 1000);
        assertEquals(TipusPartida.ranked,resultat1.getTipusPartida());
    }

    @Test
    public void getRondesUsuari() {
        LocalDateTime tempsInici = LocalDateTime.now();
        Duration temps = Duration.ofSeconds(100);
        Resultat resultat1 = new Resultat(1,TipusPartida.ranked, (byte) 5, (byte) 4, tempsInici,temps, 1000);
        assertEquals(5,resultat1.getRondesUsuari());
    }

    @Test
    public void getRondesIA() {
        LocalDateTime tempsInici = LocalDateTime.now();
        Duration temps = Duration.ofSeconds(100);
        Resultat resultat1 = new Resultat(1,TipusPartida.ranked, (byte) 5, (byte) 4, tempsInici,temps, 1000);
        assertEquals(4,resultat1.getRondesIA());
    }

    @Test
    public void getTempsInici() {
        LocalDateTime tempsInici = LocalDateTime.now();
        Duration temps = Duration.ofSeconds(100);
        Resultat resultat1 = new Resultat(1,TipusPartida.ranked, (byte) 5, (byte) 4, tempsInici,temps, 1000);
        assertEquals(tempsInici,resultat1.getTempsInici());
    }

    @Test
    public void getTemps() {
        LocalDateTime tempsInici = LocalDateTime.now();
        Duration temps = Duration.ofSeconds(100);
        Resultat resultat1 = new Resultat(1,TipusPartida.ranked, (byte) 5, (byte) 4, tempsInici,temps, 1000);
        assertEquals(temps,resultat1.getTemps());
    }

    @Test
    public void getPuntuacio() {
        LocalDateTime tempsInici = LocalDateTime.now();
        Duration temps = Duration.ofSeconds(100);
        Resultat resultat1 = new Resultat(1,TipusPartida.ranked, (byte) 5, (byte) 4, tempsInici,temps, 1000);
        assertEquals(1000,resultat1.getPuntuacio());
    }
}*/