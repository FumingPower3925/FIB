/*package Domain.Usuari;

import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class UsuariTest  {


    @Test
    public void getUid() {
    }

    @Test
    public void getNom() {
        Usuari user1 = new Usuari(1,"Juan","1234");
        assertEquals("Juan",user1.getNom());

        Usuari user2 = new Usuari(2,"","1234");
        assertEquals("",user2.getNom());

        Usuari user3 = new Usuari(3,"1234","Juan");
        assertEquals("1234",user3.getNom());

        Usuari user4 = new Usuari(4,"1234","Juan");
        assertEquals("1234",user4.getNom());
    }

    @Test
    public void getContrasenya() {
    }

    @Test
    public void getTePartidaPausada() {
    }

    @Test
    public void getEsborrat() {
    }

    @Test
    public void getIdiomaPreferit() {
    }

    @Test
    public void setNom() {
    }

    @Test
    public void setContrasenya() {
    }

    @Test
    public void setTePartidaPausada() {
    }

    @Test
    public void setEsborrat() {
    }

    @Test
    public void setIdioma() {
    }
}*/