/*package Domain.Usuari;

import org.junit.Test;
public class EstadistiquesTest {

    @Test
    void actualitzarEstadistiques () {
    }

    @Test
    void getEstadistiques () {
    }

    @Test
    void getCreacioCompte () {
    }

    @Test
    void getRatiVictories () {
    }

    @Test
    void getPrimeraPartida () {
    }

}*/
