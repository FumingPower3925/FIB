package Persistencia;

import Domain.Idioma;
import Domain.Pair;
import Domain.Quartet;
import Domain.Usuari.Estadistiques;
import Domain.Usuari.Historial;
import Domain.Usuari.Records;
import Domain.Usuari.Usuari;

import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Classe PersistenciaUsuaris
 * Conté les funcions per a guardar i recuperar les dades dels usuaris aixi com de la llista d'aquests
 *
 * @author Albert Bausili Fernández
 */
public class PersistenciaUsuaris  {

    /**
     * Guarda en un fitxer txt de la forma "uid".txt l'usuari, les estadistiques, els records i el seu historial, si ja existeix el sobrescriu
     * Cost: O(1) en tots els casos
     * @param usr Dades necessaries del objecte usuari per poder-lo reconstruir
     * @param est Dades necessaries del objecte estadístiques per poder-lo reconstruir
     * @param rec Dades necessaries del objecte records per poder-lo reconstruir
     * @param hist Dades necessaries del objecte historial per poder-lo reconstruir
     */
    public static void guardarUsuari(Pair<Integer, Quartet<String[], Integer, Boolean, Idioma>> usr, Pair<Integer[], Date> est, int[] rec, ArrayList<Integer> hist) {
        Usuari usuari = new Usuari(usr.getKey(), usr.getValue().getPrimer()[0], usr.getValue().getPrimer()[1], usr.getValue().getSegon(), usr.getValue().getTercer(), usr.getValue().getQuart());
        Estadistiques estadistiques = new Estadistiques(usr.getKey(), est.getKey(), est.getValue());
        Records records = new Records(usr.getKey(), rec);
        Historial historial = new Historial(usr.getKey(), hist);
        try {
            FileOutputStream fileOut = new FileOutputStream("./data/usuaris/"+usr.getKey()+".txt", false);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);

            out.writeObject(usuari);
            out.writeObject(estadistiques);
            out.writeObject(records);
            out.writeObject(historial);

            out.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * Guarda en un fitxer amb el nom nomUid.txt la llista de noms relacionats amb els seus respectius uids, si ja existeix el sobrescriu
     * Cost: O(1) en tots els casos
     * @param nomUid Llista de noms/uids que volem guardar en disc
     */
    public static void guardarNomUid(HashMap<String, Integer> nomUid) {
        FileWriter ficher = null;
        PrintWriter pw;
        try
        {
            ficher = new FileWriter("./data/nomUid.txt");
            pw = new PrintWriter(ficher);

            for (String i : nomUid.keySet()) {
                pw.println(i +","+ nomUid.get(i));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != ficher)
                    ficher.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    /**
     * Llegeix del fitxer de l'usuari el seu objecte, el de les seves estadistiques, els seus records i el seu historial i ho torna en un tipus generic
     * Cost: O(1) en tots els casos
     * @param uid identificador de l'usuari del qual volem tornar els seus objectes, si no existeix retorna un error
     * @return Retorna un tipus generic del tipus Quartet que conté els objectes Usuari, Estadistiques, Records i Historial de l'usuari demanat
     */
    public static Quartet<Usuari, Estadistiques, Records, Historial> tornarUsuari(int uid) {
        Usuari usr = null;
        Estadistiques est = null;
        Records rec = null;
        Historial hist = null;
        try {
            FileInputStream fileIn = new FileInputStream("./data/usuaris/"+uid+".txt");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            usr = (Usuari) in.readObject();
            est = (Estadistiques) in.readObject();
            rec = (Records) in.readObject();
            hist = (Historial) in.readObject();
            in.close();
            fileIn.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException c) {
            System.out.println("Usuari no trobat");
            c.printStackTrace();
        }
        return new Quartet<>(usr, est, rec, hist);
    }

    /**
     * Lleigeix del fitxer de nomUid la llsita de noms amb els seus respectius identificadors
     * Cost: O(1)
     * @return Retorna un Hashmap amb els continguts de noms com a key i els seus identificadors com a value
     */
    public static HashMap<String, Integer> tornarNomUid() {
        HashMap<String, Integer> nomUid = new HashMap<>();

        File archiu;
        FileReader fr = null;
        BufferedReader br;

        try {
            archiu = new File ("./data/nomUid.txt");
            fr = new FileReader (archiu);
            br = new BufferedReader(fr);

            String linea;
            while((linea=br.readLine())!=null) {
                String[] resultat = linea.split(",");
                nomUid.putIfAbsent(resultat[0],Integer.valueOf(resultat[1]));
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }finally{
            try{
                if( null != fr ){
                    fr.close();
                }
            }catch (Exception e2){
                e2.printStackTrace();
            }
        }
        return nomUid;
    }

    /**
     * Funció per a comprovar si existeix en el disc l'arxiu nomUid o si encara no s'ha guardat mai
     * @return Torna un boleà indicant si aquest arxiu es troba a disc o no
     */
    public static boolean comprovarSiNomUid() {
        return new File("./data/nomUid.txt").exists();
    }
}
