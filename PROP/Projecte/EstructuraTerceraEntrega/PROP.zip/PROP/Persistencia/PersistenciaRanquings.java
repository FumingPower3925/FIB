package Persistencia;

import Domain.Dificultat;
import Domain.Pair;
import Domain.Ranquing.RanquingPartides;
import Domain.Ranquing.RanquingUsuaris;

import java.io.*;
import java.util.LinkedList;

/**
 * Classe PersistenciaRanquings
 * Conté les funcions per a guardar i recuperar les dades dels ranquings d'usuaris i de partides
 *
 * @author Albert Bausili Fernández
 */
public class PersistenciaRanquings {

    /**
     * Guarda en un fitxer txt de la forma Usuaris_"dif".txt el ranquing d'usuaris per la dificultat dif, si ja existeix el sobreescriu
     * Cost:
     * @param ranq Informació necessaria per a poder construir el objecte ranquing Usuaris
     * @param dif Dificultat del ranquing d'usuaris que volem guardar
     */
    public static void guardarRanquingUsuaris(LinkedList<Pair<Float, Integer>> ranq, Dificultat dif) {
        RanquingUsuaris ru = new RanquingUsuaris(ranq, dif);
        try {
            FileOutputStream fileOut = new FileOutputStream("./data/ranquings/Usuaris_"+dif+".txt", false);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);

            out.writeObject(ru);

            out.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Guarda en un fitxer txt de la forma Partides_"dif".txt el ranquing de partides per la dificultat dif, si ja existeix el sobreescriu
     * Cost:
     * @param ranq Informació necessaria per a poder construir el objecte ranquing Partides
     * @param dif Dificultat del ranquing de partides que volem guardar
     */
    public static void guardarRanquingPartides(LinkedList<Pair<Integer, Integer>> ranq, Dificultat dif) {
        RanquingPartides rp = new RanquingPartides(ranq, dif);
        try {
            FileOutputStream fileOut = new FileOutputStream("./data/ranquings/Partides_"+dif+".txt", false);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);

            out.writeObject(rp);

            out.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Recupera del disc el ranquing d'usuaris de la dificultat dif
     * Cost:
     * @param dif Indica la dificultat per la que volem tornar el ranquing
     * @return Retorna el ranquing d'usuaris per la dificultat dif
     */
    public static RanquingUsuaris tornarRanquingUsuaris(Dificultat dif) {
        RanquingUsuaris ru = null;
        try {
            FileInputStream fileIn = new FileInputStream("./data/ranquings/Usuaris_"+dif+".txt");
            ObjectInputStream in = new ObjectInputStream(fileIn);

            ru = (RanquingUsuaris) in.readObject();

            in.close();
            fileIn.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException c) {
            System.out.println("Ranquing Usuaris "+dif+" no trobat");
            c.printStackTrace();
        }
        return ru;
    }

    /**
     * Recupera del disc el ranquing de partides de la dificultat dif
     * Cost:
     * @param dif Indica la dificultat per la que volem tornar el ranquing
     * @return Retorna el ranquing de partides corresponent a la dificultat dif
     */
    public static RanquingPartides tornarRanquingPartides(Dificultat dif) {
        RanquingPartides rp = null;
        try {
            FileInputStream fileIn = new FileInputStream("./data/ranquings/Partides_"+dif+".txt");
            ObjectInputStream in = new ObjectInputStream(fileIn);

            rp = (RanquingPartides) in.readObject();

            in.close();
            fileIn.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException c) {
            System.out.println("Ranquing Partides "+dif+" no trobat");
            c.printStackTrace();
        }
        return rp;
    }

    /**
     * Funcio per a comprovar si existeix en disc algun dels ranquings en concret
     * @param usuaris Es true si el ranquing del que volem saber la informació es d'usuaris, fals en cas contrari
     * @param dif Es la dificultat del ranquing del que volem saber si existeix
     * @return Torna un boleà indicant si aquest arxiu es troba a disc o no
     */
    public static boolean comprovarSiRanquing (Boolean usuaris, Dificultat dif) {
        if (usuaris) {
            return new File("./data/ranquings/Usuaris_"+dif+".txt").exists();
        }
        return new File("./data/ranquings/Partides_"+dif+".txt").exists();
    }
}
