package Persistencia;

import Domain.Dificultat;


import Domain.Pair;
import Domain.Partida.*;
import Domain.Quartet;

import java.io.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Set;

/**
 * Classe PersistenciaPartida
 * Conté les funcions per a guardar i recuperar les dades de les partides i resultats del usuaris
 *
 * @author Albert Bausili Fernández
 */
public class PersistenciaPartida {

    /**
     * Guarda en un fitxer txt de la forma "pid".txt les dades de partida i tauler
     * Cost: O(1) en tots els casos
     * @param part Dades necessaries del objecte partida per poder-lo reconstruir
     * @param tulr Dades necessaries del objecte tauler per poder-lo reconstruir
     */
    public static void guardarPartida(Quartet<Integer, Dificultat, TipusPartida, Boolean> part, int[] tulr) {
        Maquina maquina = null;
        if (part.getQuart()) maquina = new MaquinaFiveGuess(tulr[3], tulr[1]);
        else maquina = new MaquinaGenetic(tulr[3], tulr[1]);
        Partida partida = new Partida(part.getPrimer(), part.getSegon(), part.getTercer(), maquina);
        Tauler tauler = new Tauler(tulr[0], tulr[1], tulr[2], tulr[3]);
        try {
            FileOutputStream fileOut = new FileOutputStream("./data/partides/"+part.getPrimer()+".txt", false);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);

            out.writeObject(partida);
            out.writeObject(tauler);

            out.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Llegeix del fitxer de la partida el objecte partida i tauler i els torna
     * Cost: O(1) en tots els casos
     * @param pid identificador de la partida de la que volem tornar els objectes
     * @return Retorna un tipus generic del tipus Pair que conté els dos objectes Partida i Tauler
     */
    public static Pair<Partida, Tauler> tornarPartida(int pid) {
        Partida partida = null;
        Tauler tauler = null;
        try {
            FileInputStream fileIn = new FileInputStream("./data/partides/"+pid+".txt");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            partida = (Partida) in.readObject();
            tauler = (Tauler) in.readObject();
            in.close();
            fileIn.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException c) {
            System.out.println("Usuari no trobat");
            c.printStackTrace();
        }
        return new Pair<>(partida, tauler);
    }

    /**
     * Guarda en un fitxer amb el nom maxpartides.txt l'identificador mes gran fins el moment
     * Cost: O(1) en tots els casos
     * @param pid Identificador de la partida mes alta
     */
    public static void guardarMaxPartides(int pid) {
        try {
            FileOutputStream fileOut = new FileOutputStream("./data/partides/maxpartides.txt", false);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);

            out.writeObject(pid);

            out.close();
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Retorna el identificador mes gran fins el moment
     * Cost: O(1) en tots els casos
     * @return Retorna un integer amb el valor d'indentificador mes alt
     */
    public static int tornarMaxPartides() {
        int maxpartides = -1;
        try {
            FileInputStream fileIn = new FileInputStream("./data/partides/maxpartides.txt");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            maxpartides = (int) in.readObject();
            in.close();
            fileIn.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException c) {
            System.out.println("Usuari no trobat");
            c.printStackTrace();
        }
        return maxpartides;
    }

    /**
     * Comprova si existeix el fitxer maxpartides.txt
     * Cost: O(1) en tots els casos
     * @return Retorna un boleà indicant si existeix aquest fitxer en disc o no
     */
    public static boolean existeixMaxPartides() {
        return new File("./data/partides/maxpartides.txt").exists();
    }

    /**
     * Guarda un nou resultat a la llista de resultats de persistencia
     * Cost: O(1) en tots els casos
     * @param rid identificador del resultat a guardar
     * @param res Tipus generic amb les dades necessaries per a construir l'objecte resultat
     */
    public static void guardarResultat(int rid, Quartet<TipusPartida, int[], LocalDateTime, Duration> res) {
        FileWriter ficher = null;
        PrintWriter pw;
        try
        {
            ficher = new FileWriter("./data/partides/resultats.txt");
            pw = new PrintWriter(ficher);
            String buffer = rid+","+res.getPrimer()+","+res.getSegon()[0]+","+res.getSegon()[1]+","+res.getTercer()+","+res.getQuart()+","+res.getSegon()[2];
            pw.println(buffer);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != ficher)
                    ficher.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    /**
     * Torna una llista de objectes resultat que corresponen a les ids introduïdes
     * Cost: O(n) on n es el numero de ids
     * @param ids Set que conté les ids dels identificadors del resultats que volem
     * @return Retorna un Arraylist amb els resultats demanats per el parametre
     */
    public static ArrayList<Resultat> tornarResultats(Set<Integer> ids) {
        ArrayList<Resultat> resultats = new ArrayList<>();

        File arxiu;
        FileReader fr = null;
        BufferedReader br;

        try {
            arxiu = new File ("./data/partides/resultats.txt");
            fr = new FileReader (arxiu);
            br = new BufferedReader(fr);

            String linea;
            while((linea=br.readLine())!=null) {
                String[] resultat = linea.split(",");
                if (ids.contains(Integer.valueOf(resultat[0]))) resultats.add(new Resultat(Integer.parseInt(resultat[0]), TipusPartida.valueOf(resultat[1]), Byte.parseByte(resultat[2]), Byte.parseByte(resultat[3]), LocalDateTime.parse(resultat[4]), Duration.parse(resultat[5]), Integer.parseInt(resultat[6])));
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }finally{
            try{
                if( null != fr ){
                    fr.close();
                }
            }catch (Exception e2){
                e2.printStackTrace();
            }
        }
        return resultats;
    }
}
