package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class VistaCanviarNom extends JFrame {

    private ControladorPresentacio cp;
    private JPanel panelCanviarNom;
    private JButton enrereButton;
    private JLabel nomFieldLabel;
    private JLabel confirmarNomFieldLabel;
    private JTextField nomField;
    private JTextField confirmarNomField;
    private JButton acceptarButton;
    private JLabel canviarNomLabel;

    public VistaCanviarNom(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        panelCanviarNom = new JPanel();
        panelCanviarNom.setLayout(null);

        canviarNomLabel = new JLabel(messages.getString("canviarNomButton"));
        enrereButton = new JButton(messages.getString("enrereButton"));
        nomFieldLabel = new JLabel(messages.getString("nouNomLabel"));
        confirmarNomFieldLabel = new JLabel(messages.getString("confirmarNouNomLabel"));
        acceptarButton = new JButton(messages.getString("acceptarButton"));
        nomField = new JTextField();
        confirmarNomField = new JTextField();

        canviarNomLabel.setBounds(320, 30, 200, 30);
        enrereButton.setBounds(20, 380, 100, 30);
        acceptarButton.setBounds(575, 380, 100, 30);
        nomFieldLabel.setBounds(275, 70, 300, 30);
        nomField.setBounds(275, 110, 200, 20);
        confirmarNomFieldLabel.setBounds(275, 140, 300, 30);
        confirmarNomField.setBounds(275, 180, 200, 20);

        panelCanviarNom.add(canviarNomLabel);
        panelCanviarNom.add(enrereButton);
        panelCanviarNom.add(acceptarButton);
        panelCanviarNom.add(nomFieldLabel);
        panelCanviarNom.add(nomField);
        panelCanviarNom.add(confirmarNomFieldLabel);
        panelCanviarNom.add(confirmarNomField);

        setContentPane(panelCanviarNom);

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPerfil vp = new VistaPerfil(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });

        acceptarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String username = nomField.getText();
                String confirmusername = confirmarNomField.getText();

                // Realiza la validación de los campos aquí
                if (username.isEmpty() || confirmusername.isEmpty()) {
                    JOptionPane.showMessageDialog(VistaCanviarNom.this, "Omple tots els camps", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (username.length() > cp.getMax_length() || confirmusername.length() > cp.getMax_length()) {
                    JOptionPane.showMessageDialog(VistaCanviarNom.this, "El nom d'usuari és massa llarg. El nombre màxim de caràcters és " + cp.getMax_length(), "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!username.equals(confirmusername)) {
                    JOptionPane.showMessageDialog(VistaCanviarNom.this, "Els noms d'usuari no coincideixen", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if(cp.existeixNomUsuari(username)){
                    JOptionPane.showMessageDialog(VistaCanviarNom.this, "Ja existeix un usuari amb aquest nom!", "Error", JOptionPane.ERROR_MESSAGE);
                }

                else {
                    cp.canviarNom(username);
                    VistaIniciarSessio vis = new VistaIniciarSessio(cp);
                    vis.setVisible(true);
                    setVisible(false);
                }
            }
        });
    }
}