package Presentacio;

import Domain.Dificultat;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class VistaRanquingUsuaris extends JFrame {
    private ControladorPresentacio cp;
    private JPanel panelRanquingUsuaris;
    private JButton enrereButton;
    private JComboBox dificultatComboBox;
    private JScrollPane jsp;
    private JLabel ranquingUsuarisLabel;

    public VistaRanquingUsuaris(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        panelRanquingUsuaris = new JPanel();
        panelRanquingUsuaris.setLayout(null);

        ranquingUsuarisLabel = new JLabel(messages.getString("ranquingUsuarisButton"));
        enrereButton = new JButton(messages.getString("enrereButton"));
        String[] dificultats = {"Fàcil", "Intermig", "Difícil"};
        dificultatComboBox = new JComboBox(dificultats);
        LlistaScroll h = new LlistaScroll(cp);
        jsp = new JScrollPane(h.generateList(2, Dificultat.facil));

        ranquingUsuarisLabel.setBounds(320, 30, 200, 30);
        enrereButton.setBounds(20, 380, 100, 30);
        dificultatComboBox.setBounds(600, 320, 100, 30);
        jsp.setBounds(125, 100, 500, 200);

        panelRanquingUsuaris.add(ranquingUsuarisLabel);
        panelRanquingUsuaris.add(enrereButton);
        panelRanquingUsuaris.add(dificultatComboBox);
        panelRanquingUsuaris.add(jsp);

        setContentPane(panelRanquingUsuaris);

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaSeleccioRanquing vsr = new VistaSeleccioRanquing(cp);
                vsr.setVisible(true);
                setVisible(false);
            }
        });

        dificultatComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelRanquingUsuaris.remove(jsp);

                LlistaScroll h = new LlistaScroll(cp);
                jsp = new JScrollPane(h.generateList(2, getDificultatSeleccionada()));

                jsp.setBounds(125, 100, 500, 200);
                panelRanquingUsuaris.add(jsp);

                panelRanquingUsuaris.repaint();
                panelRanquingUsuaris.revalidate();
            }
        });
    }

    private Dificultat getDificultatSeleccionada() {

        Dificultat dif = Dificultat.facil;

        String difSeleccionada = (String) dificultatComboBox.getSelectedItem();
        switch (difSeleccionada) {
            case "Fàcil":
                dif = Dificultat.facil;
                break;
            case "Intermig":
                dif = Dificultat.intermig;
                break;
            case "Difícil":
                dif = Dificultat.dificil;
                break;
        }
        return dif;
    }
}