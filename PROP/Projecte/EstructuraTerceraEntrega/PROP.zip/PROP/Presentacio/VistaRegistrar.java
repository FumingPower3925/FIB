package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Classe VistaRegistrar
 * Conté els elements per renderitzar la vista de registrar
 *
 * @author David Molina Mesa
 */
public class VistaRegistrar extends JFrame {

    private ControladorPresentacio cp;
    private JPanel panelRegistrar;
    private JButton enrereButton;
    private JTextField usuariField;
    private JPasswordField contrasenyaField;
    private JPasswordField confirmarContrasenyaField;
    private JButton registraMButton;
    private JLabel confirmarContrasenyaFieldLabel;
    private JLabel usuariFieldLabel;
    private JLabel contrasenyaFieldLabel;
    private JLabel crearCompteLabel;

    /**
     * Creadora de la vista de registrar
     * Cost: O(1)
     * @param cp es el controlador de presentació
     */
    public VistaRegistrar(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    /**
     * Funció inicilitzadora dels components de la vista
     * Cost: O(1)
     */
    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));
        crearCompteLabel.setText(messages.getString("crearCompteLabel"));
        usuariFieldLabel.setText(messages.getString("usuariFieldLabel"));
        contrasenyaFieldLabel.setText(messages.getString("contrasenyaFieldLabel"));
        confirmarContrasenyaFieldLabel.setText(messages.getString("confirmarContrasenyaFieldLabel"));
        registraMButton.setText(messages.getString("registraMButton"));
        enrereButton.setText(messages.getString("enrereButton"));

        setContentPane(panelRegistrar);

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPrincipal vp = new VistaPrincipal(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });

        registraMButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String username = usuariField.getText();
                String password = new String(contrasenyaField.getPassword());
                String confirmPassword = new String(confirmarContrasenyaField.getPassword());

                // Realiza la validación de los campos aquí
                if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(VistaRegistrar.this, "Omple tots els camps", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(VistaRegistrar.this, "Les contrasenyes no coincideixen", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if(!cp.registrarUsuari(username,password)){
                    JOptionPane.showMessageDialog(VistaRegistrar.this, "Ja existeix un usuari amb aquest nom!", "Error", JOptionPane.ERROR_MESSAGE);

                }
                else {
                    VistaMenuPrincipal vmp = new VistaMenuPrincipal(cp);
                    vmp.setVisible(true);
                    setVisible(false);
                }
            }
        });
    }
}
