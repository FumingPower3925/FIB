package Presentacio;

import Domain.Partida.Colors;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.ResourceBundle;

public class VistaCodeMaker extends JFrame {
    ControladorPresentacio cp;
    private JPanel panelCodeMaker;

    private JLabel codeMakerTextLabel;
    private JLabel araEtsCodeMakerLabel;
    private JLabel resultatTornIALabel;
    private JButton netejarButton;
    private JButton confirmarSeleccioButton;
    private JButton jugarCodeBreakerButton;
    private JButton menuButton;
    private JPanel taulerPanel;
    private JPanel colorPanel;
    private JPanel[][] tauler;

    private JPanel[] inputCodi;
    private int nColors;
    private int casellesSeleccionades;
    private Colors[] colorsEscollits;
    private boolean seleccioBotonsHabilitada;
    private int filaActual;
    private int nFiles;
    private int nColumnes;
    private JPanel codiPanel;


    public VistaCodeMaker(ControladorPresentacio cp){
        this.cp = cp;
        this.casellesSeleccionades = 0;
        this.seleccioBotonsHabilitada = true;
        initComponents();
    }

    private void initComponents(){
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(920, 740);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        int[] elements = Arrays.copyOf(cp.reprenPartida(), cp.reprenPartida().length);

        panelCodeMaker = new JPanel();
        panelCodeMaker.setLayout(null);
        panelCodeMaker.setBackground(Color.darkGray);

        nFiles = elements[2];
        nColumnes= elements[3];
        nColors = elements[4];
        this.colorsEscollits = new Colors[nColumnes];
        this.filaActual = nFiles-1;

        taulerPanel = new JPanel();

        Dimension windowSize = getSize();
        int windowWidth = windowSize.width;
        int windowHeight = windowSize.height;

        int taulerWidth = nColumnes * 32;
        int taulerHeight = nFiles * 30;
        int taulerX = (windowWidth - taulerWidth) / 2;
        int taulerY = (windowHeight - taulerHeight) / 2;

        taulerPanel.setBounds(taulerX+200, taulerY-100, taulerWidth, taulerHeight);// Calcular las coordenadas del centro del tauler

        taulerPanel.setLayout(new GridLayout(nFiles, nColumnes));
        generartauler(nFiles, nColumnes);
        panelCodeMaker.add(taulerPanel);

        int colorPanelWidth = nColors * 40;
        int colorPanelHeight = 45;

        colorPanel = new JPanel();
        colorPanel.setBounds(20, 400, colorPanelWidth, colorPanelHeight);
        colorPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        colorPanel.setLayout(new GridLayout(nColors, 1));
        colorPanel.setBackground(Color.GRAY);
        generarColores(nColors);
        panelCodeMaker.add(colorPanel);

        int codiPanelWidth = nColors * 50;
        int codiPanelHeight = 60;
        codiPanel = new JPanel();
        codiPanel.setBounds(20, 320, codiPanelWidth, codiPanelHeight);
        codiPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        codiPanel.setLayout(new FlowLayout());

        codiPanel.setBackground(Color.GRAY);
        generarCodiInput(nColumnes);
        panelCodeMaker.add(codiPanel);


        araEtsCodeMakerLabel = new JLabel(messages.getString("araEtsCodeMakerLabel"));
        araEtsCodeMakerLabel.setForeground(Color.white);
        araEtsCodeMakerLabel.setBounds((windowWidth/2)-200,50,500,40);
        panelCodeMaker.add(araEtsCodeMakerLabel);

        codeMakerTextLabel = new JLabel(messages.getString("codeMakerTextLabel"));
        codeMakerTextLabel.setForeground(Color.white);
        codeMakerTextLabel.setBounds(20,270,500,40);
        panelCodeMaker.add(codeMakerTextLabel);

        netejarButton = new JButton(messages.getString("netejarButton"));
        netejarButton.setBounds(230 , 500, 100, 30);
        netejarButton.setBackground(Color.white);
        netejarButton.setForeground(Color.black);
        netejarButton.setOpaque(true);
        netejarButton.setBorderPainted(true);
        netejarButton.setBorder(BorderFactory.createLineBorder(Color.black, 2));
        netejarButton.setFocusPainted(false);
        panelCodeMaker.add(netejarButton);

        confirmarSeleccioButton = new JButton(messages.getString("confirmarSeleccioButton"));
        confirmarSeleccioButton.setBounds(20, 500, 120, 30);
        confirmarSeleccioButton.setEnabled(false);
        confirmarSeleccioButton.setBackground(Color.green);
        confirmarSeleccioButton.setForeground(Color.white);
        confirmarSeleccioButton.setOpaque(true);
        confirmarSeleccioButton.setBorderPainted(true);
        confirmarSeleccioButton.setBorder(BorderFactory.createLineBorder(Color.white, 2));
        confirmarSeleccioButton.setFocusPainted(false);
        panelCodeMaker.add(confirmarSeleccioButton);

        jugarCodeBreakerButton = new JButton(messages.getString("jugarCodeBreakerButton"));
        jugarCodeBreakerButton.setBounds(550, 600, 300, 30);
        jugarCodeBreakerButton.setEnabled(true);
        jugarCodeBreakerButton.setBackground(Color.red);
        jugarCodeBreakerButton.setForeground(Color.white);
        jugarCodeBreakerButton.setOpaque(true);
        jugarCodeBreakerButton.setBorderPainted(true);
        jugarCodeBreakerButton.setBorder(BorderFactory.createLineBorder(Color.white, 2));
        jugarCodeBreakerButton.setFocusPainted(false);
        jugarCodeBreakerButton.setVisible(false);
        panelCodeMaker.add(jugarCodeBreakerButton);

        menuButton = new JButton(messages.getString("menuButton"));
        menuButton.setBounds(20, 40, 100, 30);
        panelCodeMaker.add(menuButton);

        resultatTornIALabel = new JLabel();
        resultatTornIALabel.setBounds(600, 500, 1000, 30);
        resultatTornIALabel.setForeground(Color.white);
        panelCodeMaker.add(resultatTornIALabel);

        confirmarSeleccioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Colors[]> jugadesIA = cp.resolCodiIA(colorsEscollits);
                Colors[] ultimaJugada = jugadesIA.get(jugadesIA.size() -1);
                for (Colors[] jugada : jugadesIA) {
                    for (Colors color : jugada) {
                        System.out.print(color + " ");
                        colocarColorEnTauler(obteColorRenderitzable(color));
                    }
                    --filaActual;
                }


                confirmarSeleccioButton.setEnabled(false);

                modificaEnableBotonsColors(false);

                netejarButton.setEnabled(false);
                mostraResultatIA(Arrays.equals(ultimaJugada,colorsEscollits),jugadesIA.size());
                jugarCodeBreakerButton.setVisible(true);
            }
        });

        netejarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                netejarSeleccio();
                modificaEnableBotonsColors(true);
                confirmarSeleccioButton.setEnabled(false);
            }
        });

        jugarCodeBreakerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaCodeBreaker vp = new VistaCodeBreaker(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });

        menuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] opcions = {messages.getString("reanudarOption"),messages.getString("abandonarOption")};
                int seleccio = JOptionPane.showOptionDialog(
                        VistaCodeMaker.this,
                        "",
                        "Menu",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        opcions,
                        opcions[0]);

                switch (seleccio) {
                    case 0:
                        // no faig res
                        break;
                    case 1:
                        cp.abandonarPartida();
                        VistaMenuPrincipal vmp2 = new VistaMenuPrincipal(cp);
                        vmp2.setVisible(true);
                        setVisible(false);
                        break;
                }
            }
        });
        setContentPane(panelCodeMaker);
    }

    private void generartauler(int filas, int columnas) {
        tauler = new JPanel[filas][columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                JPanel casillaPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
                //casillaPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                casillaPanel.setBackground(Color.lightGray);
                taulerPanel.add(casillaPanel);
                tauler[i][j] = casillaPanel;
            }
        }
    }

    private void generarColores(int numColores) {
        colorPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0));
        for (int i = 0; i < numColores; i++) {
            JButton colorButton = new JButton();
            colorButton.setPreferredSize(new Dimension(30, 30));

            colorButton.setBackground(asignaColorAlBoto(numColores,i));
            colorButton.setOpaque(true);
            colorButton.setBorderPainted(false);
            colorButton.setFocusPainted(false);
            colorButton.setMargin(new Insets(0, 5, 0, 5));
            colorButton.setBorder(BorderFactory.createEmptyBorder());
            int finalI = i;
            colorButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    Color color = colorButton.getBackground();
                    colorsEscollits[casellesSeleccionades] = agafaColordeColorObject(color);
                    System.out.println("El que porto escollit : " + Arrays.toString(colorsEscollits));
                    ++casellesSeleccionades;
                    if(casellesSeleccionades == nColumnes){
                        casellesSeleccionades = 0;
                        confirmarSeleccioButton.setEnabled(true);
                        seleccioBotonsHabilitada = false;
                        modificaEnableBotonsColors(seleccioBotonsHabilitada);
                    }
                    colocarColorEnCodi(color);
                }
            });
            colorPanel.add(colorButton);
        }
    }

    private void colocarColorEnTauler(Color color) {
            for (int j = 0; j < tauler[0].length; j++) {
                JPanel casillaPanel = tauler[filaActual][j];
                if (casillaPanel.getComponentCount() == 0) {
                    JLabel colorLabel = crearColorLabel(color);
                    casillaPanel.add(colorLabel);
                    casillaPanel.revalidate();
                    casillaPanel.repaint();
                    return;
            }
        }
    }

    private void generarCodiInput(int columnes) {
        inputCodi = new JPanel[columnes];
            for (int j = 0; j < columnes; j++) {
                JPanel casillaPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
                //casillaPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                casillaPanel.setBackground(Color.lightGray);
                codiPanel.add(casillaPanel);
                inputCodi[j] = casillaPanel;
            }

    }

    private void colocarColorEnCodi(Color color) {
        for (int i = 0; i < inputCodi.length; ++i) {
                JPanel casillaPanel = inputCodi[i];
                if (casillaPanel.getComponentCount() == 0) {
                    JLabel colorLabel = crearColorLabel(color);
                    casillaPanel.add(colorLabel);
                    casillaPanel.revalidate();
                    casillaPanel.repaint();
                    return;
                }
        }
    }

    private JLabel crearColorLabel(Color color) {
        JLabel colorLabel = new JLabel();
        colorLabel.setOpaque(true);
        colorLabel.setBackground(color);
        colorLabel.setPreferredSize(new Dimension(30, 30));
        colorLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        return colorLabel;
    }

    private void netejarSeleccio() {
        casellesSeleccionades = 0;
        for (int j = 0; j < inputCodi.length; j++) {
            JPanel casillaPanel = inputCodi[j];
            casillaPanel.removeAll();
            casillaPanel.revalidate();
            casillaPanel.repaint();
        }
    }

    private void modificaEnableBotonsColors(boolean habilita){
        for (Component component : colorPanel.getComponents()) {
            if (component instanceof JButton) {
                ((JButton) component).setEnabled(habilita);
            }
        }
    }

    private void mostraResultatIA(boolean encert,int intents){
        System.out.println("ha encertat " + encert);

        if(encert){
            resultatTornIALabel.setText("La IA ha encentat en el intent " + intents);
        }
        else {
                resultatTornIALabel.setText("La IA no ha resolt el codi");
        }

    }

    private static Colors[] getAmountColors(int nColors){
        Colors[] valors = Colors.values();
        int abast = Math.min(valors.length, nColors);
        return Arrays.copyOfRange(valors, 0, abast);
    }

    private Color asignaColorAlBoto(int numColors, int indexColor) {
        Colors[] opcionsColors = getAmountColors(numColors);
        Colors colorSeleccionado = opcionsColors[indexColor];

        switch (colorSeleccionado) {
            case vermell:
                return Color.red;
            case blau:
                return Color.blue;
            case verd:
                return Color.green;
            case groc:
                return Color.yellow;
            case taronja:
                return new Color(231, 133, 28);
            case rosa:
                return Color.magenta;
            case lila:
                return new Color(148, 59, 165);
            case gris:
                return Color.gray;
            case negre:
                return Color.black;
            case blanc:
                return Color.white;
            default:
                return null;
        }
    }

    private Colors agafaColordeColorObject(Color color) {
        if (color.equals(Color.red)) {
            return Colors.vermell;
        } else if (color.equals(Color.blue)) {
            return Colors.blau;
        } else if (color.equals(Color.green)) {
            return Colors.verd;
        } else if (color.equals(Color.yellow)) {
            return Colors.groc;
        } else if (color.equals(new Color(231, 133, 28))) {
            return Colors.taronja;
        } else if (color.equals(Color.magenta)) {
            return Colors.rosa;
        } else if (color.equals(new Color(200, 162, 200))) {
            return Colors.lila;
        } else if (color.equals(Color.gray)) {
            return Colors.gris;
        } else if (color.equals(Color.black)) {
            return Colors.negre;
        }else if (color.equals(Color.white)) {
            return Colors.blanc;
        }else {
            return null;
        }
    }

    private Color obteColorRenderitzable(Colors color) {
        switch (color) {
            case vermell:
                return Color.red;
            case blau:
                return Color.blue;
            case verd:
                return Color.green;
            case groc:
                return Color.yellow;
            case taronja:
                return new Color(231, 133, 28);
            case rosa:
                return Color.magenta;
            case lila:
                return new Color(200, 162, 200);
            case negre:
                return Color.black;
            case blanc:
                return Color.white;
            default:
                return Color.gray;
        }
    }
}



