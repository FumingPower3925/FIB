package Presentacio;

import Domain.Pair;
import Domain.Partida.Colors;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Classe VistaCodeBreaker
 * Conté els elements per renderitzar la vista de quan es juga com Code Breaker
 *
 * @author David Molina Mesa
 */
public class VistaCodeBreaker extends JFrame {
    ControladorPresentacio cp;
    private JPanel panelPartida;
    private JButton menuButton;
    private JButton netejarButton;
    private JButton confirmarSeleccioButton;
    private JButton ajudaButton;
    private JPanel taulerPanel;
    private JPanel colorPanel;
    private JPanel[][] tauler;
    private int filaActual;
    private int nFiles;
    private int nColumnes;
    private int nColors;
    private int casellesSeleccionades;
    private Colors[] colorsEscollits;
    private boolean seleccioBotonsHabilitada;
    private boolean esRepeteixen;

    /**
     * Creadora de la vista del Code Breaker
     * Cost: O(1)
     * @param cp es el controlador de presentació
     */
    public VistaCodeBreaker(ControladorPresentacio cp) {
        this.cp = cp;
        this.casellesSeleccionades = 0;
        this.seleccioBotonsHabilitada = true;
        initComponents();
    }

    /**
     * Funció inicilitzadora dels components de la vista
     * Cost: O(1)
     */
    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(920, 740);
        setLocationRelativeTo(null);
        setVisible(true);

        int[] elements = Arrays.copyOf(cp.reprenPartida(), cp.reprenPartida().length);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        panelPartida = new JPanel();
        panelPartida.setLayout(null);
        panelPartida.setBackground(Color.darkGray);

        menuButton = new JButton(messages.getString("menuButton"));
        menuButton.setBounds(20, 40, 100, 30);
        panelPartida.add(menuButton);

        netejarButton = new JButton(messages.getString("netejarButton"));
        netejarButton.setBounds(650, 650, 100, 30);
        netejarButton.setBackground(Color.white);
        netejarButton.setForeground(Color.black);
        netejarButton.setOpaque(true);
        netejarButton.setBorderPainted(true);
        netejarButton.setBorder(BorderFactory.createLineBorder(Color.black, 2));
        netejarButton.setFocusPainted(false);
        panelPartida.add(netejarButton);

        confirmarSeleccioButton = new JButton(messages.getString("confirmarSeleccioButton"));
        confirmarSeleccioButton.setBounds(650, 600, 120, 30);
        confirmarSeleccioButton.setEnabled(false);
        confirmarSeleccioButton.setBackground(Color.green);
        confirmarSeleccioButton.setForeground(Color.white);
        confirmarSeleccioButton.setOpaque(true);
        confirmarSeleccioButton.setBorderPainted(true);
        confirmarSeleccioButton.setBorder(BorderFactory.createLineBorder(Color.white, 2));
        confirmarSeleccioButton.setFocusPainted(false);
        panelPartida.add(confirmarSeleccioButton);

        ajudaButton = new JButton("Ajuda'm");
        ajudaButton.setBounds(50, 200, 120, 30);
        ajudaButton.setEnabled(true);
        ajudaButton.setBackground(Color.blue);
        ajudaButton.setForeground(Color.white);
        ajudaButton.setOpaque(true);
        ajudaButton.setBorderPainted(true);
        ajudaButton.setBorder(BorderFactory.createLineBorder(Color.white, 2));
        ajudaButton.setFocusPainted(false);
        panelPartida.add(ajudaButton);

        JLabel ajudaLabel = new JLabel();
        ajudaLabel.setBounds(50, 250, 1000, 30);
        ajudaLabel.setForeground(Color.white);
        panelPartida.add(ajudaLabel);

        nFiles = elements[2];
        nColumnes= elements[3];
        nColors = elements[4];
        colorsEscollits = new Colors[nColumnes];
        filaActual = nFiles-1;
        esRepeteixen = elements[1] == 3;

        JLabel intentsLabel = new JLabel(messages.getString("intentsLabel")+ " " + (nFiles));
        intentsLabel.setBounds(50, 150, 1000, 30);
        intentsLabel.setForeground(Color.white);
        panelPartida.add(intentsLabel);

        taulerPanel = new JPanel();

        Dimension windowSize = getSize();
        int windowWidth = windowSize.width;
        int windowHeight = windowSize.height;


        int taulerWidth = nColumnes * 32;
        int taulerHeight = nFiles * 30;
        int taulerX = (windowWidth - taulerWidth) / 2;
        int taulerY = (windowHeight - taulerHeight) / 2;

        int colorPanelWidth = nColors * 40;
        int colorPanelHeight = 45;
        int colorPanelX = (windowWidth - colorPanelWidth) / 2;


        taulerPanel.setBounds(taulerX, taulerY-100, taulerWidth, taulerHeight);

        taulerPanel.setLayout(new GridLayout(nFiles, nColumnes));
        generarTauler(nFiles, nColumnes);
        if(cp.getPausada()) carregaTauler();
        panelPartida.add(taulerPanel);

        colorPanel = new JPanel();
        colorPanel.setBounds(colorPanelX, 600, colorPanelWidth, colorPanelHeight);
        colorPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Agrega padding de 10 píxeles
        colorPanel.setLayout(new GridLayout(nColors, 1));
        colorPanel.setBackground(Color.GRAY);
        generarColors(nColors);
        panelPartida.add(colorPanel);

        setContentPane(panelPartida);

        menuButton.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] opcions = {messages.getString("reanudarOption"), messages.getString("reiniciarOption"), messages.getString("guardarsortirOption"), messages.getString("abandonarOption")};
                int seleccio = JOptionPane.showOptionDialog(
                        VistaCodeBreaker.this,
                        "",
                        messages.getString("menuButton"),
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        opcions,
                        opcions[0]);

                switch (seleccio) {
                    case 0:
                        // no faig res
                        break;
                    case 1:
                        cp.reiniciaPartida();
                        VistaCodeMaker vp = new VistaCodeMaker(cp);
                        vp.setVisible(true);
                        setVisible(false);
                        break;
                    case 2:
                        cp.pausarPartida();
                        VistaMenuPrincipal vmp = new VistaMenuPrincipal(cp);
                        vmp.setVisible(true);
                        setVisible(false);
                        break;
                    case 3:
                        cp.abandonarPartida();
                        VistaMenuPrincipal vmp2 = new VistaMenuPrincipal(cp);
                        vmp2.setVisible(true);
                        setVisible(false);
                        break;
                }
            }
        });

        netejarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                netejarFilaActual();
                modificaEnableBotonsColors(true);
                confirmarSeleccioButton.setEnabled(false);
            }
        });

        confirmarSeleccioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pair<Pair<Boolean, Boolean>, Colors[]> respostaCodeMaster = cp.validaJugada(colorsEscollits);
                confirmarSeleccioButton.setEnabled(false);
                --filaActual;

                if(!seleccioBotonsHabilitada){
                    seleccioBotonsHabilitada = true;
                    modificaEnableBotonsColors(seleccioBotonsHabilitada);
                }
                mostraRespostaCodeMaker(respostaCodeMaster);

                intentsLabel.setText(messages.getString("intentsLabel")+ " " + (nFiles - (nFiles-filaActual-1)));
            }
        });

        ajudaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pair<Colors,Integer> ajuda = cp.demanarAjuda();
                ajudaLabel.setText( messages.getString("elColorNumero") + " " + (ajuda.getValue() + 1) + " " + messages.getString("esEL") + " " + ajuda.getKey());
                ajudaButton.setEnabled(false);
            }
        });

    }

    /**
     * Genera el tauler de la partida (sense fitxes)
     * Cost: O(file*columnes)
     * @param files el numero de files del tauler
     * @param columnes el numero de columnes del tauler
     */
    private void generarTauler(int files, int columnes) {
        tauler = new JPanel[files][columnes];
        for (int i = 0; i < files; i++) {
            for (int j = 0; j < columnes; j++) {
                JPanel casillaPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 4));
                casillaPanel.setBackground(Color.lightGray);
                taulerPanel.add(casillaPanel);
                tauler[i][j] = casillaPanel;
            }
        }
    }

    /**
     * Genera un panell amb els botons de colors de la partida
     * Cost: O(n) essent n el numero de colors disponibles
     * @param numColors es el numero de colors disponibles
     */
    private void generarColors(int numColors) {
        colorPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 0));
        for (int i = 0; i < numColors; i++) {
            JButton colorButton = new JButton();
            colorButton.setPreferredSize(new Dimension(30, 30));
            colorButton.setBackground(asignaColorAlBoto(i));
            colorButton.setOpaque(true);
            colorButton.setBorderPainted(false);
            colorButton.setFocusPainted(false);
            colorButton.setMargin(new Insets(0, 5, 0, 5));
            colorButton.setBorder(BorderFactory.createEmptyBorder());
            int finalI = i;
            colorButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    colorButton.setEnabled(esRepeteixen);
                    Color color = colorButton.getBackground();
                    colorsEscollits[casellesSeleccionades] = agafaColordeColorObject(color);
                    ++casellesSeleccionades;
                     if(casellesSeleccionades == nColumnes){
                        casellesSeleccionades = 0;
                        confirmarSeleccioButton.setEnabled(true);
                            seleccioBotonsHabilitada = false;
                            modificaEnableBotonsColors(seleccioBotonsHabilitada);
                    }
                    colocarColorEnTauler(color);
                }
            });
            colorPanel.add(colorButton);
        }
    }

    /**
     * Posiciona el color polsat en el tauler
     * Cost: O(nFiles * nColumnes)
     * @param color es el objecte Color que es renderitzara a la posició del tauler
     */
    private void colocarColorEnTauler(Color color) {
        for (int i = tauler.length - 1; i >= 0; i--) {
            for (int j = 0; j < tauler[0].length; j++) {
                JPanel casillaPanel = tauler[i][j];
                if (casillaPanel.getComponentCount() == 0) {
                    JLabel colorLabel = crearColorLabel(color);
                    casillaPanel.add(colorLabel);
                    casillaPanel.revalidate();
                    casillaPanel.repaint();
                    return;
                }
            }
        }
    }

    /**
     * Crea el JlLabel que es necesita per ser colocat al tauler
     * Cost: O(1)
     * @param color és l'objecte Color que otorga propietats al JLabel
     * @return JLabel és l'element que retorna amb les propietats d'estil assignades
     */
    private JLabel crearColorLabel(Color color) {
        JLabel colorLabel = new JLabel();
        colorLabel.setOpaque(true);
        colorLabel.setBackground(color);
        colorLabel.setPreferredSize(new Dimension(30, 30));
        colorLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        return colorLabel;
    }

    /**
     * S'encarrega de netejar tot el contingut que s'ha inserit en la fila que l'usuari està resolent el codi
     * Cost: O(1)
     */
    private void netejarFilaActual() {
        casellesSeleccionades = 0;
        for (int j = 0; j < tauler[filaActual].length; j++) {
            JPanel casillaPanel = tauler[filaActual][j];
            casillaPanel.removeAll();
            casillaPanel.revalidate();
            casillaPanel.repaint();
        }
    }

    /**
     * Habilita o deshabilita la possibilitat de premer els botons dels colors
     * Cost: O(1)
     */
    private void modificaEnableBotonsColors(boolean habilita){
            for (Component component : colorPanel.getComponents()) {
                if (component instanceof JButton) {
                    ((JButton) component).setEnabled(habilita);
                }
            }
    }



    /**
     * Retorna objecte Color depenent el seu índex entre tots els colors
     * Cost: O(n) essent n la mida de l'enum Colors
     * @param indexColor index del color al que accedim
     * @return Objecte Color que sera assignat al boto de color com una propietat d'estil
     */
    private Color asignaColorAlBoto(int indexColor) {
        Colors[] valors = Colors.values();
        Colors colorSeleccionat = valors[indexColor];

        switch (colorSeleccionat) {
            case vermell:
                return Color.red;
            case blau:
                return Color.blue;
            case verd:
                return Color.green;
            case groc:
                return Color.yellow;
            case taronja:
                return new Color(231, 133, 28);
            case rosa:
                return Color.magenta;
            case lila:
                return new Color(148, 59, 165);
            case gris:
                return Color.gray;
            case negre:
                return Color.black;
            case blanc:
                return Color.white;
            default:
                return null;
        }
    }

    /**
     * Mostra la resposta del Code Maker en un panel amb les fitxes de colors corresponents. Si es tracta d'encert o fi
     * dels intents disponibles mostra un pop-up indicant-lo a més del resultat de la partida
     * Cost: O(n) essent n la mida de la resposta del codi
     * @param respostaCodeMaker una parella que conté:
     *        1. Un boolean que indica si hi ha més files per jugar una altra ronda, amb un altre boolean que indica si el codebreaker ha encertat el codi
     *        2. Un array de tantes posicions com columnes tingui el paràmetre entrat indicant quants colors s'han encertat
     */
    private void mostraRespostaCodeMaker(Pair<Pair<Boolean, Boolean>, Colors[]> respostaCodeMaker) {
        boolean encert = respostaCodeMaker.getKey().getValue();
        Colors[] respotaCodi = respostaCodeMaker.getValue();
        System.out.println(Arrays.toString(respotaCodi));

        ArrayList<JLabel> colorLabels = new ArrayList<>();

        for (Colors color : respotaCodi) {
            JLabel colorLabel = new JLabel();
            colorLabel.setOpaque(true);
            colorLabel.setBackground(obteColorRenderitzable(color));
            colorLabel.setPreferredSize(new Dimension(30, 30));
            colorLabels.add(colorLabel);
        }

        JPanel respostaCodeMasterPanel = new JPanel();
        for (JLabel colorLabel : colorLabels) {
            respostaCodeMasterPanel.add(colorLabel);
        }
        panelPartida.repaint();

        respostaCodeMasterPanel.setBounds(650,500 - (nFiles-filaActual)*35 ,nColumnes*40,35);

        respostaCodeMasterPanel.repaint();
        panelPartida.revalidate();

        panelPartida.add(respostaCodeMasterPanel);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));
        if (encert || filaActual < 0) {
            int [] resultat = cp.registraResultat();
            JPanel panel = new JPanel();
            JLabel textSuperior = new JLabel( messages.getString("durada") + " " + resultat[0] +  "  " + messages.getString("intentsJugador") + " " +  resultat[1] + "  " + messages.getString("intentsIA") + " " + resultat[2] + "  " + messages.getString("puntuacio") + " " + resultat[3]);
            panel.add(textSuperior);

            JOptionPane optionPane = new JOptionPane(panel, JOptionPane.INFORMATION_MESSAGE, JOptionPane.DEFAULT_OPTION, null, new Object[]{}, null);
            JDialog dialog = new JDialog();
            if (encert)  dialog = optionPane.createDialog(panelPartida, messages.getString("hasEncertat"));
            else if (filaActual < 0) dialog = optionPane.createDialog(panelPartida, messages.getString("noHasEncertat"));

            dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
            JDialog finalDialog = dialog;
            dialog.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    VistaMenuPrincipal vmp = new VistaMenuPrincipal(cp);
                    vmp.setVisible(true);
                    setVisible(false);
                    finalDialog.dispose();
                }
            });

            dialog.setVisible(true);
        }
    }

    /**
     * Donat un objecte de l'enum de Colors retorna un altre objecte de tipus Color. En serveix per traduir
     * Cost: O(1)
     * @param color objecte de l'enum de Colors que volem traduir
     * @return Objecte Color traduit
     */
    private Color obteColorRenderitzable(Colors color) {
        switch (color) {
            case vermell:
                return Color.red;
            case blau:
                return Color.blue;
            case verd:
                return Color.green;
            case groc:
                return Color.yellow;
            case taronja:
                return new Color(231, 133, 28);
            case rosa:
                return Color.magenta;
            case lila:
                return new Color(148, 59, 165);
            case negre:
                return Color.black;
            case blanc:
                return Color.white;
            case buit:
                return Color.lightGray;
        }
        return null;
    }

    /**
     * Donat un objecte Color retorna un altre de tipus Colors (enum amb el que treballem). Ens serveix per traduir
     * Cost: O(1)
     * @param color objecte Color que volem traduir
     * @return Objecte de l'enum Colors corresponent
     */
    private Colors agafaColordeColorObject(Color color) {
        if (color.equals(Color.red)) {
            return Colors.vermell;
        } else if (color.equals(Color.blue)) {
            return Colors.blau;
        } else if (color.equals(Color.green)) {
            return Colors.verd;
        } else if (color.equals(Color.yellow)) {
            return Colors.groc;
        } else if (color.equals(new Color(231, 133, 28))) {
            return Colors.taronja;
        } else if (color.equals(Color.magenta)) {
            return Colors.rosa;
        } else if (color.equals(new Color(148, 59, 165))) {
            return Colors.lila;
        } else if (color.equals(Color.lightGray)) {
            return Colors.buit;
        } else if (color.equals(Color.black)) {
            return Colors.negre;
        }else if (color.equals(Color.white)) {
            return Colors.blanc;
        }else {
            return null;
        }
    }

    private void carregaTauler() {
        Colors[][] taulerAmbColors = cp.getTauler();
        for (int i = 0; i < taulerAmbColors.length; i++) {
            for (int j = 0; j < taulerAmbColors[i].length; j++) {
                Colors color = taulerAmbColors[i][j];
                colocarColorEnTauler(obteColorRenderitzable(color));
            }
        }
    }

}
