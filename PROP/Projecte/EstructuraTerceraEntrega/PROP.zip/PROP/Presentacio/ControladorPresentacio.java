package Presentacio;

import Domain.ControladorDomini;
import Domain.Dificultat;
import Domain.Pair;
import Domain.Partida.Colors;
import Domain.Partida.Resultat;
import Domain.Partida.TipusPartida;

import java.io.IOException;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Classe ControladorPresentació
 * Conté mètodes i atributs per gestionar la informació que precisen les vistes
 *
 * @author David Molina Mesa
 */
public class ControladorPresentacio {
    private ControladorDomini cd;
    private int usuariActual;
    private int partidaActual;
    private String idioma;
    private int max_length;
    private boolean pausada;

    /**
     * Creadora del controlador de presentació
     * Cost: O(1)
     */
    public ControladorPresentacio() throws IOException {
        this.cd = new ControladorDomini();
        this.idioma = "ca";
        this.partidaActual = -1;
        this.max_length = 16;
    }

    public int getMax_length() {
        return this.max_length;
    }

    public void iniciaPrograma() throws IOException {
        new VistaBenvinguda(this);
    }

    /**
     * Obtenim l'idioma que utilitzem a les vistes
     * Cost: O(1) en tots els casos
     * @return l'idioma que utilitzem a les vistes
     */
    public String getIdioma() {
        return idioma;
    }

    /**
     * Obtenim el pid de la partida actual
     * Cost: O(1) en tots els casos
     * @return el pid de la partida actual
     */
    public int getPartidaActual() {return partidaActual;}

    /**
     * Asignem un nou idioma a l'idioma que utilitzem a les vistes
     * Cost: O(1) en tots els casos
     * @param idioma nou idioma que volem setejar
     */
    public void setIdioma(String idioma){
        this.idioma = idioma;
    }

    /**
     * Retorna l'atribut pausada
     * Cost: O(1) en tots els casos
     * @return l'atribut pausada
     */
    public boolean getPausada(){
        return pausada;
    }

    /**
     * Registra l'usuari al sistema
     * Cost: O(1)
     * @param nom és el nom que especifica l'usuari no registrat
     * @param contrasenya és la contrasenya que especifica l'usuari no registrat
     * @return un boolean indicant si l'usuari s'ha pogut registrar o no
     */
    public boolean registrarUsuari(String nom, String contrasenya){
        if(!cd.comprovarNom(nom)){
            this.usuariActual = cd.altaUsuari(nom,contrasenya);
            System.out.println(usuariActual);
            return true;
        }
        return false;
    }

    /**
     * Loguejar l'usuari al sistema
     * Cost: O(1)
     * @param nom és el nom que especifica l'usuari
     * @param contrasenya és la contrasenya que especifica l'usuari
     * @return un boolean indicant si l'usuari ha pogut iniciar sessió o no
     */
    public boolean logejarUsuari(String nom, String contrasenya){
        this.usuariActual = cd.loginUsuari(nom,contrasenya);
        System.out.println(usuariActual);
        return this.usuariActual > -1;
    }

    public int getUsuariActual(){
        return this.usuariActual;
    }

    public String getNomUsuariActual(){
        return cd.dadesUsuari(usuariActual)[1];
    }


    /**
     * Configura les variables d'una partida inicialitzant-la
     * Cost: O(1)
     * @param tipus tipus de la partida
     * @param dif dificultat de la partida
     * @param nFiles número de files del tauler
     * @param nColumnes número de columnes del tauler
     * @param nColors número de colors que hauran al joc
     */
    public void configuraPartida(TipusPartida tipus, Dificultat dif, int nFiles, int nColumnes, int nColors){
        this.partidaActual = cd.iniciarPartida(usuariActual, dif, tipus, nFiles, nColumnes, nColors);
        System.out.println("partida actual :" + partidaActual);
    }

    public void pausarPartida(){
        pausada = true;
        cd.pausarPartida(usuariActual);
    }

    /**
     * Obtenim el tauler de la partida
     * Cost: O(n*m); on n és el nombre de files, m és el nombre de columnes del tauler
     * @return el tauler de la partida
     */
    public Colors[][] getTauler() {
        return cd.getTauler(usuariActual);
    }

    public void reiniciaPartida() { partidaActual = cd.reiniciarPartida(usuariActual);}

    /**
     * Reprèn una partida activa retornant el seu estat
     * Cost: O(1)
     * @return un array de int amb els següents paràmetres:
     *              1. El tipus de partida: 0 és de tipus entrenament, 1 és de tipus ranked
     *              2. La dificultat de la partida: 1 és de dificultat fàcil, 2 és de dificultat intermitja, 3 és de dificultat difícil
     *              3. El nombre de files que té el tauler de la partida
     *              4. El nombre de columnes que té el tauler de la partida
     *              5. El nombre de colors possibles per a encertar el codi del codemaker
     */
    public int [] reprenPartida(){
        return cd.rependrePartida(usuariActual);
    }

    /**
     * Comprovem si el codi del codebreaker que s'ha entrat és el correcte i informem si queden més files per seguir jugant una altra ronda
     * Cost: O(n^2) cas pitjor i mig, O(n) cas millor; on n és el nombre de columnes del tauler
     * @param colorsEscollits codi que ha entrat el codebreaker per intentar adivinar el codi del codemaker. Té tantes posicions com columnes té el tauler
     * @return una parella que conté:
     *          1. Un boolean que indica si hi ha més files per jugar una altra ronda, amb un altre boolean que indica si el codebreaker ha encertat el codi
     *          2. Un array de tantes posicions com columnes tingui el paràmetre entrat indicant quants colors s'han encertat
     */
    public Pair<Pair<Boolean,Boolean>,Colors[]> validaJugada(Colors[] colorsEscollits){
        return cd.comprovarCodi(partidaActual,colorsEscollits);
    }

    public Pair<Colors,Integer> demanarAjuda(){
        return cd.demanarAjuda(usuariActual);
    }

    public void abandonarPartida(){
        partidaActual = -1;
        cd.abandonarPartida(usuariActual);
    }

    public int [] registraResultat(){
        partidaActual = -1;
        return cd.acabarPartida(usuariActual);
    }

    public ArrayList<Colors[]> resolCodiIA(Colors[] colorsSeleccionats){
        return cd.iniciaJugadaIA(partidaActual,colorsSeleccionats);
    }

    public void esborrarCompte(int uid) {
        this.usuariActual = -1;
        cd.baixaUsuari(uid);
    }

    public void canviarContrasenya(String pwd) {
        cd.canviaUsuari(true, this.usuariActual, pwd);
    }

    public void canviarNom(String nom) {
        cd.canviaUsuari(false, this.usuariActual, nom);
    }

    public boolean existeixNomUsuari(String nom) {
        return cd.comprovarNom(nom);
    }

    public int [] getEstadistiquesUsuari(){
        return cd.estadistiquesUsuari(this.usuariActual);
    }

    public ArrayList<Pair<int[], LocalDateTime>> getHistorial() {
        return cd.historialUsuari(usuariActual);
    }

    public ArrayList<Pair<String,Boolean>> getRecords() {
        return cd.consultarRecords(usuariActual);
    }

    public ArrayList<Pair<Integer, String>> getRanquingPartides(Dificultat dif) {
        return cd.ranquingPartides(dif);
    }

    public ArrayList<Pair<Float, String>> getRanquingUsuaris(Dificultat dif) {
        ArrayList<Pair<Float, String>> r = cd.ranquingUsuaris(dif);
        ArrayList<Pair<Float, String>> ret = new ArrayList<>();
        if (r != null) return r;

        return ret;
    }

}


