package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Classe VistaMenuPrincipal
 * Conté els elements per renderitzar la vista del menú principal
 *
 * @author David Molina Mesa
 */
public class VistaMenuPrincipal extends JFrame {
    private ControladorPresentacio cp;
    private JPanel panelMenuPrincipal;
    private JButton perfilButton;
    private JButton tancarSessioButton;
    private JButton enrereButton;
    private JButton jugarPartidaButton;
    private JButton reprendrePartidaButton;
    private JButton ranquingButton;
    private JLabel menuPrincipalLabel;

    /**
     * Creadora de la vista del menú principal
     * Cost: O(1)
     * @param cp es el controlador de presentació
     */
    public VistaMenuPrincipal(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    /**
     * Funció inicilitzadora dels components de la vista
     * Cost: O(1)
     */
    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));
        menuPrincipalLabel.setText(messages.getString("menuPrincipalLabel"));
        perfilButton.setText(messages.getString("perfilButton"));
        jugarPartidaButton.setText(messages.getString("jugarPartidaButton"));
        reprendrePartidaButton.setText(messages.getString("reprendePartidaButton"));
        //Li fem que sigui clickable dependent de si hi ha partida activa o no
        reprendrePartidaButton.setEnabled(cp.getPartidaActual()!=-1);
        ranquingButton.setText(messages.getString("ranquingButton"));
        tancarSessioButton.setText(messages.getString("tancarSessioButton"));


        setContentPane(panelMenuPrincipal);

        perfilButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPerfil vp = new VistaPerfil(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });

        jugarPartidaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaConfiguracioPartida vcp = new VistaConfiguracioPartida(cp);
                vcp.setVisible(true);
                setVisible(false);
            }
        });

        reprendrePartidaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaCodeBreaker vp = new VistaCodeBreaker(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });

        tancarSessioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPrincipal vp = new VistaPrincipal(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });

        ranquingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaSeleccioRanquing vsr = new VistaSeleccioRanquing(cp);
                vsr.setVisible(true);
                setVisible(false);
            }
        });

    }
}
