package Presentacio;

import Domain.Dificultat;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class VistaRanquingPartides extends JFrame {
    private ControladorPresentacio cp;
    private JPanel panelRanquingPartides;
    private JButton enrereButton;
    private JComboBox dificultatComboBox;
    private JScrollPane jsp;
    private JLabel ranquingPartidesLabel;

    public VistaRanquingPartides(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        panelRanquingPartides = new JPanel();
        panelRanquingPartides.setLayout(null);

        ranquingPartidesLabel = new JLabel(messages.getString("ranquingPartidesButton"));
        enrereButton = new JButton(messages.getString("enrereButton"));
        String[] dificultats = {"Fàcil", "Intermig", "Difícil"};
        dificultatComboBox = new JComboBox(dificultats);
        LlistaScroll h = new LlistaScroll(cp);
        jsp = new JScrollPane(h.generateList(1, Dificultat.facil));

        ranquingPartidesLabel.setBounds(320, 30, 200, 30);
        enrereButton.setBounds(20, 380, 100, 30);
        dificultatComboBox.setBounds(600, 320, 100, 30);
        jsp.setBounds(125, 100, 500, 200);

        panelRanquingPartides.add(ranquingPartidesLabel);
        panelRanquingPartides.add(enrereButton);
        panelRanquingPartides.add(dificultatComboBox);
        panelRanquingPartides.add(jsp);

        setContentPane(panelRanquingPartides);

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaSeleccioRanquing vsr = new VistaSeleccioRanquing(cp);
                vsr.setVisible(true);
                setVisible(false);
            }
        });

        dificultatComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panelRanquingPartides.remove(jsp);

                LlistaScroll h = new LlistaScroll(cp);
                jsp = new JScrollPane(h.generateList(1, getDificultatSeleccionada()));

                jsp.setBounds(125, 100, 500, 200);
                panelRanquingPartides.add(jsp);

                panelRanquingPartides.repaint();
                panelRanquingPartides.revalidate();
            }
        });
    }

    private Dificultat getDificultatSeleccionada() {

        Dificultat dif = Dificultat.facil;

        String difSeleccionada = (String) dificultatComboBox.getSelectedItem();
        switch (difSeleccionada) {
            case "Fàcil":
                dif = Dificultat.facil;
                break;
            case "Intermig":
                dif = Dificultat.intermig;
                break;
            case "Difícil":
                dif = Dificultat.dificil;
                break;
        }
        return dif;
    }
} 