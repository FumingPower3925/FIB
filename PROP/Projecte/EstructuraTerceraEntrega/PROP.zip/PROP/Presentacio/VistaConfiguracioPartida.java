package Presentacio;

import Domain.Dificultat;
import Domain.Partida.TipusPartida;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 * Classe VistaConfiguracioPartida
 * Conté els elements per renderitzar la vista de configurar partida
 *
 * @author David Molina Mesa
 */
public class VistaConfiguracioPartida extends JFrame {

    private ControladorPresentacio cp;
    private JPanel panelConfiguracioPartida;
    private JButton enrereButton;
    private JComboBox<String> tipusComboBox;
    private JComboBox<String> dificultatComboBox;
    private JComboBox<String> filesComboBox;
    private JComboBox<String> columnesComboBox;
    private JComboBox<String> colorsComboBox;
    private JButton endavantButton;
    private JLabel dificultatLabel;
    private JLabel repetitsLabel;
    private JLabel filesLabel;
    private JLabel columnesLabel;
    private JLabel colorsLabel;
    private JLabel tipusLabel;
    private JLabel configuracioPartidaLabel;

    /**
     * Creadora de la vista de configurar partida
     * Cost: O(1)
     * @param cp es el controlador de presentació
     */
    public VistaConfiguracioPartida(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    /**
     * Funció inicilitzadora dels components de la vista
     * Cost: O(1)
     */
    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        panelConfiguracioPartida = new JPanel();
        panelConfiguracioPartida.setLayout(null);
        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));
        configuracioPartidaLabel = new JLabel(messages.getString("configuracioPartidaLabel"));
        enrereButton = new JButton(messages.getString("enrereButton"));
        tipusComboBox = new JComboBox<>(new String[]{messages.getString("entrenamentOption"), messages.getString("ranquejadaOption")});
        dificultatComboBox = new JComboBox<>(new String[]{messages.getString("facilOption"), messages.getString("mitjaOption"), messages.getString("dificilOption")});
        filesComboBox = new JComboBox<>(new String[]{"5", "6", "7", "8", "9", "10", "11" ,"12", "13", "14", "15" });
        columnesComboBox = new JComboBox<>(new String[]{"4", "5", "6"});
        colorsComboBox = new JComboBox<>(new String[]{"4", "5", "6"});
        endavantButton = new JButton(messages.getString("endavantButton"));
        tipusLabel = new JLabel(messages.getString("tipusLabel"));
        dificultatLabel = new JLabel(messages.getString("dificultatLabel"));
        filesLabel = new JLabel(messages.getString("filesLabel"));
        columnesLabel = new JLabel(messages.getString("columnesLabel"));
        colorsLabel = new JLabel(messages.getString("colorsLabel"));
        repetitsLabel = new JLabel(messages.getString("repetitsLabel"));


        enrereButton.setBounds(20, 400, 100, 30);

        configuracioPartidaLabel.setBounds(280,30,200,30);

        tipusLabel.setBounds(270, 90, 100, 30);
        tipusComboBox.setBounds(350, 90, 130, 30);

        dificultatLabel.setBounds(270, 140, 100, 30);
        dificultatComboBox.setBounds(350, 140, 130, 30);

        filesLabel.setBounds(270, 190, 100, 30);
        filesComboBox.setBounds(350, 190, 130, 30);

        columnesLabel.setBounds(270, 240, 100, 30);
        columnesComboBox.setBounds(350, 240, 130, 30);

        colorsLabel.setBounds(270, 290, 100, 30);
        colorsComboBox.setBounds(350, 290, 130, 30);

        endavantButton.setBounds(620, 400, 100, 30);

        repetitsLabel.setBounds(230,320,1000,50);
        repetitsLabel.setForeground(Color.red);
        repetitsLabel.setVisible(false);

        panelConfiguracioPartida.add(repetitsLabel);
        panelConfiguracioPartida.add(enrereButton);
        panelConfiguracioPartida.add(configuracioPartidaLabel);
        panelConfiguracioPartida.add(tipusLabel);
        panelConfiguracioPartida.add(tipusComboBox);
        panelConfiguracioPartida.add(dificultatLabel);
        panelConfiguracioPartida.add(dificultatComboBox);
        panelConfiguracioPartida.add(filesLabel);
        panelConfiguracioPartida.add(filesComboBox);
        panelConfiguracioPartida.add(columnesLabel);
        panelConfiguracioPartida.add(columnesComboBox);
        panelConfiguracioPartida.add(colorsLabel);
        panelConfiguracioPartida.add(colorsComboBox);
        panelConfiguracioPartida.add(endavantButton);

        setContentPane(panelConfiguracioPartida);

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaMenuPrincipal vmp = new VistaMenuPrincipal(cp);
                vmp.setVisible(true);
                setVisible(false);
            }
        });

        endavantButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(Integer.parseInt(columnesComboBox.getSelectedItem().toString()) > Integer.parseInt(colorsComboBox.getSelectedItem().toString())){
                    JOptionPane.showMessageDialog(VistaConfiguracioPartida.this, messages.getString("menysColorsQueColumnes"), "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                TipusPartida tipus;
                if(Objects.equals(tipusComboBox.getSelectedItem(), messages.getString("entrenamentOption"))) tipus = TipusPartida.entrenament;
                else tipus = TipusPartida.ranked;

                Dificultat dif;
                if (Objects.equals(dificultatComboBox.getSelectedItem(),  messages.getString("facilOption"))) dif = Dificultat.facil;
                else if (Objects.equals(dificultatComboBox.getSelectedItem(),  messages.getString("mitjaOption"))) dif = Dificultat.intermig;
                else dif = Dificultat.dificil;

                cp.configuraPartida(tipus,dif, Integer.parseInt(filesComboBox.getSelectedItem().toString()), Integer.parseInt(columnesComboBox.getSelectedItem().toString()), Integer.parseInt(colorsComboBox.getSelectedItem().toString()));
                VistaCodeMaker vp = new VistaCodeMaker(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });

        dificultatComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(dificultatComboBox.getSelectedItem().equals(messages.getString("dificilOption"))) repetitsLabel.setVisible(true);
                else repetitsLabel.setVisible(false);
            }
        });
    }
}

