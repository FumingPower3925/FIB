package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Classe VistaPerfil
 * Conté els elements per renderitzar la vista del perfil
 *
 * @author Sergio Delgado Ampudia
 */
public class VistaPerfil extends JFrame {

    private ControladorPresentacio cp;
    private JPanel panelPerfil;
    private JButton enrereButton;
    private JButton estadistiquesButton;
    private JButton historialButton;
    private JButton recordsButton;
    private JButton canviarNomButton;
    private JButton canviarContrasenyaButton;
    private JButton esborrarCompteButton;
    private JLabel perfilLabel;
    private JButton canviarIdiomaButton;

    /**
     * Creadora de la vista del perfil
     * Cost: O(1)
     * @param cp es el controlador de presentació
     */
    public VistaPerfil(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    /**
     * Funció inicilitzadora dels components de la vista
     * Cost: O(1)
     */
    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));
        perfilLabel.setText(messages.getString("perfilLabel"));
        estadistiquesButton.setText(messages.getString("estadistiquesButton"));
        historialButton.setText(messages.getString("historialButton"));
        recordsButton.setText(messages.getString("recordsButton"));
        canviarNomButton.setText(messages.getString("canviarNomButton"));
        canviarContrasenyaButton.setText(messages.getString("canviarContrasenyaButton"));
        esborrarCompteButton.setText(messages.getString("esborrarCompteButton"));
        enrereButton.setText(messages.getString("enrereButton"));

        setContentPane(panelPerfil);


        estadistiquesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaEstadistiques ve = new VistaEstadistiques(cp);
                ve.setVisible(true);
                setVisible(false);
            }
        });


        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaMenuPrincipal vmp = new VistaMenuPrincipal(cp);
                vmp.setVisible(true);
                setVisible(false);
            }
        });
        //Afegit: Noa
        recordsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaRecords vr = new VistaRecords(cp);
                vr.setVisible(true);
                setVisible(false);
            }
        });

        //Afegit: Noa
        canviarIdiomaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaCanviarIdioma vci = new VistaCanviarIdioma(cp);
                vci.setVisible(true);
                setVisible(false);
            }
        });

        //Afegit: Noa
        historialButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaHistorial vh = new VistaHistorial(cp);
                vh.setVisible(true);
                setVisible(false);
            }
        });

        //Afegit: Noa
        canviarContrasenyaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaCanviarContrasenya vcc = new VistaCanviarContrasenya(cp);
                vcc.setVisible(true);
                setVisible(false);
            }
        });

        //Afegit: Noa
        canviarNomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaCanviarNom vcn = new VistaCanviarNom(cp);
                vcn.setVisible(true);
                setVisible(false);
            }
        });

        //Afegit: Noa
        esborrarCompteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaEsborrarCompte vec = new VistaEsborrarCompte(cp);
                vec.setVisible(true);
                setVisible(false);
            }
        });
    }
}
