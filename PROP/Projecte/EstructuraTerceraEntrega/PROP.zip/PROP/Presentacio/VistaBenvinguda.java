package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Classe VistaBenvinguda
 * Conté els elements per renderitzar la vista de benvinguda
 *
 * @author David Molina Mesa
 */
public class VistaBenvinguda extends JFrame {

    private ControladorPresentacio cp;
    private JPanel panelBenvinguda;
    private JButton jugarButton;
    private JLabel benvingutLabel;
    private JComboBox<String> idiomaComboBox;

    /**
     * Creadora de la vista de benviguda
     * Cost: O(1)
     * @param cp es el controlador de presentació
     */
    public VistaBenvinguda(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    /**
     * Funció inicilitzadora dels components de la vista
     * Cost: O(1)
     */
    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale("ca"));

        panelBenvinguda = new JPanel();
        panelBenvinguda.setLayout(null);


        String[] idiomas = {"Català", "Español", "English", "Français", "Deustch"};
        idiomaComboBox = new JComboBox<>(idiomas);
        idiomaComboBox.setSelectedItem("Català");
        actualitzaIdioma("Catala");
        benvingutLabel = new JLabel(messages.getString("benvinguda"));
        jugarButton.setText(messages.getString("jugarButton"));

        benvingutLabel.setBounds(330, 30, 200, 30);
        jugarButton.setBounds(320, 200, 100, 30);
        idiomaComboBox.setBounds(600, 320, 100, 30);

        panelBenvinguda.add(benvingutLabel);
        panelBenvinguda.add(jugarButton);
        panelBenvinguda.add(idiomaComboBox);


        setContentPane(panelBenvinguda);

        idiomaComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idiomaSeleccionat = getIdiomaSeleccionat();
                cp.setIdioma(idiomaSeleccionat);
                actualitzaIdioma(idiomaSeleccionat);
            }
        });

        jugarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

               VistaPrincipal vp = new VistaPrincipal(cp);
               vp.setVisible(true);
               setVisible(false);
            }
        });
    }

    /**
     * Captura l'idioma seleccionat en el desplegable d'idiomes
     * Cost: O(1)
     */
    private String getIdiomaSeleccionat() {
        String idioma = "";
        String idiomaSeleccionat = (String) idiomaComboBox.getSelectedItem();
        switch (idiomaSeleccionat) {
            case "Català":
                idioma = "ca";
                break;
            case "Español":
                idioma = "es";
                break;
            case "English":
                idioma = "en";
                break;
            case "Français":
                idioma = "fr";
                break;
            case "Deustch":
                idioma = "de";
                break;
        }
        return idioma;
    }

    /**
     * Actualitza els components de la vista amb un dels idiomes que hagi estat seleccionat
     * Cost: O(1)
     * @param idiomaSeleccionat idioma que selecciona l'usuari del desplegable
     */
    private void actualitzaIdioma(String idiomaSeleccionat) {
        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(idiomaSeleccionat));
        benvingutLabel.setText(messages.getString("benvinguda"));
        jugarButton.setText(messages.getString("jugarButton"));
    }
}
