package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class VistaCanviarContrasenya extends JFrame {

    private ControladorPresentacio cp;
    private JPanel panelCanviarContrasenya;
    private JButton enrereButton;
    private JLabel contrasenyaFieldLabel;
    private JLabel confirmarContrasenyaFieldLabel;
    private JPasswordField contrasenyaField;
    private JPasswordField confirmarContrasenyaField;
    private JButton acceptarButton;
    private JLabel canviarContrasenyaLabel;

    public VistaCanviarContrasenya(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        panelCanviarContrasenya = new JPanel();
        panelCanviarContrasenya.setLayout(null);

        canviarContrasenyaLabel = new JLabel(messages.getString("canviarContrasenyaButton"));
        enrereButton = new JButton(messages.getString("enrereButton"));
        contrasenyaFieldLabel = new JLabel(messages.getString("novaContrasenyaLabel"));
        confirmarContrasenyaFieldLabel = new JLabel(messages.getString("confirmarNovaContrasenyaLabel"));
        acceptarButton = new JButton(messages.getString("acceptarButton"));
        contrasenyaField = new JPasswordField();
        confirmarContrasenyaField = new JPasswordField();

        canviarContrasenyaLabel.setBounds(320, 30, 200, 30);
        enrereButton.setBounds(20, 380, 100, 30);
        acceptarButton.setBounds(575, 380, 100, 30);
        contrasenyaFieldLabel.setBounds(275, 70, 300, 30);
        contrasenyaField.setBounds(275, 110, 200, 20);
        confirmarContrasenyaFieldLabel.setBounds(275, 140, 300, 30);
        confirmarContrasenyaField.setBounds(275, 180, 200, 20);

        panelCanviarContrasenya.add(canviarContrasenyaLabel);
        panelCanviarContrasenya.add(enrereButton);
        panelCanviarContrasenya.add(acceptarButton);
        panelCanviarContrasenya.add(contrasenyaField);
        panelCanviarContrasenya.add(confirmarContrasenyaField);
        panelCanviarContrasenya.add(contrasenyaFieldLabel);
        panelCanviarContrasenya.add(confirmarContrasenyaFieldLabel);

        setContentPane(panelCanviarContrasenya);

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPerfil vp = new VistaPerfil(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });

        acceptarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String password = new String(contrasenyaField.getPassword());
                String confirmPassword = new String(confirmarContrasenyaField.getPassword());

                // Realiza la validación de los campos aquí
                if (password.isEmpty() || confirmPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(VistaCanviarContrasenya.this, "Omple tots els camps", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (password.length() > cp.getMax_length() || confirmPassword.length() > cp.getMax_length()) {
                    JOptionPane.showMessageDialog(VistaCanviarContrasenya.this, "La contrasenya és massa llarga. El nombre màxim de caràcters és " + cp.getMax_length(), "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(VistaCanviarContrasenya.this, "Les contrasenyes no coincideixen", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                else {
                    cp.canviarContrasenya(password);
                    VistaIniciarSessio vis = new VistaIniciarSessio(cp);
                    vis.setVisible(true);
                    setVisible(false);
                }
            }
        });
    }
}