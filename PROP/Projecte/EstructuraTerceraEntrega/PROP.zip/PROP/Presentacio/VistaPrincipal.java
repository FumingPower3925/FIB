package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Classe VistaPrincipal
 * Conté els elements per renderitzar la vista de benvinguda
 *
 * @author David Molina Mesa
 */
public class VistaPrincipal extends JFrame {
    private ControladorPresentacio cp;
    private JPanel MenuPrincipalPanel;
    private JButton iniciarSessióButton;
    private JButton registrarSeButton;
    private JButton provaUbermindButton;
    private JLabel provaLabel;

    /**
     * Creadora de la vista principal
     * Cost: O(1)
     * @param cp es el controlador de presentació
     */
    public VistaPrincipal(ControladorPresentacio cp) {
        this.cp = cp;
        //this.idioma = idiomaSeleccionat;
        iniComponents();
    }

    /**
     * Funció inicilitzadora dels components de la vista
     * Cost: O(1)
     */
    private void iniComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740,480);
        setLocationRelativeTo(null);
        setVisible(true);
        setContentPane(MenuPrincipalPanel);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        iniciarSessióButton.setText(messages.getString("iniciarSessioButton"));
        registrarSeButton.setText(messages.getString("registrarseButton"));
        provaLabel.setText(messages.getString("provaLabel"));
        provaUbermindButton.setText(messages.getString("provaUbermindButton"));

        iniciarSessióButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crea la vista de inicio de sesión y la hace visible
                VistaIniciarSessio vistaIniciarSesio = new VistaIniciarSessio(cp);
                vistaIniciarSesio.setVisible(true);

                // Oculta la vista actual
                setVisible(false);
            }
        });


        registrarSeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crea la vista de registro y la hace visible
                VistaRegistrar vistaRegistrar = new VistaRegistrar(cp);
                vistaRegistrar.setVisible(true);

                // Oculta la vista actual
                setVisible(false);
            }
        });

        provaUbermindButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crea la vista de registro y la hace visible
                VistaCodeBreaker vp = new VistaCodeBreaker(cp);
                vp.setVisible(true);

                // Oculta la vista actual
                setVisible(false);
            }
        });



    }
}
