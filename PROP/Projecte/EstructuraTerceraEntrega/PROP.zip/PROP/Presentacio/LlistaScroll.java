package Presentacio;

import Domain.Dificultat;
import Domain.Pair;
import Presentacio.ControladorPresentacio;

import javax.swing.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Locale;
import java.util.ResourceBundle;

public class LlistaScroll {
    private ControladorPresentacio cp;
    private JList<String> llista;

    public LlistaScroll(ControladorPresentacio cp) {
        this.cp = cp;
    }

    public JList<String> generateList(int mode, Dificultat dif) {
        if (mode < 0 || mode > 3) throw new IllegalArgumentException("Argument invàlid");
        if ((mode == 1 || mode == 2) && dif != Dificultat.facil && dif != Dificultat.intermig && dif != Dificultat.dificil) throw new IllegalArgumentException("Argument invàlid");
        DefaultListModel<String> listModel = new DefaultListModel<>();
        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        if (mode == 0) { //historial
            ArrayList<Pair<int[], LocalDateTime>> historial = cp.getHistorial();
            for (int i = 0; i < historial.size(); ++i) {
                listModel.addElement(messages.getString("puntuacioLabel") + "  " + historial.get(i).getKey()[4] + "  " + messages.getString("iniciPartida") + "  " +historial.get(i).getValue());
            }
        }

        else if (mode == 1) { //ranquing partides
            if (dif == Dificultat.facil) {
                ArrayList<Pair<Integer, String>> ranquingPartidesF = cp.getRanquingPartides(Dificultat.facil);
                for (int i = 0; i < ranquingPartidesF.size(); ++i) {
                    listModel.addElement(messages.getString("puntuacioLabel") + "  " + ranquingPartidesF.get(i).getKey() + "  " + messages.getString("nomUsuari") + "  " + ranquingPartidesF.get(i).getValue());
                }
            }
            if (dif == Dificultat.intermig) {
                ArrayList<Pair<Integer, String>> ranquingPartidesI = cp.getRanquingPartides(Dificultat.intermig);
                for (int i = 0; i < ranquingPartidesI.size(); ++i) {
                    listModel.addElement(messages.getString("puntuacioLabel") + "  " + ranquingPartidesI.get(i).getKey() + "  " + messages.getString("nomUsuari") + "  " + ranquingPartidesI.get(i).getValue());
                }
            }
            if (dif == Dificultat.dificil) {
                ArrayList<Pair<Integer, String>> ranquingPartidesD = cp.getRanquingPartides(Dificultat.dificil);
                for (int i = 0; i < ranquingPartidesD.size(); ++i) {
                    listModel.addElement(messages.getString("puntuacioLabel") + "   " + ranquingPartidesD.get(i).getKey() + "  " + messages.getString("nomUsuari") + "  " + ranquingPartidesD.get(i).getValue());
                }
            }
        }

        else if (mode == 2) { //ranquing usuaris
            if (dif == Dificultat.facil) {
                ArrayList<Pair<Float, String>> ranquingUsuarisF = cp.getRanquingUsuaris(Dificultat.facil);
                for (int i = 0; i < ranquingUsuarisF.size(); ++i) {
                    listModel.addElement(messages.getString("winrateLabel") + "  "  + ranquingUsuarisF.get(i).getKey() + "  " + messages.getString("nomUsuari") + "  " + ranquingUsuarisF.get(i).getValue());
                }
            }
            if (dif == Dificultat.intermig) {
                ArrayList<Pair<Float, String>> ranquingUsuarisI = cp.getRanquingUsuaris(Dificultat.intermig);
                for (int i = 0; i < ranquingUsuarisI.size(); ++i) {
                    listModel.addElement(messages.getString("winrateLabel") + "  " + ranquingUsuarisI.get(i).getKey() + "  " + messages.getString("nomUsuari") + "  " + ranquingUsuarisI.get(i).getValue());
                }
            }
            if (dif == Dificultat.dificil) {
                ArrayList<Pair<Float, String>> ranquingUsuarisD = cp.getRanquingUsuaris(Dificultat.dificil);
                for (int i = 0; i < ranquingUsuarisD.size(); ++i) {
                    listModel.addElement(messages.getString("winrateLabel") + "  " + ranquingUsuarisD.get(i).getKey() + "  " + messages.getString("nomUsuari") + "  " + ranquingUsuarisD.get(i).getValue());
                }
            }
        }

        else if (mode == 3) { //records
            ArrayList<Pair<String,Boolean>> records = cp.getRecords();
            for (int i = 0; i < records.size(); ++i){
                String completat = "Sí";
                if (!records.get(i).getValue()) completat = "No";
                listModel.addElement(records.get(i).getKey() + "  Completat:  " + completat);
            }
        }

        llista = new JList<>(listModel);
        return llista;
    }
}
