package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Classe VistaIniciarSessio
 * Conté els elements per renderitzar la vista d'iniciar sessió
 *
 * @author David Molina Mesa
 */
public class VistaIniciarSessio extends JFrame {
    private ControladorPresentacio cp;
    private JPanel panelIniciarSessio;
    private JButton enrereButton;
    private JTextField usuariField;
    private JPasswordField contrasenyaField;
    private JButton entrarButton;
    private JLabel usuariFieldLabel;
    private JLabel contrasenyaFieldLabel;
    private JLabel iniciarSessioLabel;

    /**
     * Creadora de la vista d'iniciar sessió
     * Cost: O(1)
     * @param cp es el controlador de presentació
     */
    public VistaIniciarSessio(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    /**
     * Funció inicilitzadora dels components de la vista
     * Cost: O(1)
     */
    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));
        iniciarSessioLabel.setText(messages.getString("iniciarSessioLabel"));
        usuariFieldLabel.setText(messages.getString("usuariFieldLabel"));
        contrasenyaFieldLabel.setText(messages.getString("contrasenyaFieldLabel"));
        entrarButton.setText(messages.getString("entrarButton"));
        enrereButton.setText(messages.getString("enrereButton"));
        setContentPane(panelIniciarSessio);


        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPrincipal vp = new VistaPrincipal(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });

        entrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usuariField.getText();
                String password = new String(contrasenyaField.getPassword());

                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(VistaIniciarSessio.this, "Cal omplir tots el camps", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if(cp.logejarUsuari(username,password)){
                    VistaMenuPrincipal vmp = new VistaMenuPrincipal(cp);
                    vmp.setVisible(true);
                    setVisible(false);
                }
                else {
                    JOptionPane.showMessageDialog(VistaIniciarSessio.this, "Usuari o contrasenya incorrectes", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
        });
    }
}
