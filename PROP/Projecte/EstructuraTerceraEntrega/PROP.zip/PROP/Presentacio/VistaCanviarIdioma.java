package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class VistaCanviarIdioma extends JFrame {

    private ControladorPresentacio cp;
    private JPanel panelCanviarIdioma;
    private JButton enrereButton;
    private JComboBox idiomaComboBox;
    private JLabel canviarIdiomaLabel;

    public VistaCanviarIdioma(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        panelCanviarIdioma = new JPanel();
        panelCanviarIdioma.setLayout(null);

        canviarIdiomaLabel = new JLabel(messages.getString("canviaIdiomaLabel"));
        enrereButton = new JButton(messages.getString("enrereButton"));

        String[] idiomas = {"Català", "Español", "English", "Français", "Deustch"};
        idiomaComboBox = new JComboBox<>(idiomas);
        idiomaComboBox.setSelectedItem(getIdiomaSeleccionatReverse(cp.getIdioma()));

        canviarIdiomaLabel.setBounds(330, 30, 200, 30);
        enrereButton.setBounds(20, 380, 100, 30);
        idiomaComboBox.setBounds(600, 320, 100, 30);

        panelCanviarIdioma.add(canviarIdiomaLabel);
        panelCanviarIdioma.add(enrereButton);
        panelCanviarIdioma.add(idiomaComboBox);

        setContentPane(panelCanviarIdioma);

        idiomaComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String idiomaSeleccionat = getIdiomaSeleccionat();
                cp.setIdioma(idiomaSeleccionat);
                idiomaComboBox.setSelectedItem(idiomaComboBox.getSelectedItem());
                actualitzaIdioma(idiomaSeleccionat);
            }
        });

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPerfil vp = new VistaPerfil(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });
    }

    private String getIdiomaSeleccionat() {

        String idioma = "";

        String idiomaSeleccionat = (String) idiomaComboBox.getSelectedItem();
        switch (idiomaSeleccionat) {
            case "Català":
                idioma = "ca";
                break;
            case "Español":
                idioma = "es";
                break;
            case "English":
                idioma = "en";
                break;
            case "Français":
                idioma = "fr";
                break;
            case "Deustch":
                idioma = "de";
                break;
        }
        return idioma;
    }

    private String getIdiomaSeleccionatReverse(String idiomaSeleccionat) {

        String idioma = "";

        switch (idiomaSeleccionat) {
            case "ca":
                idioma = "Català";
                break;
            case "es":
                idioma = "Español";
                break;
            case "en":
                idioma = "English";
                break;
            case "fr":
                idioma = "Français";
                break;
            case "de":
                idioma = "Deustch";
                break;
        }
        return idioma;
    }

    private void actualitzaIdioma(String idiomaSeleccionat) {
        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(idiomaSeleccionat));

        canviarIdiomaLabel.setText(messages.getString("canviaIdiomaLabel"));
        enrereButton.setText(messages.getString("enrereButton"));
    }
}