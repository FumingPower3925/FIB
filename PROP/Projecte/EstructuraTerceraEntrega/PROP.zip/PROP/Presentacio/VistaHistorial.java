package Presentacio;

import Domain.Dificultat;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class VistaHistorial extends JFrame {
    private ControladorPresentacio cp;
    private JPanel panelHistorial;
    private JButton enrereButton;
    private JLabel historialLabel;

    public VistaHistorial(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        panelHistorial = new JPanel();
        panelHistorial.setLayout(null);

        historialLabel = new JLabel(messages.getString("historialButton"));
        enrereButton = new JButton(messages.getString("enrereButton"));
        LlistaScroll h = new LlistaScroll(cp);
        JScrollPane jsp = new JScrollPane(h.generateList(0, Dificultat.facil));

        historialLabel.setBounds(345, 30, 200, 30);
        enrereButton.setBounds(20, 380, 100, 30);
        jsp.setBounds(150, 100, 500, 200);

        panelHistorial.add(historialLabel);
        panelHistorial.add(enrereButton);
        panelHistorial.add(jsp);

        setContentPane(panelHistorial);

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPerfil vp = new VistaPerfil(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });
    }
}