package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class VistaEstadistiques extends JFrame{

    private ControladorPresentacio cp;
    private JPanel panelEstadistiques;
    private JButton enrereButton;
    private JComboBox dificultatComboBox;
    private JLabel guanyadesLabel;
    private JLabel perdudesLabel;
    private JLabel tempsPartidaLabel;
    private JLabel duracioPromigLabel;
    private JLabel millorLabel;
    private JLabel promigLabel;
    private JLabel estadistiquesLabel;
    private JLabel dificultatLabel;

    public VistaEstadistiques(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    private void actualitzaLabels(String opcioSeleccionada) {
        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

            if(opcioSeleccionada.equals(messages.getString("facilOption"))){
                guanyadesLabel.setText(messages.getString("guanyadesLabel") + ": " + cp.getEstadistiquesUsuari()[0]);
                perdudesLabel.setText(messages.getString("perdudesLabel") + ": " + cp.getEstadistiquesUsuari()[3]);
                tempsPartidaLabel.setText(messages.getString("tempsPartidaLabel") + ": "+ cp.getEstadistiquesUsuari()[6]);
                duracioPromigLabel.setText(messages.getString("duracioPromigLabel") + ": " + cp.getEstadistiquesUsuari()[9]);
                millorLabel.setText(messages.getString("millorLabel") + ": " + cp.getEstadistiquesUsuari()[12]);
                promigLabel.setText(messages.getString("promigLabel") + ": " + cp.getEstadistiquesUsuari()[15]);
            }
            else if (opcioSeleccionada.equals(messages.getString("mitjaOption"))){
                guanyadesLabel.setText(messages.getString("guanyadesLabel") + ": " + cp.getEstadistiquesUsuari()[1]);
                perdudesLabel.setText(messages.getString("perdudesLabel") + ": " + cp.getEstadistiquesUsuari()[4]);
                tempsPartidaLabel.setText(messages.getString("tempsPartidaLabel") + ": "+ cp.getEstadistiquesUsuari()[7]);
                duracioPromigLabel.setText(messages.getString("duracioPromigLabel") + ": " + cp.getEstadistiquesUsuari()[10]);
                millorLabel.setText(messages.getString("millorLabel") + ": " + cp.getEstadistiquesUsuari()[13]);
                promigLabel.setText(messages.getString("promigLabel") + ": " + cp.getEstadistiquesUsuari()[16]);
            }
            else if (opcioSeleccionada.equals(messages.getString("dificilOption"))){
                guanyadesLabel.setText(messages.getString("guanyadesLabel") + ": " + cp.getEstadistiquesUsuari()[2]);
                perdudesLabel.setText(messages.getString("perdudesLabel") + ": " + cp.getEstadistiquesUsuari()[5]);
                tempsPartidaLabel.setText(messages.getString("tempsPartidaLabel") + ": "+ cp.getEstadistiquesUsuari()[8]);
                duracioPromigLabel.setText(messages.getString("duracioPromigLabel") + ": " + cp.getEstadistiquesUsuari()[11]);
                millorLabel.setText(messages.getString("millorLabel") + ": " + cp.getEstadistiquesUsuari()[14]);
                promigLabel.setText(messages.getString("promigLabel") + ": " + cp.getEstadistiquesUsuari()[17]);
             }
    }

    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        cp.getEstadistiquesUsuari();

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        panelEstadistiques = new JPanel();
        panelEstadistiques.setLayout(null);

        dificultatLabel.setText(messages.getString("dificultatLabel"));

        enrereButton = new JButton(messages.getString("enrereButton"));
        estadistiquesLabel = new JLabel(messages.getString("estadistiquesLabel"));
        dificultatComboBox = new JComboBox(new String[]{messages.getString("facilOption"), messages.getString("mitjaOption"), messages.getString("dificilOption")});
        dificultatComboBox.setSelectedItem(messages.getString("facilOption"));
        actualitzaLabels(messages.getString("facilOption"));

        estadistiquesLabel.setBounds(320, 30, 200, 30);
        enrereButton.setBounds(20, 380, 100, 30);
        dificultatComboBox.setBounds(20, 70, 200, 30);
        guanyadesLabel.setBounds(20, 120, 200, 30);
        perdudesLabel.setBounds(20, 160, 200, 30);
        tempsPartidaLabel.setBounds(20, 200, 200, 30);
        duracioPromigLabel.setBounds(20, 240, 200, 30);
        millorLabel.setBounds(20, 280, 200, 30);
        promigLabel.setBounds(20, 320, 200, 30);

        panelEstadistiques.add(estadistiquesLabel);
        panelEstadistiques.add(enrereButton);
        panelEstadistiques.add(dificultatComboBox);
        panelEstadistiques.add(guanyadesLabel);
        panelEstadistiques.add(perdudesLabel);
        panelEstadistiques.add(tempsPartidaLabel);
        panelEstadistiques.add(duracioPromigLabel);
        panelEstadistiques.add(millorLabel);
        panelEstadistiques.add(promigLabel);

        setContentPane(panelEstadistiques);

        dificultatComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String opcioSeleccionada = (String) dificultatComboBox.getSelectedItem();
                actualitzaLabels(opcioSeleccionada);
            }
        });

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPerfil vp = new VistaPerfil(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });
    }
}
