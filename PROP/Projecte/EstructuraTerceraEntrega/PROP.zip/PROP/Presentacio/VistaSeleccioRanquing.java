package Presentacio;

import Domain.Dificultat;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class VistaSeleccioRanquing extends JFrame {
    private ControladorPresentacio cp;
    private JPanel panelSeleccionarRanquing;
    private JButton enrereButton;
    private JButton usuarisButton;
    private JButton partidesButton;
    private JLabel SeleccioRanquingLabel;

    public VistaSeleccioRanquing(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        panelSeleccionarRanquing = new JPanel();
        panelSeleccionarRanquing.setLayout(null);

        SeleccioRanquingLabel = new JLabel(messages.getString("seleccioRanquingLabel"));
        enrereButton = new JButton(messages.getString("enrereButton"));
        usuarisButton = new JButton(messages.getString("ranquingUsuarisButton"));
        partidesButton = new JButton(messages.getString("ranquingPartidesButton"));

        SeleccioRanquingLabel.setBounds(315, 30, 200, 30);
        enrereButton.setBounds(20, 380, 100, 30);
        usuarisButton.setBounds(165, 100, 200, 30);
        partidesButton.setBounds(375, 100, 200, 30);

        panelSeleccionarRanquing.add(SeleccioRanquingLabel);
        panelSeleccionarRanquing.add(enrereButton);
        panelSeleccionarRanquing.add(usuarisButton);
        panelSeleccionarRanquing.add(partidesButton);

        setContentPane(panelSeleccionarRanquing);

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaMenuPrincipal vmp = new VistaMenuPrincipal(cp);
                vmp.setVisible(true);
                setVisible(false);
            }
        });

        usuarisButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaRanquingUsuaris vru = new VistaRanquingUsuaris(cp);
                vru.setVisible(true);
                setVisible(false);
            }
        });

        partidesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaRanquingPartides vrp = new VistaRanquingPartides(cp);
                vrp.setVisible(true);
                setVisible(false);
            }
        });
    }
}