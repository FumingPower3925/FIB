package Presentacio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class VistaEsborrarCompte extends JFrame{

    private ControladorPresentacio cp;
    private JPanel panelEsborrarCompte;
    private JButton enrereButton;
    private JButton siButton;
    private JButton noButton;
    private JLabel esborrarCompteLabel;

    public VistaEsborrarCompte(ControladorPresentacio cp) {
        this.cp = cp;
        initComponents();
    }

    private void initComponents() {
        setTitle("Ubermind 2.0");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(740, 480);
        setLocationRelativeTo(null);
        setVisible(true);

        ResourceBundle messages = ResourceBundle.getBundle("messages", new Locale(cp.getIdioma()));

        panelEsborrarCompte = new JPanel();
        panelEsborrarCompte.setLayout(null);

        esborrarCompteLabel = new JLabel(messages.getString("esborrarCompteLabel"));
        enrereButton = new JButton(messages.getString("enrereButton"));
        siButton = new JButton(messages.getString("siButton"));
        noButton = new JButton(messages.getString("noButton"));

        esborrarCompteLabel.setBounds(250, 30, 500, 30);
        enrereButton.setBounds(20, 380, 100, 30);
        siButton.setBounds(250, 100, 100, 30);
        noButton.setBounds(400, 100, 100, 30);

        panelEsborrarCompte.add(esborrarCompteLabel);
        panelEsborrarCompte.add(enrereButton);
        panelEsborrarCompte.add(siButton);
        panelEsborrarCompte.add(noButton);

        setContentPane(panelEsborrarCompte);

        enrereButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPerfil vp = new VistaPerfil(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });

        siButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaBenvinguda vb = new VistaBenvinguda(cp);
                cp.esborrarCompte(cp.getUsuariActual());
                vb.setVisible(true);
                setVisible(false);
            }
        });

        noButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VistaPerfil vp = new VistaPerfil(cp);
                vp.setVisible(true);
                setVisible(false);
            }
        });
    }

}