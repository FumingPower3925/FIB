import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.logging.Logger;

import Domain.*;
import Domain.Partida.Colors;
import Domain.Partida.TipusPartida;
import Presentacio.ControladorPresentacio;

import static java.lang.System.exit;
/**
 * Classe Ubermind
 *
 * Conté la interacció i intefície
 *
 * @author Albert Bausili Fernández
 */
public class Ubermind {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ControladorPresentacio cp = new ControladorPresentacio();
                    cp.iniciaPrograma();
                } catch (IOException ex) {
                    System.out.println("Error en el main");
                }
            }
        });
    }
}
