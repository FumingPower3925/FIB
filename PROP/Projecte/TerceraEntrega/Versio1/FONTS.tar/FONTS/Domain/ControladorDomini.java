package Domain;

import Domain.Partida.*;
import Domain.Usuari.*;
import Domain.Ranquing.*;

import java.time.*;
import java.util.*;

/**
 * Classe Controlador de Domini
 *
 * Conté les estructures de dades de correspondència de controladors de Partida, Usuari i Rànquing i mètodes relacionats amb casos d'ús
 *
 * @author Noa Yu Ventura Vila
 */

public class ControladorDomini {

    ControladorPartida cp;
    ControladorRanquing cr;
    ControladorUsuaris cu;

    public ControladorDomini() {
        cr = new ControladorRanquing();
        cp = new ControladorPartida();
        cu = new ControladorUsuaris();
    }

    /*
    Índex
        Partida
        Ranquing
        Usuari
        Gestió Partides
        Misc
    */

    //--------------------------------------------------------------Partida--------------------------------------------------------------

    /**
     * Obtenim si l'usuari ha demanat ajuda o no en la partida
     * Cost: O(1) en tots els casos
     * @param uid ID de la partida de la que volem saber si l'usuari ha demanat ajuda
     * @return true si l'usuari ha demanat ajuda, false en cas contrari
     */
    public boolean getUsatAjuda(int uid) {
        return cp.getUsatAjuda(uid);
    }

    /**
     * Obtenim si és el torn de la IA per jugar com a codebreaker
     * Cost: O(1) en tots els casos
     * @param uid ID de la partida de la que volem saber si és el torn de la IA o no
     * @return <CODE>true</CODE> si és el torn de la IA per jugar com a codebreaker, <CODE>false</CODE> en cas contrari
     */
    public boolean getTornIA(int uid) {return cp.getTornIA(cu.getPidPartidaActiva(uid));}

    /**
     * Funció que et dóna l'ajuda per a l'usuari. Et dóna la posició correcte d'una de les fitxes del codi del codemaker
     * Cost: O(n); on n és el nombre de columnes del tauler
     * @param uid ID de l'usuari que ha demanat ajuda
     * @return una parella de:
     *          1. Colors: el color de la fitxa
     *          2. Integer: la posició on està la fitxa
     */
    public Pair<Colors,Integer> demanarAjuda(int uid) {
        cp.setUsatAjuda(cu.getPidPartidaActiva(uid));
        return cp.demanarAjuda(cu.getPidPartidaActiva(uid));
    }

    /**
     * Obtenim el tauler de la partida
     * Cost: O(n*m); on n és el nombre de files, m és el nombre de columnes del tauler
     * @param uid ID de l'usuari de la que volem obtenir el tauler
     * @return el tauler de la partida
     */
    public Colors[][] getTauler(int uid) {
        return cp.getTauler(cu.getPidPartidaActiva(uid));
    }

    //--------------------------------------------------------------Ranquing--------------------------------------------------------------

    /**
     * Obté els rànquings d'usuaris
     * Cost: O(1) en tots els casos
     * @return un array de llistes de pairs de float i int que són els rànquings d'usuaris, un per cada dificultat
     */
    public LinkedList<Pair<Float, Integer>> ranquingUsuaris(Dificultat dif) { return cr.consultarRanquingUsuaris(dif); }

    /**
     * Obté els rànquings de partides
     * Cost: O(1) en tots els casos
     * @return Retorna un array de llistes de pairs de dos int que són els rànquings de partides, un per cada dificultat
     */

    public LinkedList<Pair<Integer, Integer>> ranquingPartides(Dificultat dif) { return cr.consultarRanquingPartides(dif); }

    /**
     * Quan un usuari acaba una partida s'han d'actualitzar els rànquings de partides i usuaris
     * Cost: Cost: O(1) en cas millor, O(n) en cas pitjor; on n és el nombre d'usuaris que hi ha al rànquing
     * @param dif és la dificultat de la partida
     * @param uid és l'identificador de l'usuari
     * @param puntuacio és la puntuació que ha fet l'usuari en la partida acabada
     */
    public void actualitzaRanquing(Dificultat dif, int uid, int puntuacio) {
        cr.afegirRanquingPartida(dif, puntuacio, uid);
        if (cu.getHaJugat(uid, dif)) cr.modificarRanquingUsuari(dif,(cu.getRatiDeVictories(uid, dif)), uid);
        else cr.afegirRanquingUsuari(dif,(1.0f), uid);
    }

    //--------------------------------------------------------------Usuari--------------------------------------------------------------

    /**
     * Dona d'alta un nou usuari al sistema amb el següent id i l'afegeix a la llista de paràmetres i fa lo propi amb les
     * estadístiques d'aquest usuari
     * Cost: O(1) amortitzat
     * @param nomU Nom que mostrarem a l'usuari i en el rànquing
     * @param contrasenyaU Contrasenya que utilitzarà l'usuari per a fer login a l'aplicació
     * @return l'identificador del nou usuari
     */
    public int altaUsuari(String nomU, String contrasenyaU) {
        return cu.afegirUsuari(nomU, contrasenyaU);
    }


    /**
     * Dona de baixa un usuari (l'elimina del sistema)
     * Cost: O(1) en tots els casos
     * @param uid Identificador de l'usuari a eliminar
     */
    public void baixaUsuari(int uid) {
        cu.esborrarUsuari(uid);
    }

    /**
     * Intenta fer login amb les credencials introduïdes
     * Cost: O(1) en tots els casos
     * @param nom nom a comprovar
     * @param contrasenya contrasenya a comprovar
     * @return retorna el uid del usuari o -1 si ha sigut un login incorrecte
     */
    public int loginUsuari(String nom, String contrasenya) {
        System.out.println("loginUsuari");
        return cu.comprovarCredencials(nom, contrasenya);
    }

    /**
     * Canviem el nom de l'usuari, la contrasenya o els dos
     * Cost: O(1) en tots els casos
     * @param mode Pren valor 0 per canviar només el nom, valor 1 per canviar la contrasenya i 2 per canviar els dos
     * @param uid id del usuari al que canviar-li els atributs
     * @param nou pot contenir el nom o la contrasenya
     */
    public void canviaUsuari(boolean mode, int uid, String nou) {
        if (mode) cu.canviaContrasenya(uid, nou);
        else cu.canviaNom(uid, nou);
    }

    /**
     * Comprova si existeix un usuari amb el nom introduït
     * Cost: O(1) en tots els casos
     * @param nom conté el nom que es vol comprovar
     * @return un boleà indicant si existeix un usuari amb el nom indicat. True en cas afirmatiu, false en cas contrari
     */
    public boolean comprovarNom(String nom) {
        return cu.existeixNom(nom);
    }

    /**
     * Obté les dades de l'usuari: la seva ID, el nom i si té una partida pausada o no
     * @param id identificador del usuari del que retornar les dades
     * @return array de quatre posicions amb els paràmetres en l'ordre ID de l'usuari, el seu nom, la seva contrasenya, i si té una partida pausada o no
     */
    public String[] dadesUsuari(int id) {
        return cu.getUsuari(id);
    }

    /**
     * Obté la data de la creació del compte de l'usuari
     * @param id identificador de l'usuari del que retornar la data
     * @return Date amb la data de creació del compte de l'usuari
     */
    public Date dataCreacioCompteUsuari(int id) {
        return cu.getDataCreacioCompte(id);
    }

    /**
     * Obté l'historial de l'usuari en forma d'array de resultats de les partides que ha jugat l' usuari
     * Cost: O(1) en tots els casos
     * @param id identificador de l'usuari del que retornar l'historial
     * @return arraylist de resultats que volem obtenir, que contenen:
     *         1. int[]:
     *              a. El tipus de partida: != 0 entrenament, = 0 ranked
     *              b. Les rondes que ha fet l'usuari
     *              c. Les rondes que ha fet la IA
     *              d. El temps que ha durat la partida en segons
     *              e. La puntuacio de la partida
     *         2. LocalDateTime: el moment en que es va començar a jugar la partida
     *
     */
    public ArrayList<Pair<int[],LocalDateTime>> historialUsuari(int id) {
        return cp.getResultatMultiple(cu.getHistorial(id));
    }

    /**
     * Obté totes les estadístiques de l'usuari
     * Cost: O(1) en tots els casos
     * @param id identificador de l'usuari del que retornar les estadístiques
     * @return un array d'ints amb les estadístiques de l'usuari en l'ordre que estan guardades
     */
    public int[] estadistiquesUsuari(int id) {
        return cu.getEstadistiquesUsuari(id);
    }

    /**
     * Quan un usuari acaba partida s'han d'actualitzar les seves estadístiques
     * Cost: O(1) en tots els casos
     * @param uid és l'identificador de l'usuari
     * @param resultat és el resultat de la partida que ha acabat
     */
    public void actualitzaEstadistiques(int uid, int[] resultat) {
        cu.afegirEstadistiques(uid, resultat);
    }

    /**
     * Quan un usuari acaba partida s'ha d'actualitzar el seu historial
     * Cost: O(1) en tots els casos
     * @param uid es l'identificador de l'usuari
     * @param rid és l'identificador del resultat de la partida que ha acabat
     */
    public void actualitzaHistorial(int uid, int rid) {
        cu.afegirResultatHistorial(uid, rid);
    }

    //--------------------------------------------------------------Gestió partides--------------------------------------------------------------

    /**
     * Obtenim la ID de la partida corresponent a l'usuari que la va començar
     * Cost: O(1) en tots els casos
     * @param uid ID de l'usuari que té la partida amb ID uid activa. Assumim que existeix l'usuari amb ID uid
     * @return ID de la partida que l'usuari té activa
     */
    public int getUsuariPartidaActiva(int uid) {
        return cu.getPidPartidaActiva(uid);
    }

    /**
     * L'usuari inicia una nova partida. Aparellem l'usuari amb la partida que acaba de començar
     * Cost: O(1) amortitzat
     * @param uid ID de l'usuari que té la partida antiga que no volem guardar. Assumim que existeix l'usuari amb ID uid
     * @return la ID de la nova partida que s'ha creat
     */
    public int reiniciarPartida(int uid) {
        int old_pid = cu.getPidPartidaActiva(uid);
        int new_pid = cp.afegirPartida(cp.getDificultat(old_pid), cp.getTipusPartida(old_pid), cp.getNfiles(old_pid), cp.getNcolumnes(old_pid), cp.getNcolors(old_pid));
        cu.setPidPartidaActiva(uid, new_pid);
        return new_pid;
    }

    /**
     * Pausem la partida guardant els seus valors
     * Cost: O(1) en tots els casos
     * @param uid ID de la partida que volem pausar
     */
    public void pausarPartida(int uid) {
        cp.incTempsPartida(cu.getPidPartidaActiva(uid));
    }

    /**
     * Reprenem la partida guardant els seus valors
     * Cost: O(1) en tots els casos
     * @param uid ID de la partida que volem reanudar
     * @return un array de int amb els següents paràmetres:
     *              1. El tipus de partida: 0 és de tipus entrenament, 1 és de tipus ranked
     *              2. La dificultat de la partida: 1 és de dificultat fàcil, 2 és de dificultat intermitja, 3 és de dificultat difícil
     *              3. El nombre de files que té el tauler de la partida
     *              4. El nomrbe de columnes que té el tauler de la partida
     *              5. El nombre de colors possibles per a encertar el codi del codemaker
     */
    public int[] rependrePartida(int uid) {
        int id_partida = cu.getPidPartidaActiva(uid);
        cp.setIniciPartida(id_partida);

        int[] res = new int[5];
        if (cp.getTipusPartida(id_partida) == TipusPartida.entrenament) res[0] = 0;
        else if (cp.getTipusPartida(id_partida) == TipusPartida.ranked) res[0] = 1;
        if (cp.getDificultat(id_partida) == Dificultat.facil) res[1] = 1;
        else if (cp.getDificultat(id_partida) == Dificultat.intermig) res[1] = 2;
        else if (cp.getDificultat(id_partida) == Dificultat.dificil) res[1] = 3;
        res[2] = cp.getNfiles(id_partida);
        res[3] = cp.getNcolumnes(id_partida);
        res[4] = cp.getNcolors(id_partida);

        return res;
    }

    /**
     * L'usuari inicia una nova partida. Aparellem l'usuari amb la partida que acaba de començar
     * Cost: O(1) en tots els casos
     * @param uid ID de l'usuari que ha començat la partida
     * @param dif dificultat de la partida
     * @param tipusP tipus de la partida
     * @param nColumns número de columnes del tauler
     * @param nColors número de colors que hauran al joc
     * @return la ID de la nova partida que s'ha iniciat
     */
    public int iniciarPartida(int uid, Dificultat dif, TipusPartida tipusP, int nFiles, int nColumns, int nColors) {
        int pid = cp.afegirPartida(dif, tipusP, nFiles, nColumns, nColors);
        cu.setPidPartidaActiva(uid, pid);
        return pid;
    }

    /**
     * Abandonem la partida activa que té l'usuari amb ID uid. Això vol dir no guardar res i esborrar-la
     * Cost: O(1) en tots els casos
     * @param uid ID de l'usuari
     */
    public void abandonarPartida(int uid) {
        cp.esborrarPartida(cu.getPidPartidaActiva(uid));
        cu.setPidPartidaActiva(uid, -1);
    }

    /**
     * Acabem la partida fent:
     *          1. Afegint el resultat al conjunt de resultats
     *          2. Actualitzant el rànquing
     *          3. Actualitzant l'historial
     *          4. Actualitzant les estadístiques de l'usuari que ha acabat la partida
     * Cost: O(1) en tots els casos
     * @param uid ID de l'usuari que ha acabat la partida
     * @return un array de int amb el següent significat:
     *          1. El temps que ha durat en segons
     *          2. Les rondes que ha fet l'usuari
     *          3. Les rondes que ha fet la IA
     *          4. La puntuació de la partida
     *          5. Si l'usuari ha demanat ajuda o no. True si n'ha demanat, false si no n'ha demanat
     */
    public int[] acabarPartida(int uid) {
        int pid = cu.getPidPartidaActiva(uid);
        int ret[] = new int[5];
        if (uid != -1) {

            cu.setPidPartidaActiva(uid, -1);

            cp.incTempsPartida(pid);

            int puntuacio = cp.calcularPuntuacio(pid); //el id del tauler és igual al de la partida


            //1.
            //Utilitzarem el id del resultat per guardar-lo a l'historial

            int rid = cp.afegirResultat(pid);

            //2.
            boolean guanyat = false;
            if (cp.getRondesUsuari(pid) > cp.getRondesIA(pid)) guanyat = true;
            actualitzaRanquing(cp.getDificultat(pid), uid, puntuacio);
            //3.
            actualitzaHistorial(uid, rid);

            //En la posició 1 indiquem la dificultat de la partida
            int[] res = new int[4];
            switch (cp.getDificultat(pid)) {
                case facil:
                    res[0] = 1;
                    break;
                case intermig:
                    res[0] = 2;
                    break;
                case dificil:
                    res[0] = 3;
                    break;
                default:
                    //error, no hauria de ser possible que arribi aquí la funció
            }

            //En la posició 2 indquem si l'usuari ha guanyat contra la IA o no
            if (guanyat) res[1] = 1;
            else res[1] = 0;

            //En les posicions 3 i 4 indiquem el temps que ha durat la partida i la seva puntuacio respectivament
            int segons = (int) cp.getTempsPartida(pid).getSeconds();
            System.out.println("segons: " + segons);
            res[2] = segons;
            res[3] = puntuacio;

            //4.
            actualitzaEstadistiques(uid, res);

            //Retornem la informació de la partida
            ret[0] = segons;
            ret[1] = cp.getRondesUsuari(pid);
            ret[2] = cp.getRondesIA(pid);
            ret[3] = puntuacio;
            if (cp.getUsatAjuda(pid)) ret[4] = 1;
            else ret[4] = 0;

            comprovarRecords(uid, guanyat, cp.getRondesUsuari(pid), cp.getTipusPartida(pid), cp.getDificultat(pid));

            cp.esborrarPartida(pid);
            return ret;
        }

        //Retornem la informació de la partida
        cp.incTempsPartida(pid);
        ret[0] = Long.valueOf(cp.getTempsPartida(pid).getSeconds()).intValue();
        ret[1] = cp.getRondesUsuari(pid);
        ret[2] = cp.getRondesIA(pid);
        ret[3] = cp.calcularPuntuacio(pid);
        if (cp.getUsatAjuda(pid)) ret[4] = 1;
        else ret[4] = 0;
        cp.esborrarPartida(pid);

        return ret;
    }

    //--------------------------------------------------------------Misc--------------------------------------------------------------

    /**
     * Comprovem si el codi del codebreaker que s'ha entrat és el correcte i informem si queden més files per seguir jugant una altra ronda
     * Cost: O(n^2) cas pitjor i mig, O(n) cas millor; on n és el nombre de columnes del tauler
     * @param pid ID del tauler del que volem comprovar el codi
     * @param entered_code codi que ha entrat el codebreaker per intentar adivinar el codi del codemaker. Té tantes posicions com columnes té el tauler
     * @return una parella que conté:
     *          1. Un boolean que indica si hi ha més files per jugar una altra ronda, amb un altre boolean que indica si el codebreaker ha encertat el codi
     *          2. Un array de tantes posicions com columnes tingui el paràmetre entrat indicant quants colors s'han encertat
     */
    public Pair<Pair<Boolean,Boolean>,Colors[]> comprovarCodi(int pid, Colors[] entered_code) {
        return cp.comprovarCodi(pid, entered_code);
    }

    /**
     * Recolecta totes les jugades fetes per la IA per resoldre el codi
     * Cost: O(maxSteps * (colors^n + n^3)); on n és la longitud de la solució per a l'algoritme FiveGuess
     * Cost: O(n) en el millor cas, O(maxGeneracions * m * n^3) en el pitjor dels casos; on n és el nombre d'individus de la població, maxGeneracions és els intents per a l'algoritme Genètic
     * @param pid ID de la partida en la qual estem jugant
     * @param colorsSeleccionats solució que proposa l'usuari com a codemaster
     */
    public ArrayList<Colors[]> iniciaJugadaIA(int pid, Colors[] colorsSeleccionats){
        return cp.obteJugadesIA(pid, colorsSeleccionats);
    }

    /**
     * Comprovem quins rècords s'han completat en aquesta partida. Passa per paràmetre a controlador d'usuaris:
     *          1. La ID de l'usuari
     *          2. Si l'usuari ha guanyat o no
     *          3. Les rondes que ha fet l'usuari en aquesta partida
     *          4. El tipus de partida: 0 ranked, 1 entrenament
     *          5. La dificultat de la partida: 1 facil, 2 intermig, 3 difícil
     * Cost: O(1) en tots els casos
     * @param uid ID de l'usuari que ha jugat la partida
     * @param guanyat indica si l'usuari ha guanyat a la IA o no; true en cas afirmatiu, false en cas contrari
     * @param rondesUsuari rondes que ha fet l'usuari en la partida
     * @param tipusP el tipus de la partida
     * @param dif dificultat de la partida
     */
    public void comprovarRecords(int uid, boolean guanyat, int rondesUsuari, TipusPartida tipusP, Dificultat dif) {
        int res[] = new int[5];
        res[0] = uid;

        if (guanyat) res[1] = 1;
        else res[1] = 0;
        res[2] = rondesUsuari;
        if (tipusP == TipusPartida.ranked) res[3] = 0;
        else res[3] = 1;

        if (dif == Dificultat.facil) res[4] = 1;
        else if (dif == Dificultat.intermig) res[4] = 2;
        else if (dif == Dificultat.dificil) res[4] = 3;
        cu.comprovarRecords(res);
    }

    /**
     * Retorna tota la informació sobre els rècords de l'usuari
     * COst: O(1) en tots els casos
     * @param uid ID de l'usuari que ha demanat consultar els seus rècords
     * @return un arraylist amb tots els rècords que hi ha al sistema (String) i si l'usuari els ha completat o no (Boolean)
     */
    public ArrayList<Pair<String,Boolean>> consultarRecords(int uid) {
        return cu.consultarRecords(uid);
    }
}

