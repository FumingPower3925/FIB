package Domain;
/**
 * Classe Dificultat
 *
 * Representa els diferents nivells de dificultat d'una partida
 *
 * @author David Molina and Noa Yu Ventura
 */
public enum Dificultat {
    facil,
    intermig,
    dificil
}