package Domain.Ranquing;

import java.io.Serializable;
import java.util.LinkedList;
import Domain.Dificultat;
import Domain.Pair;

/**
 * Classe Controlador RànquingPartides
 * Conté les estructures de dades i funcions per gestionar els rànquings de partides
 *
 * @author Sergio Delgado Ampudia
 */

public class RanquingPartides extends Ranquing implements Serializable  {

    private final Dificultat dificultat;

    /**
     * Estructura de dades que enmagatzema el raàquing de partides, linked list amb dos integers,
     * que són l'id del resultat de partida i el uid del jugador que ha jugat la partida
     */
    private LinkedList<Pair<Integer, Integer>> Rpartides = new LinkedList<>();

    /**
     * Crea un nou rànquing afegint la dificultat
     * Cost: O(1) en tots els casos
     * @param dif dificultat del rànquing
     */
    RanquingPartides(Dificultat dif) {
        dificultat = dif;
    }

    /**
     * Constructora utilitzada en la persistencia
     * Cost: O(1) en tots els casos
     * @param rp Ranquing de partides ja inicialitzat
     * @param dif Dificultat d'aquest ranquing
     */
    public RanquingPartides(LinkedList<Pair<Integer, Integer>> rp, Dificultat dif) {
        dificultat = dif;
        Rpartides = rp;
    }

    /**
     * Obtenim la dificultat del rànquing de partides
     * Cost: O(1) en tots els casos
     * @return la dificultat del rànquing de partides
     */
    public Dificultat getDificultat() {
        return dificultat;
    }

    /**
     * Obtenim el rànquing de partides complet
     * Cost: O(1) en tots els casos
     * @return rànquing de partides, una llista amb puntuacions i usuaris que han fet les puntuacions
     */
    public LinkedList<Pair<Integer, Integer>> getRanquingPartides() {

        if (Rpartides.isEmpty()) {
            return null;
        }
        return Rpartides;
    }

    /**
     * S'afegeix una posició al rànquing de partida, és a dir, un pair amb la puntuació i l'identificador de l'usuari
     * que l'ha jugat. S'inserta de manera ordenada amb una búsqueda binària
     * Cost: O(1) en el millor cas, O(log(n)) en el pitjor cas; on n és el nombre de partides que hi ha al rànquing
     * @param punt representa la puntuació de l'usuari en una partida
     * @param uid representa l'identificador de l'usuari que ha jugat la partida
     */
    public void afegirRanquingPartides(int punt, int uid) {
        Pair<Integer, Integer> NouPar = new Pair<Integer, Integer>(punt, uid);
        int left = 0;
        if (Rpartides.size() != 0) {
            System.out.println("pasa el inicio");

            System.out.println(Rpartides);
            int right = Rpartides.size() - 1;
            int mid;

            while (left <= right) {
                mid = (left + right) / 2;
                Pair<Integer, Integer> actual = Rpartides.get(mid);
                System.out.println("entra bucle");
                if (actual.getKey() == punt) {
                    Rpartides.add(mid + 1, NouPar);
                    System.out.println("añade al inicio");
                    return;
                }
                else if (actual.getKey() < punt) {
                    left = mid + 1;
                    System.out.println("siguinte");
                }
                else {
                    right = mid - 1;
                }
            }
        }
        Rpartides.add(left, NouPar);
    }
}
