package Domain.Ranquing;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.Iterator;
import Domain.Dificultat;

/**
 * Classe Ranquing
 * Classe abstracta per representar rànquing de partida i usuaris
 *
 * @author Sergio Delgado Ampudia
 */
public abstract class Ranquing implements Serializable {

    protected Dificultat dificultat;

    /**
     * Obtenim la dificultat del rànquing
     * Cost: O(1) en tots els casos
     * @return la dificultat de les partides del rànquing
     */
    public abstract Dificultat getDificultat();

}
