package Domain.Ranquing;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.Iterator;
import Domain.Dificultat;
import Domain.Pair;

/**
 * Classe Controlador RànquingUsuaris
 * Conté les estructures de dades i funcions per gestionar els rànquings d'usuaris
 *
 * @author Sergio Delgado Ampudia
 */

public class RanquingUsuaris extends Ranquing implements Serializable {

    private final Dificultat dificultat;

    /**
     * Estructura de dades que emmagatzema el rànquing d'usuaris, cada posició de la llista està formada per
     * winrate d'un usuari (partides guanyades/partides perdudes) i l'identificador de cada usuari
     */
    private LinkedList<Pair<Float, Integer>> Rusuaris = new LinkedList<>();

    /**
     * Crea un nou rànquing afegint la dificultat
     * Cost: O(1) en tots els casos
     * @param dif dificultat del rànquing
     */
    RanquingUsuaris(Dificultat dif) {
        dificultat = dif;
    }

    /**
     * Creadora utilitzada en la persistencia
     * Cost: O(1) en tots els casos
     * @param ru Ranquing d'usuaris ja iniciat
     * @param dif Dificultat d'aquest ranquing
     */
    public RanquingUsuaris(LinkedList<Pair<Float, Integer>> ru, Dificultat dif) {
        dificultat = dif;
        Rusuaris = ru;
    }

    /**
     * Obtenim la dificultat del rànquing d'usuaris
     * Cost: O(1) en tots els casos
     * @return la dificultat del rànquing d'usuaris
     */
    public Dificultat getDificultat() {
        return dificultat;
    }

    /**
     * Obtenim el rànquing d'usuaris
     * Cost: O(1) en tots els casos
     * @return llista de winrates i uid d'usuaris del rànquing
     */
    public LinkedList<Pair<Float, Integer>> getRanquingUsuaris() {

        if (Rusuaris.isEmpty()) {
            return null;
        }
        return Rusuaris;
    }

    /**
     * S'afegeix un posició al rànquing d'usuaris amb el winrate d'un usuari i l'identificador de l'usuari,
     * es fa de manera ordenada amb una búsqueda binària
     * Cost: O(1) en el millor cas, O(log(n)) en el pitjor cas; on n és el nombre d'usuaris que hi ha al rànquing
     * @param winrate representa la puntuació de l'usuari.
     * @param uid representa l'identificador de l'usuari.
     */
    public void afegirRanquingUsuaris(Float winrate, int uid) {

        Pair<Float, Integer> NouPar = new Pair<Float, Integer>(winrate, uid);

        int left = 0;
        int right = Rusuaris.size() - 1;
        int mid;

        while (left <= right) {
            mid = (left + right) / 2;
            Pair<Float, Integer> actual = Rusuaris.get(mid);

            if (actual.getKey().equals(winrate)) {
                Rusuaris.add(mid + 1, NouPar);
                return;
            }
            else if (actual.getKey() < winrate) {
                left = mid + 1;
            }
            else {
                right = mid - 1;
            }
        }
        Rusuaris.add(left, NouPar);
    }

    /**
     * Quan canvia el winrate d'un usuari, s'elimina la seva posició del rànquing d'usuaris
     * Cost: O(1) en el millor cas, O(n) en el pitjor; on n és el nombre d'usuaris que hi ha al rànquing
     * @param uid representa l'identificador de l'usuari.
     */
    public void eliminarRanquingUsuaris(int uid) {
        Iterator<Pair<Float, Integer>> iter = Rusuaris.iterator();
        while (iter.hasNext()) {
            Pair<Float, Integer> pair = iter.next();
            if (pair.getValue() == uid) {
                iter.remove();
            }
        }
    }

}

