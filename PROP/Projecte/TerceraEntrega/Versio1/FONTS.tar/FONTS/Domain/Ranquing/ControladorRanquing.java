package Domain.Ranquing;

import Domain.Dificultat;
import Domain.Pair;

import java.util.LinkedList;

import static Persistencia.PersistenciaRanquings.*;

/**
 * Classe Controlador Rànquing
 * Conté les estructures de dades i funcions per gestionar els rànquings
 *
 * @author Sergio Delgado Ampudia
 */

public class ControladorRanquing {

    // Agregació de la classe Rànquing
    private Ranquing r;

    // Agregació de la classe RànquingPartides, una per cada dificultat
    private RanquingPartides rpf = new RanquingPartides(Dificultat.facil);
    private RanquingPartides rpi = new RanquingPartides(Dificultat.intermig);
    private RanquingPartides rpd = new RanquingPartides(Dificultat.dificil);

    // Agregació de la classe RànquingUsuaris, una per cada dificultat
    private RanquingUsuaris ruf = new RanquingUsuaris(Dificultat.facil);
    private RanquingUsuaris rui = new RanquingUsuaris(Dificultat.intermig);
    private RanquingUsuaris rud = new RanquingUsuaris(Dificultat.dificil);

    /**
     * Retorna el rànquing d'usuaris en la dificultat demanada. NOTA: els rànquings estan compostos per pairs
     * amb el winrate d'un usuari i el seu identificador
     * Cost: O(1) en tots els casos
     * @param dif dificultat de la que volem obtenir el rànquing d'usuaris. Pren valors: facil, intermig i dificil
     * @return el rànquing d'usuaris en la dificultat especificada al paràmetre
     */
    public LinkedList<Pair<Float, Integer>> consultarRanquingUsuaris(Dificultat dif) {

        LinkedList<Pair<Float, Integer>> ranquingUsuaris;
        if (dif == Dificultat.facil) {
            if (ruf.getRanquingUsuaris().isEmpty() && comprovarSiRanquing(true, dif)) {
                ranquingUsuaris = tornarRanquingUsuaris(dif).getRanquingUsuaris();
            }
            else {
                ranquingUsuaris = ruf.getRanquingUsuaris();
            }
        }
        else if (dif == Dificultat.intermig) {
            if (rui.getRanquingUsuaris().isEmpty() &&  comprovarSiRanquing(true, dif)) {
                ranquingUsuaris = tornarRanquingUsuaris(dif).getRanquingUsuaris();
            }
            else {
                ranquingUsuaris = rui.getRanquingUsuaris();
            }
        }
        else {
            if (rud.getRanquingUsuaris().isEmpty() && comprovarSiRanquing(true, dif)) {
                ranquingUsuaris = tornarRanquingUsuaris(dif).getRanquingUsuaris();
            }
            else {
                ranquingUsuaris = rud.getRanquingUsuaris();
            }
        }
        return ranquingUsuaris;
    }

    /**
     * Retorna els 3 rànquings de partides en les 3 dificultats (fàcil, intermig i difícil). NOTA: rànquings compostos
     * per pairs amb la puntuació d'una partida i l'identificador de l'usuari que l'ha jugat
     * Cost: O(1) en tots els casos
     * @param dif dificultat de la que volem obtenir el rànquing de partides. Pren valors: facil, intermig i dificil
     * @return el rànquing de partides en la dificultat especificada al paràmetre
     */
    public LinkedList<Pair<Integer, Integer>> consultarRanquingPartides(Dificultat dif) {

        LinkedList<Pair<Integer, Integer>> ranquingPartides;
        if (dif == Dificultat.facil) {
            if (rpf.getRanquingPartides().isEmpty() && comprovarSiRanquing(false, dif)) {
                ranquingPartides = tornarRanquingPartides(dif).getRanquingPartides();
            }
            else {
                ranquingPartides = rpf.getRanquingPartides();
            }
        }
        else if (dif == Dificultat.intermig) {
            if (rpi.getRanquingPartides().isEmpty() && comprovarSiRanquing(false, dif)) {
                ranquingPartides = tornarRanquingPartides(dif).getRanquingPartides();
            }
            else {
                ranquingPartides = rpi.getRanquingPartides();
            }
        }
        else {
            if (rpd.getRanquingPartides().isEmpty() && comprovarSiRanquing(false, dif)) {
                ranquingPartides = tornarRanquingPartides(dif).getRanquingPartides();
            }
            else {
                ranquingPartides = rpd.getRanquingPartides();
            }
        }
        return ranquingPartides;
    }

    /**
     * Afegeix una nova posició al rànquing d'usuaris composta pel winrate d'un usuari i el seu uid, es fa segons
     * la dificultat
     * Cost: O(1) en el millor cas, O(log(n)) en el pitjor cas; on n és el nombre d'usuaris que hi ha al rànquing
     * @param dif la dificultat en la què es té en compte el winrate
     * @param winrate partides guanyades/perdudes d'un usuari a una dificultat = dif
     * @param uid l'identificador de l'usuari
     */
    public void afegirRanquingUsuari(Dificultat dif, Float winrate, int uid) {
        if (dif == Dificultat.facil) {
            if (ruf.getRanquingUsuaris().isEmpty() && comprovarSiRanquing(true, dif)) tornarRanquingUsuaris(dif);
            ruf.afegirRanquingUsuaris(winrate, uid);
            guardarRanquingUsuaris(ruf.getRanquingUsuaris(), dif);
        }
        else if (dif == Dificultat.intermig) {
            if (rui.getRanquingUsuaris().isEmpty() && comprovarSiRanquing(true, dif)) tornarRanquingUsuaris(dif);
            rui.afegirRanquingUsuaris(winrate, uid);
            guardarRanquingUsuaris(rui.getRanquingUsuaris(), dif);
        }
        else {
            if (rud.getRanquingUsuaris().isEmpty() && comprovarSiRanquing(true, dif)) tornarRanquingUsuaris(dif);
            rud.afegirRanquingUsuaris(winrate, uid);
            guardarRanquingUsuaris(rud.getRanquingUsuaris(), dif);
        }
    }

    /**
     * Afegeix una nova posició al rànquing de partides composta per la puntuació que ha fet un usuari en una partida
     * i l'uid de l'usuari, es fa segons la dificultat de la partida
     * Cost: O(1) en el millor cas, O(log(n)) en el pitjor cas; on n és el nombre de partides que hi ha al rànquing
     * @param dif és la dificultat en la què es té en compte el winrate
     * @param punt la puntuació final d'un usuari en una partida amb dificultat = dif
     * @param uid és l'identificador de l'usuari
     */
    public void afegirRanquingPartida(Dificultat dif, int punt, int uid) {
        if (dif == Dificultat.facil) {
            if (rpf.getRanquingPartides().isEmpty() && comprovarSiRanquing(false, dif)) tornarRanquingPartides(dif);
            rpf.afegirRanquingPartides(punt, uid);
            guardarRanquingPartides(rpf.getRanquingPartides(), dif);
        }
        else if (dif == Dificultat.intermig) {
            if (rpi.getRanquingPartides().isEmpty() && comprovarSiRanquing(false, dif)) tornarRanquingPartides(dif);
            rpi.afegirRanquingPartides(punt, uid);
            guardarRanquingPartides(rpi.getRanquingPartides(), dif);
        }
        else {
            if (rpd.getRanquingPartides().isEmpty() && comprovarSiRanquing(false, dif)) tornarRanquingPartides(dif);
            rpd.afegirRanquingPartides(punt, uid);
            guardarRanquingPartides(rpd.getRanquingPartides(), dif);
        }
    }

    /**
     * Quan un usuari juga una partida en una dificultat en la què ja havia jugat abans, s'elimina del rànquing
     * d'usuaris i es torna a afegir amb el nou winrate
     * Cost: O(1) en cas millor, O(n) en cas pitjor; on n és el nombre d'usuaris que hi ha al rànquing
     * @param dif la dificultat en la què es té en compte el winrate
     * @param winrate partides guanyades/perdudes d'un usuari a una dificultat = dif
     * @param uid l'identificador de l'usuari
     */
    public void modificarRanquingUsuari(Dificultat dif, Float winrate, int uid) {

        if (dif == Dificultat.facil) {
            if (ruf.getRanquingUsuaris().isEmpty() && comprovarSiRanquing(true, dif)) tornarRanquingUsuaris(dif);
            ruf.eliminarRanquingUsuaris(uid);
            ruf.afegirRanquingUsuaris(winrate, uid);
            guardarRanquingUsuaris(ruf.getRanquingUsuaris(), dif);
        }
        else if (dif == Dificultat.intermig) {
            if (rui.getRanquingUsuaris().isEmpty() && comprovarSiRanquing(true, dif)) tornarRanquingUsuaris(dif);
            rui.eliminarRanquingUsuaris(uid);
            rui.afegirRanquingUsuaris(winrate, uid);
            guardarRanquingUsuaris(rui.getRanquingUsuaris(), dif);
        }
        else {
            if (rud.getRanquingUsuaris().isEmpty() && comprovarSiRanquing(true, dif)) tornarRanquingUsuaris(dif);
            rud.eliminarRanquingUsuaris(uid);
            rud.afegirRanquingUsuaris(winrate, uid);
            guardarRanquingUsuaris(rud.getRanquingUsuaris(), dif);
        }
    }

}
