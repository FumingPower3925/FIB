package Domain.Usuari;

import Domain.Dificultat;
import Domain.Idioma;
import Domain.Pair;
import Domain.Quartet;

import java.util.*;

import static Persistencia.PersistenciaUsuaris.*;
import static java.lang.System.arraycopy;

/**
 * Classe Controlador Usuaris
 *
 * Conté conte les estructures de dades i funcions per gestionar els usuaris i les estadístiques
 *
 * @author Albert Bausili Fernández
 */
public class ControladorUsuaris {

    // Agregació de la classe Usuari
    private Usuari Usr;

    // Agregació de la classe Estadistiques
    private Estadistiques Est;

    // Agragació de la classe Records
    private Records Rec;

    // Agragació de la classe Historial
    private Historial Hist;

    private static Usuari usuari;

    /**
     * Estructura de dades que relaciona els noms dels usuaris amb la seva uid
     * {@code private static final HashMap<String, Integer> cjt_nomUid = new HashMap<String, Integer>();}
     */
    private static HashMap<String, Integer> cjt_nomUid = new HashMap<>();

    private static Historial historialUsuari;

    private static Estadistiques estadistiques;

    private static Records records;

    /**
     * Crea un nou usuari amb el seguent id i l'afageix a la llista de parametres i fa lo propi amb les estadistiques
     * d'aquest usuari, retorna un id igual a -1 si ja existeix un usuari amb aquest nom
     * Cost: O(1) amortitzat
     * @param nomU Nom que mostrarem al usuari i en el rànking
     * @param contrasenyaU Contrasenya que utilitzara l'usuari per a fer login a la applicació
     * @return el identificador del nou usuari
     * @exception IncompatibleClassChangeError No s'han pogut modificar les llistes de la classe
     */
    public int afegirUsuari(String nomU, String contrasenyaU) {
        int id = -1;
        if (cjt_nomUid.isEmpty() && comprovarSiNomUid()) cjt_nomUid = tornarNomUid();
        if (!existeixNom(nomU)) {
            id = cjt_nomUid.size();
            try {
                usuari = new Usuari(id, nomU, contrasenyaU);
                cjt_nomUid.put(nomU, id);
                estadistiques = new Estadistiques(id);
                records = new Records(id);
                historialUsuari = new Historial(id);

                persistenciaUsuari();
                guardarNomUid(cjt_nomUid);
            }
            catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        return id;
    }

    /**
     * Marca com esborrat del sistema a l'usuari
     * Cost: O(1) en tots els casos
     * @param uid Identificador del usuari a eliminar
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public void esborrarUsuari(int uid) {
        if (existeixUsuari(uid)) {
            usuari.setEsborrat();
            cjt_nomUid.remove(usuari.getNom());
            persistenciaUsuari();
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
    }

    /**
     * Comprova si el usuari no ha estat borrat
     * Cost: O(1) en tots els casos
     * @param uid Identificador del usuari a comprovar
     * @return Retorna un boolean indicant si l'usuari ha estat borrat o no
     */
    public boolean existeixUsuari(int uid) {
        return usuari.getUid() == uid;
    }

    /**
     * Comprova si existeix un usuari amb el nom introduit
     * Cost: O(1) en tots els casos
     * @param nom String que conté el nom que es vol comprovar
     * @return Retorn un boolean indicant si existeix un usuari amb el nom indicat
     */
    public boolean existeixNom(String nom) {
        return cjt_nomUid.containsKey(nom);
    }

    /**
     * Comprova les credenecials de l'usuari i si son correctes "entra" en la sessió
     * Cost: O(1) en tots els casos
     * @param nom Nom a comprovar
     * @param contrasenya Contrasenya a comprovar
     * @return retorna el uid del usuari o -1 si ha estat un login incorrecte
     */
    public int comprovarCredencials(String nom, String contrasenya) {
        if (cjt_nomUid.containsKey(nom)){
            int uid = cjt_nomUid.get(nom);
            Quartet<Usuari, Estadistiques, Records, Historial> possibleUsuari = tornarUsuari(uid);
            // Comprovem si el usuari ha estat esborrat
            if (!possibleUsuari.getPrimer().getEsborrat()) {
                // Comprovem si el nom i la contrasenya corresponen a les de l'usuari
                if (Objects.equals(possibleUsuari.getPrimer().getNom(), nom) && Objects.equals(possibleUsuari.getPrimer().getContrasenya(), contrasenya)) {
                    usuari = possibleUsuari.getPrimer();
                    estadistiques = possibleUsuari.getSegon();
                    records = possibleUsuari.getTercer();
                    historialUsuari = possibleUsuari.getQuart();
                    return uid;
                }
            }
        }
        return -1;
    }

    /**
     * Introdueix les dades de l'usuari en un Array de strings i ho retorna
     * Cost: O(1) en tots els casos
     * @return Retorna en un Array de strings les dades de l'usuari en el següent ordre:
     *        1. Identificador de l'usuari {"uid"}
     *        2. Nom de l'usuari {nom}
     *        3. Contrasenya de l'usuari {contrasenya}
     *        4. Si té una partida pausada o no {"true" || "false"}
     * @exception IndexOutOfBoundsException L'índex es troba en una posició no contemplada
     */
    public String[] getUsuari (int uid) {
        String[] dadesUsuari = new String[4];
        for (int i = 0; i < dadesUsuari.length; ++i) {
            switch (i) {
                case 0:
                    // Afegeix l'identificador de l'usuari a l'array
                    dadesUsuari[i] = String.valueOf(Usr.getUid());
                    break;
                case 1:
                    // Afegeix el nom de l'usuari a l'array
                    dadesUsuari[i] = Usr.getNom();
                    break;
                case 2:
                    // Afegeix la contrasenya de l'usuari a l'array
                    dadesUsuari[i] = Usr.getContrasenya();
                    break;
                case 3:
                    // Afegeix el pid de la partida activa del usuari l'usuari a l'array
                    dadesUsuari[i] = String.valueOf(Usr.getPidPartidaActiva());
                    break;
                default:
                    throw new IndexOutOfBoundsException("L'index es troba en una posició no contemplada");
                }
            }
        return dadesUsuari;
    }

    /**
     * Canvia el nom de l'usuari uid pel nouNom, s'ha de comprovar abans que no existeix un usuari amb el nouNom
     * Cost: O(1) en tots els casos
     * @param uid Identificador del usuari al que modificar el nom
     * @param nouNom Nom pel que modificar el nom existent de l'usuari
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public void canviaNom (int uid, String nouNom) {
        boolean modificat = true;
        if (cjt_nomUid.isEmpty() && comprovarSiNomUid()) cjt_nomUid = tornarNomUid();
        if (existeixUsuari(uid)) {
            if (!cjt_nomUid.containsKey(nouNom)) {
                cjt_nomUid.remove(usuari.getNom());
                usuari.setNom(nouNom);
                cjt_nomUid.put(nouNom, uid);
                persistenciaUsuari();
                guardarNomUid(cjt_nomUid);
            }
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
    }

    /**
     * Canvia la contrasenya de l'usuari uid per la novaContrasenya
     * Cost: O(1) en tots els casos
     * @param uid Identificador de l'usuari al que modificar la contrasenya
     * @param novaContrasenya Contrasenya per la que modificar la contrasenya existent del usuari
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public void canviaContrasenya(int uid, String novaContrasenya) {
        if (existeixUsuari(uid)) {
            usuari.setContrasenya(novaContrasenya);
            persistenciaUsuari();
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
    }

    /**
     * Retorna l'identificador de la partida que té activa l'usuari amb el uid introduït
     * Cost: O(1) en tots els casos
     * @param uid Identificador del usuari del que retornar el identificador de la partida que te activa
     * @return Retorna el pid que identifica la partida que te activa el usuari, -1 si no en te cap
     */
    public int getPidPartidaActiva (int uid) {
        int pid;
        if (existeixUsuari(uid)) {
            pid = usuari.getPidPartidaActiva();
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
        return pid;
    }

    /**
     * L'usuari passarà a tenir una partida en actiu amb el pid introduït en el paràmetre
     * Cost: O(1) en tots els casos
     * @param uid Identificador de l'usuari al que modificar si té una partida guardada
     * @param pid Identificador de la partida que l'usuari te en actiu
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public void setPidPartidaActiva (int uid, int pid) {
        if (existeixUsuari(uid)) {
            usuari.setPidPartidaActiva(pid);
            persistenciaUsuari();
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
    }

    /**
     * Crea i retorna un array de tamany n amb els n resultats de l'usuari amb identificador uid
     * Cost: O(n) en tots els casos; on n és el nombre d'elements del array
     *
     * @param uid Identificador del usuari del que retornar l'historial
     * @return array d'Integers de tamany n
     * @throws IllegalArgumentException L'usuari no existeix
     */
    public Integer[] getHistorial (int uid) {
        // Crea un array de integers de tamany igual a la quantitat de resultats tingui en l'historial
        Integer[] historial = new Integer[historialUsuari.getPartides().size()];
        if (existeixUsuari(uid)) {
            historialUsuari.getPartides().toArray(historial);
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
        return historial;
    }

    /**
     * Afegeix l'identificador del resultat que ha realitzat l'usuari uid en el seu historial
     * Cost: O(1) amortitzat
     * @param uid Identificador de l'usuari al que afegir-ne el resultat
     * @param rid Identificador del resultat a afegir l'historial
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public void afegirResultatHistorial (int uid, int rid) {
        if (existeixUsuari(uid)) {
            historialUsuari.afegirResultat(rid);
            persistenciaUsuari();
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
    }

    /**
     * Retorna les estadístiques de l'usuari en un array de int
     * Cost: O(1) en tots els casos
     * @param id Identificador de l'usuari del que retornar les estadístiques
     * @return Array d'ints amb les diferents estadístiques de l'usuari
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public int[] getEstadistiquesUsuari(int id) {
        int [] estadistiquesUsuari;
        if (existeixUsuari(id)) {
            estadistiquesUsuari = estadistiques.getEstadistiques();
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
        return estadistiquesUsuari;
    }

    /**
     * Afegeix les estadístiques de resultat a les estadístiques de l'usuari identificat per id
     * Cost: O(1) en tots els casos
     * @param id Identificador de l' usuari al que afegir-hi el resultat a les seves estadístiques
     * @param resultat Array de ints que conté la informació del resultat de l'usuari
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public void afegirEstadistiques(int id, int[] resultat) {
        if (existeixUsuari(id)) {
            estadistiques.actualitzarEstadistiques(resultat);
            persistenciaUsuari();
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
    }

    /**
     * Retorna la data de la creació del compte de l'usuari
     * Cost: O(1) en tots els casos
     * @param id Identificador de l'usuari del que retornar la seva data de creació del compte
     * @return un Date amb la data de creació de la compta de l'usuari
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public Date getDataCreacioCompte(int id) {
        Date creacioCompte;
        if (existeixUsuari(id)) {
            creacioCompte = estadistiques.getCreacioCompte();
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
        return creacioCompte;
    }

    /**
     * Retorna el rati de victòries de l'usuari per la dificultat demanada
     * Cost: O(1) en tots els casos
     * @param id Identificador de l'usuari del que retornar el rati de victòries
     * @param dif dificultat per la que volem saber el rati de victòries de l'usuari
     * @return un float amb el rati de victòries de l'usuari
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public float getRatiDeVictories(int id, Dificultat dif) {
        float rati;
        if (existeixUsuari(id)) {
            rati = estadistiques.getRatiVictories(dif);
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
        return rati;
    }

    /**
     * Retorna un boleà indicant si l'usuari ha realitzat alguna partida ja en la dificultat seleccionada
     * Cost: O(1) en tots els casos
     * @param id Identificador de l'usuari del que retornar la infomració
     * @param dif dificultat per la que volem saber si l'usuari ja ha realitzat alguna partida o no
     * @return Retorna un boleà indicant si l'usuari ha realitzat, o no, una partida en la dificultat diff
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public boolean getHaJugat(int id, Dificultat dif) {
        boolean haJugat;
        if (existeixUsuari(id)) {
            haJugat = estadistiques.getPrimeraPartida(dif);
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
        return haJugat;
    }

    /**
     * Reenvia els rècords que l'usuari ha completat i no ha completat juntament amb les descripcions d'aquests
     * Cost: O(1) en tots els casos
     * @param id Es l'identificador de l'usuari del que volem saber els seus rècords
     * @return ArrayList que conté els rècords amb el text i un boleà indicant si l'usuari els ha assolit o no
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public ArrayList<Pair<String, Boolean>> consultarRecords(int id) {
        ArrayList<Pair<String, Boolean>> recordsUsuari;
        if (existeixUsuari(id)) {
            recordsUsuari = records.retornaRecords();
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
        return recordsUsuari;
    }

    /**
     * Comprova si l'usuari ha realitzat algun record en la seva última partida
     * Cost: O(1) en tots els casos
     * @param res conté:
     *                  1. La ID de l'usuari
     *                  2. Si l'usuari ha guanyat o no
     *                  3. Les rondes que ha fet l'usuari en aquesta partida
     *                  4. El tipus de partida: 0 ranked, 1 entrenament
     *                  5. La dificultat de la partida: 1 facil, 2 intermig, 3 difícil
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public void comprovarRecords(int[] res) {
        if (existeixUsuari(res[0])) {
            int[] resultat = new int[4];
            arraycopy(res, 1, resultat, 0, resultat.length);
            records.actualitzarRecords(resultat);
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
    }

    /**
     * Obté el idioma del usuari
     * @param uid identificador del usuari al que tornar el idioma preferit
     * @return retorna el idioma preferit del usuari
     * @exception IllegalArgumentException L'usuari no existeix
     */
    public Idioma getIdiomaUsuari (int uid) {
        Idioma idioma;
        if (existeixUsuari(uid)) {
            idioma = usuari.getIdiomaPreferit();
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
        return idioma;
    }

    /**
     * Canviem el nou idioma preferit de l'usuari per l'introduït
     * @param nouIdioma Representa el nou idioma preferit de l'usuari
     * Cost: O(1) en tots els casos
     * @exception IllegalArgumentException L'usuari no existeix
     */
    void canviarIdiomaUsuari (int uid, Idioma nouIdioma) {
        if (existeixUsuari(uid)) {
            usuari.setIdioma(nouIdioma);
        }
        else {
            throw new IllegalArgumentException("L'usuari no existeix");
        }
    }

    /**
     * Funció auxiliar que envia a persistencia el usuari, estadistiques, records i historial actuals
     */
    private void persistenciaUsuari () {
        Integer uid = usuari.getUid();
        String[] nomCont = {usuari.getNom(), usuari.getContrasenya()};
        Integer pid = usuari.getPidPartidaActiva();
        Boolean esborrat = usuari.getEsborrat();
        Idioma idioma = usuari.getIdiomaPreferit();
        Integer[] est = Arrays.stream(estadistiques.getEstadistiques()).boxed().toArray(Integer[]::new);
        guardarUsuari(new Pair<>(uid, new Quartet<>(nomCont, pid, esborrat, idioma)), new Pair<>(est, estadistiques.getCreacioCompte()), records.getRecords(), historialUsuari.getPartides());
    }
}
