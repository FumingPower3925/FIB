package Domain.Usuari;

import Domain.Idioma;

import java.io.Serializable;

/**
 * Classe Usuari
 * Conté informació dels usuaris que es troben registrats en el sistema
 *
 * @author Albert Bausili Fernández
 */
public class Usuari implements Serializable {
    private final int uid;
    private String nom;
    private String contrasenya;
    private int pidPartidaActiva;
    private boolean esborrat;
    private Idioma idiomaPreferit;

    /**
     * Crea un nou usuari amb els paràmetres demanats, i la resta per defecte
     * Cost: O(1) en tots els casos
     * @param id ID que farem servir per identificar el nou usuari que crearem
     * @param nomU Nom que mostrarem al usuari i en el rànking
     * @param contrasenyaU Contrasenya que utilitzara l'usuari per a fer login a la applicació
     */
    Usuari(int id, String nomU, String contrasenyaU) {
        uid = id;
        nom = nomU;
        contrasenya = contrasenyaU;
        pidPartidaActiva = -1;
        esborrat = false;
        idiomaPreferit = Idioma.catala;
    }

    /**
     * Constructor per a la persistencia, es defineixen tots els parametres
     * Cost: O(1) en tots els casos
     * @param id ID del usuari que recuperem de persistencia
     * @param nomU Nom de l'usuari que volem recuperar
     * @param contrasenyaU Contrassenya de l'usuari que volem recuperar
     * @param pid Pid de la partida que te activa el usuari (-1 si no en te)
     * @param existeix Booleà que indica si l'usuari ha estat borrat o no del sistema
     * @param idioma Idioma preferit pel usuari
     */
    public Usuari(int id, String nomU, String contrasenyaU, int pid, boolean existeix, Idioma idioma) {
        uid = id;
        nom = nomU;
        contrasenya = contrasenyaU;
        pidPartidaActiva = pid;
        esborrat = existeix;
        idiomaPreferit = idioma;
    }

    /**
     * Obtenim l'identificador de l'usuari
     * Cost: O(1) en tots els casos
     * @return el ID de l'usuari
     */
    int getUid () {
        return uid;
    }

    /**
     * Obtenim el nom de l'usuari
     * Cost: O(1) en tots els casos
     * @return el nom de l'usuari
     */
    String getNom () {
        return nom;
    }

    /**
     * Obtenim la contrasenya de l'usuari
     * Cost: O(1) en tots els casos
     * @return la contrasenya de l'usuari
     */
    String getContrasenya () {
        return contrasenya;
    }

    /**
     * Obtenim el boolean que indica si l'usuari té alguna partida activa o no
     * Cost: O(1) en tots els casos
     * @return true si l'usuari té una partida activa, false en cas contrari
     */
    int getPidPartidaActiva () {
        return pidPartidaActiva;
    }

    /**
     * Obtenim el boolean que indica si l'usuari ha estat borrat o no
     * Cost: O(1) en tots els casos
     * @return true si l'usuari ha estat esborrat, false en cas contrari
     */
    boolean getEsborrat () {
        return esborrat;
    }

    /**
     * Obtenim l'idioma preferit de l'usuari
     * Cost: O(1) en tots els casos
     * @return l'idioma preferit del usuari
     */
    Idioma getIdiomaPreferit () {
        return idiomaPreferit;
    }

    /**
     * Posem el nom de l'usuari al valor que ens passen per paràmetre
     * Cost: O(1) en tots els casos
     * @param nomU nou nom de l'usuari
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     */
    void setNom (String nomU) {
        try {
            this.nom = nomU;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Posem l'atribut contrasenya de l'usuari al valor que ens passen per paràmetre
     * Cost: O(1) en tots els casos
     * @param contrasenyaU nova contrasenya de l'usuari
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     */
    void setContrasenya (String contrasenyaU) {
        try {
            this.contrasenya = contrasenyaU;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Posem l'atribut pidPartidaActiva de l'usuari al valor entrat pel paràmetre pid
     * Cost: O(1) en tots els casos
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     */
    void setPidPartidaActiva (int pid) {
        try {
            this.pidPartidaActiva = pid;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * "Esborrem" l'usuari posant l'atribut esborrat a true
     * Cost: O(1) en tots els casos
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     */
    void setEsborrat () {
        try {
            this.esborrat = true;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Canviem el nou idioma preferit de l'usuari per l'introduït
     * @param nouIdioma Representa el nou idioma preferit de l'usuari
     * Cost: O(1) en tots els casos
     * @exception IncompatibleClassChangeError No s'han pogut canviar les variables de la classe
     */
    void setIdioma (Idioma nouIdioma) {
        try {
            this.idiomaPreferit = nouIdioma;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
