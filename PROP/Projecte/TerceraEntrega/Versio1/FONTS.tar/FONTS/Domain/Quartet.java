package Domain;

/**
 * Classe Quartet
 *
 * Dona la posiblitat de tenir una estructura de dades amb 4 elements diferents
 *
 * @author Albert Bausili Fernández
 */
public class Quartet<P, S, T, Q> {

    private final P primer;
    private final S segon;
    private final T tercer;
    private final Q quart;

    // TODO: Afegir classe al diagrama
    /**
     * Crea un nou quartet amb els parametres demanats
     * Cost: O(1)
     * @param primer que sera el primer element del quartet
     * @param segon que sera el segon element del quartet
     * @param tercer que sera el tercer element del quartet
     * @param quart que sera el quart element del quartet
     */
    public Quartet(P primer, S segon, T tercer, Q quart) {
        this.primer = primer;
        this.segon = segon;
        this.tercer = tercer;
        this.quart = quart;
    }

    /**
     * Obtenim el primer element del quartet
     * Cost: O(1)
     * @return el primer element del quartet
     */
    public P getPrimer() {
        return primer;
    }

    /**
     * Obtenim el segon element del quartet
     * Cost: O(1)
     * @return el segon element del quartet
     */
    public S getSegon() {
        return segon;
    }

    /**
     * Obtenim el tercer element del quartet
     * Cost: O(1)
     * @return el tercer element del quartet
     */
    public T getTercer() {
        return tercer;
    }

    /**
     * Obtenim el quart element del quartet
     * Cost: O(1)
     * @return el quart element del quartet
     */
    public Q getQuart() {
        return quart;
    }
}

