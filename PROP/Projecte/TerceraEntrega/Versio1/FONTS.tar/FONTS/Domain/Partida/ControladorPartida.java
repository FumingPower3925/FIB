package Domain.Partida;

import java.util.*;
import java.time.*;

import Domain.Pair;
import Domain.Dificultat;
import Domain.Quartet;

import static Persistencia.PersistenciaPartida.*;

/**
 * Classe Controlador Partida
 * Conté les estructures de dades per a la correspondència de quin usuari està jugant una partida
 *
 * @author Noa Yu Ventura Vila
 */

public class ControladorPartida {

    /**
     * Guardem a memòria la partida que tenim activa de l'usuari que està loguejat
     * {@code Partida partidaActiva;}
     */
    Partida partidaActiva = null;

    /**
     * Tupla amb tots els resultats de les partides acabades que hi ha en el sistema
     * {@code HashMap<int,Resultat> cjt_resultats = new HashMap<Resultat>();}
     */
    HashMap<Integer,Resultat> cjt_resultats = new HashMap<>();

    /**
     * Guardem a memòria el tauler de la partida que tenim activa de l'usuari que està loguejat
     * {@code Tauler taulerActiu;}
     */
    Tauler taulerActiu;

    /**
     * Variable per guardar quina és la ID amb valor màxim que hi ha fins ara en el conjunt de partides
     * {@code private int max_id_partides;}
     */
    private int max_id_partides = -1;

    /**
     * Afegim la partida a la llista de partides actives. També hem de crear el seu tauler i generar el codi de la IA
     * Cost: O(n); on n és el nombre de columnes que té el tauler de la partida que volem afegir
     * @param dif dificultat de la partida
     * @param tipusP tipus de la partida
     * @param nFiles nombre de files que tindrà el tauler
     * @param nColumnes nomrbe de columnes que tindrà el tauler
     * @param nColors nombre de colors possibles que poden aparèixer al codi solució
     * @return el ID de la partida que acabem de crear
     * @exception IllegalArgumentException No s'han pogut modificar les llistes de la classe
     */
    public int afegirPartida(Dificultat dif, TipusPartida tipusP, int nFiles, int nColumnes, int nColors) {
        int id = -1;
        try {
            if (max_id_partides == -1 && existeixMaxPartides()) max_id_partides = tornarMaxPartides();
            id = max_id_partides+1;
            max_id_partides += 1;
            guardarMaxPartides(max_id_partides);
            Maquina maquina;
            if (dif == Dificultat.dificil) maquina = new MaquinaGenetic(nColors, nFiles);
            else if (dif == Dificultat.intermig || dif == Dificultat.facil) maquina = new MaquinaFiveGuess(nColors, nFiles);
            else throw new IllegalArgumentException("Aquesta dificultat no està registrada");
            partidaActiva = new Partida(id, dif, tipusP, maquina);
            taulerActiu = new Tauler(id, nFiles, nColumnes, nColors);
            guardarPartida(new Quartet<>(id, dif, tipusP, dif != Dificultat.dificil), new int[]{id, nFiles, nColumnes, nColors});
            crearCodiIA(id, nColumnes, nColors);
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return id;
    }

    /**
     * Creem el codi de la IA quan fa de codemaker
     * Cost: O(n) en tots els casos; on n és el nombre de columnes
     * @param id ID de la partida a la qual li creem el codi
     * @param nColumns nombre de columnes del tauler
     * @param nColors nombre de colors que farem servir a la partida
     * @exception IllegalArgumentException L'id del tauler no coincideix amb el tauler actiu
     */
    public void crearCodiIA(int id, int nColumns, int nColors) {
        if (id == taulerActiu.getTid()) {
            Colors[] valors = Colors.values();
            int abast = Math.min(valors.length, nColors);
            Colors[] colors = Arrays.copyOfRange(valors, 0, abast);
            Colors[] codi = new Colors[nColumns];
            Random r = new Random();
            for (int i = 0; i < nColumns; ++i) {
                int index = r.nextInt(nColors - i);
                codi[i] = colors[index];
                //l'eliminem del array de colors
                colors[index] = colors[nColors - i - 1];
            }
            System.out.println(Arrays.toString(codi));
            taulerActiu.setInitialCode(codi);
        }
        else throw new IllegalArgumentException("L'id del tauler no coincideix amb el tauler actiu");
    }

    /**
     * Esborrem la partida de la llista de partides. També esborra el seu tauler corresponent
     * Cost: O(1) en tots els casos
     * @param id ID de la partida que volem esborrar
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public void esborrarPartida(int id) {
        if (id == partidaActiva.getPid()) {
            partidaActiva = null;
            taulerActiu = null;
        }
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Afegim el resultat d'una partida acabada a la llista de resultats
     * Cost: O(1) amortitzat
     * @param pid ID de la partida de la que volem guardar el resultat
     * @return l'ID del resultat que acabem de crear
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public int afegirResultat(int pid) {
        if (pid == partidaActiva.getPid()) {
            int id = cjt_resultats.size();
            cjt_resultats.putIfAbsent(id, new Resultat(id, partidaActiva.getTipusPartida(), partidaActiva.getRondesUsuari(), partidaActiva.getRondesIA(), partidaActiva.getTempsInici(), partidaActiva.getTempsPartida(), partidaActiva.getPuntuacio()));
            guardarResultat(id, new Quartet<>(partidaActiva.getTipusPartida(), new int[]{partidaActiva.getRondesUsuari(), partidaActiva.getRondesIA(), partidaActiva.getPuntuacio()}, partidaActiva.getTempsInici(), partidaActiva.getTempsPartida()));
            return id;
        }
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Retorna un array de resultats amb els identificadors que entren pel parametre ids
     * Cost: O(1) en el millor cas, O(n) en el pitjor cas; on n és el nombre de resultats que volem obtenir (la mida del array)
     * @param ids array de múltiples rid dels que volem l'obtenir el resultat
     * @return l'array de resultats que volem obtenir, que contenen:
     *          1. LocalDateTime: el moment en que es va començar a jugar la partida
     *          2. int[]:
     *                  a. El tipus de partida: != 0 entrenament, = 0 ranked
     *                  b. Les rondes que ha fet l'usuari
     *                  c. Les rondes que ha fet la IA
     *                  d. El temps que ha durat la partida en segons
     *                  e. La puntuacio de la partida
     */
    public ArrayList<Pair<int[],LocalDateTime>> getResultatMultiple(Integer[] ids) {
        ArrayList<Pair<int[], LocalDateTime>> res = new ArrayList<>();
        Set<Integer> idsNoCache = new HashSet<>();
        int[] attr = new int[5];
        for (int i = 0; i < ids.length; ++i) {
            if (!cjt_resultats.containsKey(ids[i])) {
                idsNoCache.add(ids[i]);
            }
            else {
                Resultat r = cjt_resultats.get(ids[i]);
                if (r.getTipusPartida() == TipusPartida.entrenament) attr[0] = 1;
                else if (r.getTipusPartida() == TipusPartida.ranked) attr[0] = 0;
                attr[1] = r.getRondesUsuari();
                attr[2] = r.getRondesIA();
                attr[3] = (int)r.getTemps().getSeconds();
                attr[4] = r.getPuntuacio();
                res.add(new Pair<>(attr, r.getTempsInici()));
            }
        }
        ArrayList<Resultat> resultatsDisc = tornarResultats(idsNoCache);
        for (Resultat r : resultatsDisc) {
            cjt_resultats.putIfAbsent(r.getRid(), r);
            if (r.getTipusPartida() == TipusPartida.entrenament) attr[0] = 1;
            else if (r.getTipusPartida() == TipusPartida.ranked) attr[0] = 0;
            attr[1] = r.getRondesUsuari();
            attr[2] = r.getRondesIA();
            attr[3] = (int)r.getTemps().getSeconds();
            attr[4] = r.getPuntuacio();
            res.add(new Pair<>(attr, r.getTempsInici()));
        }
        return res;
    }

    /**
     * Obtenim el tauler de la partida
     * Cost: O(n*m) en tots els casos; on n és el nombre de files i m és el nombre de columnes del tauler
     * @param id ID de la partida de la que volem obtenir el tauler
     * @return el tauler de la partida
     * @exception IllegalArgumentException L'id del tauler no coincideix amb el tauler actiu
     */
     public Colors[][] getTauler(int id) {
         if (id == taulerActiu.getTid()) return taulerActiu.getTauler();
         else throw new IllegalArgumentException("L'id del tauler no coincideix amb el tauler actiu");
     }

    /**
     * Comprovem si el codi del codebreaker que s'ha entrat és el correcte. També informem si queden més files per seguir jugant una altra ronda
     * Cost: O(n^2) cas pitjor i mig, O(n) cas millor; on n és el nombre de columnes del tauler
     * @param id ID del tauler del que volem comprovar el codi
     * @param entered_code codi que ha entrat el codebreaker per intentar adivinar el codebreaker. Té tantes posicions com columnes té el codi del codemaker
     * @return una parella que conté:
     *          1. un array de booleans que indiquen: si hi ha més files per jugar una altra ronda i si s'ha encertat el codi
     *          2. un array de tantes posicions com columnes tingui el paràmetre entrat indicant quants colors s'han encertat
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public Pair<Pair<Boolean,Boolean>,Colors[]> comprovarCodi(int id, Colors[] entered_code) {
        if (id == partidaActiva.getPid()) {
            if (partidaActiva.getTornIA()) partidaActiva.incRondesIA();
            else partidaActiva.incRondesUsuari();
            Pair<Pair<Boolean, Boolean>, Colors[]> res = taulerActiu.comprovarCodi(entered_code);
            //Posem en true l'atribut tornIA de la partida quan s'han acabat el número de files o quan s'ha encertat el codi
            if (res.getKey().getKey() || res.getKey().getValue()) partidaActiva.setTornIA();
            return res;
        }
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * L'usuari demana ajuda en la partida. La funció fa:
     *          1. Si l'usuari ha encertat la fitxa del codi de l'esquerra del tot, llavors li confirmem que l'ha encertat
     *          2. Si no l'ha encertat, li indiquem de quin color és la fitxa de l'esquerra del tot
     * Cost: O(n); on n és el nombre de columnes del tauler
     * @param id ID de la partida en la que s'ha demanat ajuda
     * @return el color de la fitxa a l'esquerra del tot
     * @exception IllegalArgumentException LL'id del tauler no coincideix amb el tauler actiu
     */
    public Pair<Colors,Integer> demanarAjuda(int id) {
        if (id == taulerActiu.getTid()) return taulerActiu.pistaFitxa();
        else throw new IllegalArgumentException("L'id del tauler no coincideix amb el tauler actiu");
    }

    /**
     * Obtenim el número de files del tauler
     * Cost: O(1) en tots els casos
     * @param id ID de la partida
     * @return el número de files del tauler
     * @exception IllegalArgumentException L'id del tauler no coincideix amb el tauler actiu
     */
    public int getNfiles(int id) {
        if (id == taulerActiu.getTid()) return taulerActiu.getNfiles();
        else throw new IllegalArgumentException("L'id del tauler no coincideix amb el tauler actiu");
    }

    /**
     * Obtenim el número de columnes del tauler
     * Cost: O(1) en tots els casos
     * @param id ID de la partida de la que volem obtenir el número de colors
     * @return el número de columnes del tauler
     * @exception IllegalArgumentException L'id del tauler no coincideix amb el tauler actiu
     */
    public int getNcolumnes(int id) {
        if (id == taulerActiu.getTid()) return taulerActiu.getNcolumnes();
        else throw new IllegalArgumentException("L'id del tauler no coincideix amb el tauler actiu");
    }

    /**
     * Obtenim el número de colors que es juguen al tauler
     * Cost: O(1) en tots els casos
     * @param id ID de la partida de la que volem obtenir el número de colors
     * @return el número de colors que es juguen al tauler
     * @exception IllegalArgumentException L'id del tauler no coincideix amb el tauler actiu
     */
    public int getNcolors(int id) {
        if (id == taulerActiu.getTid()) return taulerActiu.getNcolors();
        else throw new IllegalArgumentException("L'id del tauler no coincideix amb el tauler actiu");
    }

    /**
     * Obtenim la dificultat de la partida
     * Cost: O(1) en tots els casos
     * @param id ID de la partida de la que volem obtenir la dificultat
     * @return la dificultat de la partida
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public Dificultat getDificultat(int id) {
        if (id == partidaActiva.getPid()) return partidaActiva.getDificultat();
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Obtenim el tipus de partida
     * Cost: O(1) en tots els casos
     * @param id ID de la partida de la que volem saber el tipus
     * @return el tipus de la partida
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public TipusPartida getTipusPartida(int id) {
        if (id == partidaActiva.getPid()) return partidaActiva.getTipusPartida();
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Obtenim si l'usuari ha demanat ajuda o no en la partida
     * Cost: O(1) en tots els casos
     * @param id ID de la partida de la que volem saber si l'usuari ha demanat ajuda
     * @return true si l'usuari ha demanat ajuda, false en cas contrari
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public boolean getUsatAjuda(int id) {
        if (id == partidaActiva.getPid()) return partidaActiva.getUsatAjuda();
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Obtenim les rondes que ha fet la IA en aquesta partida
     * Cost: O(1) en tots els casos
     * @param id la ID de la partida de la que volem obtenir la info
     * @return el número de rondes que ha fet la IA en aquesta partida
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public byte getRondesIA(int id) {
        if (id == partidaActiva.getPid()) return partidaActiva.getRondesIA();
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Obtenim les rondes que ha fet l'usuari en aquesta partida
     * Cost: O(1) en tots els casos
     * @param id ID de la partida de la que volem obtenir la info
     * @return el número de rondes que ha fet l'usuari en aquesta partida
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public byte getRondesUsuari(int id) {
        if (id == partidaActiva.getPid()) return partidaActiva.getRondesUsuari();
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Obtenim el temps que ha durat la partida fins ara
     * Cost: O(1) en tots els casos
     * @param id ID de la partida de la que volem obtenir la info
     * @return el temps que ha durat la partida
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public Duration getTempsPartida(int id) {
        if (id == partidaActiva.getPid()) return partidaActiva.getTempsPartida();
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Obtenim si és el torn de la IA per jugar com a codebreaker
     * Cost: O(1) en tots els casos
     * @param id ID de la partida de la qual volem saber si és el torn de la IA o no
     * @return <CODE>true</CODE> si és el torn de la IA per jugar com a codebreaker, <CODE>false</CODE> en cas contrari
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public boolean getTornIA(int id) {
        if (id == partidaActiva.getPid()) return partidaActiva.getTornIA();
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Indiquem a la partida que l'usuari ha demanat ajuda
     * Cost: O(1) en tots els casos
     * @param id ID de la partida
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public void setUsatAjuda(int id) {
        if (id == partidaActiva.getPid()) partidaActiva.setUsatAjuda();
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Indiquem a la partida que
     * Cost: O(1) en tots els casos
     * @param id ID de la partida de la que volem obtenir la info
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public void setIniciPartida(int id) {
        if (partidaActiva == null) {
            Pair<Partida, Tauler> tmp = tornarPartida(id);
            partidaActiva = tmp.getKey();
            taulerActiu = tmp.getValue();
        }
        if (id == partidaActiva.getPid()) partidaActiva.setIniciPartida();
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Incrementem el temps de partida, la partida ja té els valors necessaris per calcular en quant s'ha dincrementar
     * Cost: O(1) en tots els casos
     * @param id ID de la partida a la que li volem incrementar el temps que ha estat jugada
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public void incTempsPartida(int id) {
        if (id == partidaActiva.getPid()) partidaActiva.incTempsPartida();
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
        guardarPartida(new Quartet<>(partidaActiva.getPid(), partidaActiva.getDificultat(), partidaActiva.getTipusPartida(), partidaActiva.getMaquina()), new int[]{taulerActiu.getTid(), taulerActiu.getNfiles(), taulerActiu.getNcolumnes(), taulerActiu.getNcolors()});
    }

    /**
     * Calculem la puntuació que s'ha obtingut en la partida a partir dels atributs d'aquesta
     * Cost: O(1) en tots els casos
     * @param id ID de la partida de la que volem obtenir la puntuació
     * @return el valor que s'ha obtingut en la partida
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public int calcularPuntuacio(int id) {
        if (id == partidaActiva.getPid()) return partidaActiva.calcularPuntuacio(taulerActiu.getNcolumnes(), taulerActiu.getNcolors());
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }

    /**
     * Recolecta tots els intents que fa la IA en la resolució del codi
     * Cost: O(maxSteps * (colors^n + n^3)); on n és la longitud de la solució per a l'algoritme FiveGuess
     * Cost: O(n) en el millor cas, O(maxGeneracions * m * n^3) en el pitjor dels casos; on n és el nombre d'individus de la població, maxGeneracions és els intents per a l'algoritme Genètic
     * @param id ID de la partida en la que estem jugant
     * @param colorsSeleccionatsUsuari solucio que proposa l'usuari com a codemaker
     * @return  llista de combinacions de codis
     * @exception IllegalArgumentException L'id de la partida no coincideix amb la partida activa
     */
    public ArrayList<Colors[]> obteJugadesIA(int id, Colors[] colorsSeleccionatsUsuari){
        if (id == partidaActiva.getPid()) return partidaActiva.intentsMaquina(colorsSeleccionatsUsuari);
        else throw new IllegalArgumentException("L'id de la partida no coincideix amb la partida activa");
    }
}