package Domain.Partida;

import java.util.List;

/**
 * Interficie Maquina
 *
 * Interfície que representa la Màquina
 *
 * @author David Molina Mesa
 */
public interface Maquina {

    /**
     * Donada la solució del codi, l'operació solve utilitza un dels algorismes proposats (ja sigui Five Guess o
     * el genètic) per crear la llista de codis que portaran a la solució. Si l'algorisme no és capaç de trobar la
     * solució en menys de maxSteps passos, la llista retornada contindrà una llista composta per maxSteps codis.
     * L'operació llançarà una excepció en cas que la solució del codi secret no sigui consistent amb els paràmetres del
     * joc actual.
     * Cost: O(maxSteps * (colors^n + n^3)); on n és la longitud de la solució per a l'algoritme FiveGuess
     * Cost: O(n) en el millor cas, O(maxGeneracions * m * n^3) en el pitjor dels casos; on n és el nombre d'individus de la població, maxGeneracions és els intents per a l'algoritme Genètic
     * @param solution codi de la solució
     * @return una llista de combinacions proposades com solucions. La seva longitud depen de quants steps necessitarà
     * fer l'algorisme per trobar la solució, si no la troba retorna maxSteps codis.
     * @exception IllegalArgumentException Es llenca si el codi secret de solució no és coherent amb els paràmetres
     * de la partida actual
     */
    List<List<Integer>>  solve (List<Integer> solution) throws Exception;
}