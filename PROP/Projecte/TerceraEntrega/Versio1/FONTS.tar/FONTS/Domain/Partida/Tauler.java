package Domain.Partida;

import Domain.Pair;

import java.util.Arrays;
import java.util.Random;

/**
 * Classe Tauler
 * Conté la informacio del tauler de la partida
 *
 * @author David Molina Mesa
 */
public class Tauler {
    private final int tid;
    private Colors[][] tauler;
    private final int nfiles;
    private final int ncolumnes;
    private final int ncolors;

    private int filaActual;
    private boolean pistes[];

    /**
     * Crea un nou tauler amb els paràmetres demanats
     * Cost: O(1)
     * @param _tid ID que farem servir per identificar el nou tauler que crearem
     * @param _nfiles numero de files del tauler
     * @param _ncolumnes numero de columnes del tauler
     * @param _ncolors numero de colors que es juguen al tauler
     */
    public Tauler(int _tid, int _nfiles, int _ncolumnes, int _ncolors) {
        tid = _tid;
        nfiles = _nfiles+1;
        ncolumnes = _ncolumnes;
        ncolors = _ncolors;
        tauler = new Colors[nfiles][ncolumnes];
        for (Colors[] colors : tauler) {
            Arrays.fill(colors, Colors.buit);
        }
        filaActual = 0;
        pistes = new  boolean[_ncolumnes];
    }

    /**
     * Obtenim la id del tauler
     * Cost: O(1)
     * @return la id del tauler
     */
    int getTid() {
        return tid;
    }

    /**
     * Obtenim el numero de files del tauler
     * Cost: O(1)
     * @return el numero de files del tauler
     */
    int getNfiles() {
        return nfiles-1;
    }

    /**
     * Obtenim el numero de columnes del tauler
     * Cost: O(1)
     * @return el numero de columnes del tauler
     */
    int getNcolumnes() {
        return ncolumnes;
    }

    /**
     * Obtenim el número de colors que es juguen al tauler
     * Cost: O(1)
     * @return el numero de colors que es juguen al tauler
     */
    int getNcolors() {
        return ncolors;
    }

    /**
     * Obtenim la matriu que representa el tauler
     * Cost: O(n*m); on n és el nombre de files, m és el nombre de columnes del tauler
     * @return la matriu que representa el tauler
     */
    Colors[][] getTauler(){
        return tauler;
    }

    /**
     * Comprova el codi que proposa el Codebreaker amb el que proposa el Codemaker retornant si s'han arribat a
     * l'última fila del tauler i la resposta del Codemaker codi proposat
     * Cost: O(n^2) cas pitjor i mig, O(n) cas millor (essent n la longitud del codi proposat)
     * @param codiProposat codi proposat pel Codebreaker
     * @return Pair amb un pair que conté un boolean maximesFiles que indica si s'ha arribat al maxim de files i un
     * altre boolean que indica si s'ha resolt l'algorisme, com a segon element del primer pair la resposta de colors
     * (negre, blanc i buit) que donaria el Codemaker en format Array
     */
    Pair<Pair<Boolean,Boolean>,Colors[]> comprovarCodi(Colors[] codiProposat){
        ++filaActual;
        boolean maximesFiles = filaActual != nfiles;

        System.out.println("Fila actual: " + filaActual);
        System.out.println("Numero de files: " + nfiles);
        //set del codi
        for(int i = 0; i < ncolumnes; ++i) {
            tauler[filaActual][i] = codiProposat[i];
        }

        Colors[] solucio = new Colors[ncolumnes];
        for(int i = 0; i < ncolumnes; ++i) {
            solucio[i] = tauler[0][i];
        }

        Colors[] sortida = new Colors[ncolumnes];
        int blanques = 0;
        int negres = 0;
        for (int i = 0; i < codiProposat.length; ++i){
            for(int j = 0; j < solucio.length; ++j){
                if (codiProposat[i] == solucio[j]){
                    if(i == j) ++negres;
                    else ++blanques;
                    break;
                }
            }
        }

        boolean resolt = negres == solucio.length;
        int buides = negres + blanques - sortida.length;

        for (int i = 0; i < sortida.length; ++i){
            if(negres > 0){
                sortida[i] = Colors.negre;
                --negres;
            }
            else if(blanques > 0){
                sortida[i] = Colors.blanc;
                --blanques;
            }
            else if(buides > 0){
                sortida[i] = Colors.blanc;
                --buides;
            }
        }
        return new Pair<>(new Pair<>(maximesFiles,resolt), sortida);
    }

    /**
     * Col·loca el codi a endevinar del Codemaker a la fila 0 del tauler (cada color a una cela)
     * Cost: O(n); on n és la longitud del codi
     * @param codiSetejar codi a endevinar del code master
     */
    void setInitialCode(Colors[] codiSetejar){
        System.arraycopy(codiSetejar, 0, tauler[0], 0, codiSetejar.length);
    }

    /**
     * Obté una pista aleatoria que no s'hagi donat anteriorment
     * Cost: O(n); on n és la longitud la solucio
     * @return Pair amb el color de la fitxa i la seva posicio en la fila del tauler
     */
    public Pair<Colors, Integer> pistaFitxa() {
        Colors[] solucio = new Colors[ncolumnes];
        for (int i = 0; i < ncolumnes; ++i) {
            solucio[i] = tauler[0][i];
        }

        Random random = new Random();
        int index;
        Colors pistaColor;
        do {
            //generem index random no utiltizat
            index = random.nextInt(pistes.length);
        } while (pistes[index]);
        //asignem pista al index
        pistaColor = solucio[index];
        pistes[index] = true;

        return new Pair<>(pistaColor, index);
    }
}
