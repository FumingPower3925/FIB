package Domain.Partida;


public enum TipusPartida {
    entrenament,
    ranked,
}
